package com.nova.wallpapers

import android.graphics.*
import kotlin.math.*
import kotlin.random.Random

class Env {
    var w = 1
    var h = 1
    var dp = 1f
    var color = Color.CYAN
    var hue = 200f
    var sat = 0.7f
    var speed = 1f
    var amount = 1f
    var dir = 1f          // 1 = attract to finger, -1 = repel
    var touchOn = true
    var touching = false
    var radius = 300f     // touch radius in px
    var bounce = false    // keep objects inside the screen
    var ring = false      // show touch circle
    var dim = 0f
    var tx = 0f
    var ty = 0f
    var t = 0f
}

internal fun shade(c: Int, f: Float): Int = Color.rgb(
    (Color.red(c) * f).toInt().coerceIn(0, 255),
    (Color.green(c) * f).toInt().coerceIn(0, 255),
    (Color.blue(c) * f).toInt().coerceIn(0, 255)
)

internal fun drawPlanet(c: Canvas, p: Paint, cx: Float, cy: Float, rad: Float, base: Int, ring: Boolean, tilt: Float) {
    val rect = RectF(cx - rad * 1.9f, cy - rad * 0.5f, cx + rad * 1.9f, cy + rad * 0.5f)
    if (ring) {
        c.save()
        c.rotate(tilt, cx, cy)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = rad * 0.16f
        p.color = Color.argb(150, 230, 215, 180)
        c.drawOval(rect, p)
        c.restore()
    }
    p.style = Paint.Style.FILL
    p.shader = RadialGradient(
        cx - rad * 0.4f, cy - rad * 0.4f, rad * 1.6f,
        intArrayOf(shade(base, 1.4f), base, shade(base, 0.22f)),
        floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
    )
    c.drawCircle(cx, cy, rad, p)
    p.shader = null
    if (ring) {
        c.save()
        c.rotate(tilt, cx, cy)
        p.style = Paint.Style.STROKE
        p.strokeWidth = rad * 0.16f
        p.color = Color.argb(190, 230, 215, 180)
        c.drawArc(rect, 0f, 180f, false, p)
        c.restore()
    }
}

class StarField(private val count: Int) {
    private val sx = FloatArray(count) { Random.nextFloat() }
    private val sy = FloatArray(count) { Random.nextFloat() }
    private val sp = FloatArray(count) { Random.nextFloat() }
    fun draw(c: Canvas, p: Paint, e: Env) {
        p.shader = null
        p.style = Paint.Style.FILL
        for (i in 0 until count) {
            val tw = 0.5f + 0.5f * sin(e.t * (0.8f + sp[i]) + sp[i] * 20f)
            p.color = Color.argb((50 + 160 * tw).toInt(), 255, 255, 255)
            c.drawCircle(sx[i] * e.w, sy[i] * e.h, (0.6f + sp[i] * 1.2f) * e.dp, p)
        }
    }
}

abstract class Scene(protected val e: Env) {
    protected val p = Paint(Paint.ANTI_ALIAS_FLAG)
    protected var fx = 0f
    protected var fy = 0f

    abstract fun reset()
    abstract fun update(dt: Float)
    protected abstract fun draw(c: Canvas)

    protected fun bgColor(): Int {
        val r = (Color.red(e.color) * 0.07f).toInt() + 4
        val g = (Color.green(e.color) * 0.07f).toInt() + 5
        val b = (Color.blue(e.color) * 0.07f).toInt() + 9
        return Color.rgb(r, g, b)
    }

    fun render(c: Canvas) {
        c.drawColor(bgColor())
        draw(c)
        if (e.ring && e.touching && e.touchOn) {
            p.shader = null
            p.style = Paint.Style.FILL
            p.color = col(22)
            c.drawCircle(e.tx, e.ty, e.radius, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.5f * e.dp
            p.color = col(160)
            c.drawCircle(e.tx, e.ty, e.radius, p)
        }
        if (e.dim > 0f) c.drawColor(Color.argb((e.dim * 255).toInt(), 0, 0, 0))
    }

    protected fun rf(a: Float, b: Float) = a + Random.nextFloat() * (b - a)

    protected fun col(alpha: Int): Int =
        Color.argb(alpha.coerceIn(0, 255), Color.red(e.color), Color.green(e.color), Color.blue(e.color))

    protected fun hcol(dh: Float, alpha: Int): Int =
        Color.HSVToColor(alpha.coerceIn(0, 255), floatArrayOf(((e.hue + dh) % 360f + 360f) % 360f, e.sat, 1f))

    protected fun touchForce(px: Float, py: Float, strength: Float) {
        fx = 0f; fy = 0f
        if (!e.touching || !e.touchOn) return
        val dx = e.tx - px
        val dy = e.ty - py
        val d = sqrt(dx * dx + dy * dy)
        if (d < 1f || d > e.radius) return
        val k = (1f - d / e.radius) * strength * e.dir
        fx = dx / d * k
        fy = dy / d * k
    }
}

abstract class ParticleScene(e: Env, private val base: Int, private val cap: Int = 300) : Scene(e) {
    val x = FloatArray(cap)
    val y = FloatArray(cap)
    val vx = FloatArray(cap)
    val vy = FloatArray(cap)
    val a = FloatArray(cap)   // base velocity x
    val b = FloatArray(cap)   // base velocity y
    val s = FloatArray(cap)   // size
    val r = FloatArray(cap)   // rotation / phase
    val w = FloatArray(cap)   // rotation rate
    var n = 0

    protected open val marginDp = 80f
    protected open val canBounceY = true

    override fun reset() {
        n = (base * e.amount).toInt().coerceIn(4, cap)
        for (i in 0 until n) spawn(i, true)
    }

    abstract fun spawn(i: Int, initial: Boolean)

    protected fun randomPos(i: Int) {
        x[i] = rf(0f, e.w.toFloat())
        y[i] = rf(0f, e.h.toFloat())
    }

    protected fun drift(dt: Float, strength: Float) {
        val sw = e.w.toFloat()
        val sh = e.h.toFloat()
        val m = marginDp * e.dp
        val k = if (e.touching && e.touchOn) 2.8f else 1.2f
        for (i in 0 until n) {
            touchForce(x[i], y[i], strength)
            vx[i] += (a[i] - vx[i]) * k * dt + fx * dt
            vy[i] += (b[i] - vy[i]) * k * dt + fy * dt
            x[i] += vx[i] * dt * e.speed
            y[i] += vy[i] * dt * e.speed
            r[i] += w[i] * dt * e.speed
            if (e.bounce) {
                if (x[i] < 0f) { x[i] = 0f; vx[i] = abs(vx[i]); a[i] = abs(a[i]) }
                else if (x[i] > sw) { x[i] = sw; vx[i] = -abs(vx[i]); a[i] = -abs(a[i]) }
                if (canBounceY) {
                    if (y[i] < 0f) { y[i] = 0f; vy[i] = abs(vy[i]); b[i] = abs(b[i]) }
                    else if (y[i] > sh) { y[i] = sh; vy[i] = -abs(vy[i]); b[i] = -abs(b[i]) }
                } else {
                    if (y[i] > sh + m) y[i] = -m
                }
            } else {
                if (x[i] < -m) x[i] = sw + m else if (x[i] > sw + m) x[i] = -m
                if (y[i] < -m) y[i] = sh + m else if (y[i] > sh + m) y[i] = -m
            }
        }
    }
}

// ---------- Stars & lines ----------
class Constellation(e: Env) : ParticleScene(e, 90, 150) {
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        val ang = rf(0f, 6.283f)
        val sp = rf(8f, 28f) * e.dp
        a[i] = cos(ang) * sp; b[i] = sin(ang) * sp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(1.2f, 2.8f)
    }

    override fun update(dt: Float) = drift(dt, 2600f * e.dp)

    override fun draw(c: Canvas) {
        val maxD = 120f * e.dp
        val m2 = maxD * maxD
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * e.dp
        for (i in 0 until n) for (j in i + 1 until n) {
            val dx = x[i] - x[j]; val dy = y[i] - y[j]
            val d2 = dx * dx + dy * dy
            if (d2 < m2) {
                p.color = col(((1f - d2 / m2) * 150).toInt())
                c.drawLine(x[i], y[i], x[j], y[j], p)
            }
        }
        if (e.touching && e.touchOn) {
            val rr = e.radius
            for (i in 0 until n) {
                val dx = x[i] - e.tx; val dy = y[i] - e.ty
                val d = sqrt(dx * dx + dy * dy)
                if (d < rr) {
                    p.color = col(((1f - d / rr) * 200).toInt())
                    c.drawLine(x[i], y[i], e.tx, e.ty, p)
                }
            }
        }
        p.style = Paint.Style.FILL
        p.color = col(235)
        for (i in 0 until n) c.drawCircle(x[i], y[i], s[i] * e.dp, p)
    }
}

// ---------- 3D cubes ----------
class Cubes(e: Env) : ParticleScene(e, 14, 40) {
    private val rx = FloatArray(40); private val ry = FloatArray(40); private val rz = FloatArray(40)
    private val wx = FloatArray(40); private val wy = FloatArray(40); private val wz = FloatArray(40)
    private val vX = floatArrayOf(-1f, 1f, 1f, -1f, -1f, 1f, 1f, -1f)
    private val vY = floatArrayOf(-1f, -1f, 1f, 1f, -1f, -1f, 1f, 1f)
    private val vZ = floatArrayOf(-1f, -1f, -1f, -1f, 1f, 1f, 1f, 1f)
    private val edges = intArrayOf(0, 1, 1, 2, 2, 3, 3, 0, 4, 5, 5, 6, 6, 7, 7, 4, 0, 4, 1, 5, 2, 6, 3, 7)
    private val px = FloatArray(8)
    private val py = FloatArray(8)

    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        val ang = rf(0f, 6.283f)
        val sp = rf(6f, 20f) * e.dp
        a[i] = cos(ang) * sp; b[i] = sin(ang) * sp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(16f, 38f)
        rx[i] = rf(0f, 6.283f); ry[i] = rf(0f, 6.283f); rz[i] = rf(0f, 6.283f)
        wx[i] = rf(-0.8f, 0.8f); wy[i] = rf(-0.8f, 0.8f); wz[i] = rf(-0.6f, 0.6f)
    }

    override fun update(dt: Float) {
        drift(dt, 2200f * e.dp)
        for (i in 0 until n) {
            touchForce(x[i], y[i], 2200f * e.dp)
            val boost = 1f + (abs(fx) + abs(fy)) / (900f * e.dp)
            val k = dt * e.speed * boost
            rx[i] += wx[i] * k; ry[i] += wy[i] * k; rz[i] += wz[i] * k
        }
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * e.dp
        p.color = col(200)
        for (i in 0 until n) {
            val cxr = cos(rx[i]); val sxr = sin(rx[i])
            val cyr = cos(ry[i]); val syr = sin(ry[i])
            val czr = cos(rz[i]); val szr = sin(rz[i])
            val size = s[i] * e.dp
            for (k in 0 until 8) {
                val X = vX[k]; val Y = vY[k]; val Z = vZ[k]
                val y2 = Y * cxr - Z * sxr
                val z2 = Y * sxr + Z * cxr
                val x3 = X * cyr + z2 * syr
                val z3 = -X * syr + z2 * cyr
                val x4 = x3 * czr - y2 * szr
                val y4 = x3 * szr + y2 * czr
                val f = 4f / (4f + z3)
                px[k] = x[i] + x4 * f * size
                py[k] = y[i] + y4 * f * size
            }
            var q = 0
            while (q < edges.size) {
                c.drawLine(px[edges[q]], py[edges[q]], px[edges[q + 1]], py[edges[q + 1]], p)
                q += 2
            }
        }
    }
}

// ---------- Triangles ----------
class Triangles(e: Env) : ParticleScene(e, 30, 80) {
    private val path = Path()

    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        val ang = rf(0f, 6.283f)
        val sp = rf(6f, 24f) * e.dp
        a[i] = cos(ang) * sp; b[i] = sin(ang) * sp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(10f, 34f)
        r[i] = rf(0f, 6.283f)
        w[i] = rf(-0.9f, 0.9f)
    }

    override fun update(dt: Float) = drift(dt, 2400f * e.dp)

    override fun draw(c: Canvas) {
        p.strokeWidth = 1.5f * e.dp
        for (i in 0 until n) {
            path.reset()
            val rad = s[i] * e.dp
            for (k in 0 until 3) {
                val ang = r[i] + k * 2.0944f
                val qx = x[i] + cos(ang) * rad
                val qy = y[i] + sin(ang) * rad
                if (k == 0) path.moveTo(qx, qy) else path.lineTo(qx, qy)
            }
            path.close()
            if (i % 3 == 0) {
                p.style = Paint.Style.FILL
                p.color = col(40)
                c.drawPath(path, p)
            }
            p.style = Paint.Style.STROKE
            p.color = col(170)
            c.drawPath(path, p)
        }
    }
}

// ---------- Bubbles ----------
class Bubbles(e: Env) : ParticleScene(e, 30, 80) {
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        a[i] = rf(-8f, 8f) * e.dp
        b[i] = -rf(25f, 70f) * e.dp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(8f, 36f)
        r[i] = rf(0f, 6.283f)
        w[i] = rf(0.5f, 1.5f)
    }

    override fun update(dt: Float) = drift(dt, 2400f * e.dp)

    override fun draw(c: Canvas) {
        p.strokeWidth = 1.5f * e.dp
        for (i in 0 until n) {
            val cx = x[i] + sin(r[i]) * 6f * e.dp
            val rad = s[i] * e.dp
            p.style = Paint.Style.FILL
            p.color = col(25)
            c.drawCircle(cx, y[i], rad, p)
            p.style = Paint.Style.STROKE
            p.color = col(150)
            c.drawCircle(cx, y[i], rad, p)
            p.style = Paint.Style.FILL
            p.color = Color.argb(120, 255, 255, 255)
            c.drawCircle(cx - rad * 0.35f, y[i] - rad * 0.35f, rad * 0.16f, p)
        }
    }
}

// ---------- Rain ----------
class Rain(e: Env) : ParticleScene(e, 160, 300) {
    override val canBounceY = false
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        a[i] = rf(-30f, 30f) * e.dp
        b[i] = rf(700f, 1100f) * e.dp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(0.4f, 1f)
    }

    override fun update(dt: Float) = drift(dt, 5000f * e.dp)

    override fun draw(c: Canvas) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * e.dp
        for (i in 0 until n) {
            p.color = col((60 + s[i] * 120).toInt())
            c.drawLine(x[i], y[i], x[i] - vx[i] * 0.035f, y[i] - vy[i] * 0.035f, p)
        }
    }
}

// ---------- Snow ----------
class Snow(e: Env) : ParticleScene(e, 120, 250) {
    override val canBounceY = false
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        a[i] = rf(-10f, 10f) * e.dp
        b[i] = rf(40f, 95f) * e.dp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(1.2f, 3.6f)
        r[i] = rf(0f, 6.283f)
        w[i] = rf(0.6f, 1.6f)
    }

    override fun update(dt: Float) = drift(dt, 1800f * e.dp)

    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            p.color = col((110 + s[i] * 40).toInt())
            c.drawCircle(x[i] + sin(r[i]) * 10f * e.dp, y[i], s[i] * e.dp, p)
        }
    }
}

// ---------- Fog ----------
class Fog(e: Env) : ParticleScene(e, 7, 12) {
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        val ang = rf(0f, 6.283f)
        val sp = rf(6f, 20f) * e.dp
        a[i] = cos(ang) * sp; b[i] = sin(ang) * sp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(160f, 320f)
    }

    override fun update(dt: Float) = drift(dt, 500f * e.dp)

    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            val rad = s[i] * e.dp
            p.shader = RadialGradient(x[i], y[i], rad, col(85), col(0), Shader.TileMode.CLAMP)
            c.drawCircle(x[i], y[i], rad, p)
        }
        p.shader = null
    }
}

// ---------- Fireflies ----------
class Fireflies(e: Env) : ParticleScene(e, 45, 120) {
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        a[i] = rf(-25f, 25f) * e.dp; b[i] = rf(-25f, 25f) * e.dp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(0.7f, 1.3f)
        r[i] = rf(0f, 6.283f)
        w[i] = rf(1f, 3f)
    }

    override fun update(dt: Float) {
        val lim = 35f * e.dp
        for (i in 0 until n) {
            a[i] = (a[i] + rf(-1f, 1f) * 360f * e.dp * dt).coerceIn(-lim, lim)
            b[i] = (b[i] + rf(-1f, 1f) * 360f * e.dp * dt).coerceIn(-lim, lim)
        }
        drift(dt, 2200f * e.dp)
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            val pulse = 0.5f + 0.5f * sin(r[i])
            val k = (0.6f + 0.4f * pulse) * s[i] * e.dp
            p.color = col((25 + 30 * pulse).toInt())
            c.drawCircle(x[i], y[i], 18f * k, p)
            p.color = col((60 + 60 * pulse).toInt())
            c.drawCircle(x[i], y[i], 9f * k, p)
            p.color = col((150 + 100 * pulse).toInt())
            c.drawCircle(x[i], y[i], 3.5f * k, p)
        }
    }
}

// ---------- Planets (floating) ----------
class Planets(e: Env) : ParticleScene(e, 6, 10) {
    override val marginDp = 170f
    private val pal = listOf("#E8A04A", "#4A90E2", "#D9534F", "#9B6BD6", "#4FC3B0", "#C9B88A").map { Color.parseColor(it) }
    private val tint = IntArray(10)
    private val ringed = BooleanArray(10)
    private val stars = StarField(70)

    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        val ang = rf(0f, 6.283f)
        val sp = rf(4f, 12f) * e.dp
        a[i] = cos(ang) * sp; b[i] = sin(ang) * sp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(26f, 80f)
        tint[i] = pal[Random.nextInt(pal.size)]
        ringed[i] = i % 3 == 0
        r[i] = rf(-25f, 25f)
    }

    override fun update(dt: Float) = drift(dt, 900f * e.dp)

    override fun draw(c: Canvas) {
        stars.draw(c, p, e)
        for (i in 0 until n) drawPlanet(c, p, x[i], y[i], s[i] * e.dp, tint[i], ringed[i], r[i])
    }
}

// ---------- Solar system ----------
class SolarSystem(e: Env) : Scene(e) {
    private val k = 6
    private val pal = listOf("#B5B5B5", "#E8C07A", "#4A90E2", "#D9534F", "#E8A04A", "#4FC3B0").map { Color.parseColor(it) }
    private val size = floatArrayOf(6f, 9f, 10f, 8f, 17f, 12f)
    private val ph = FloatArray(6)
    private val ox = FloatArray(6)
    private val oy = FloatArray(6)
    private val sx = FloatArray(6)
    private val sy = FloatArray(6)
    private val stars = StarField(60)
    private val rect = RectF()

    override fun reset() {
        for (i in 0 until k) { ph[i] = rf(0f, 6.283f); ox[i] = 0f; oy[i] = 0f }
    }

    private fun orbit(i: Int) = min(e.w, e.h) * 0.5f * (0.30f + 0.12f * i)
    private fun ysc() = min(1.5f, e.h.toFloat() / e.w * 0.85f)

    override fun update(dt: Float) {
        val cx = e.w / 2f
        val cy = e.h / 2f
        val smooth = min(1f, 7f * dt)
        for (i in 0 until k) {
            val th = ph[i] + e.t * 0.5f * e.speed / (1f + i * 0.7f)
            val bx = cx + cos(th) * orbit(i)
            val by = cy + sin(th) * orbit(i) * ysc()
            var gx = 0f
            var gy = 0f
            if (e.touching && e.touchOn) {
                val dx = e.tx - bx; val dy = e.ty - by
                val d = sqrt(dx * dx + dy * dy)
                if (d in 1f..e.radius) {
                    val q = (1f - d / e.radius) * 0.85f * e.dir
                    gx = dx * q; gy = dy * q
                }
            }
            ox[i] += (gx - ox[i]) * smooth
            oy[i] += (gy - oy[i]) * smooth
            sx[i] = bx + ox[i]
            sy[i] = by + oy[i]
        }
    }

    override fun draw(c: Canvas) {
        val cx = e.w / 2f
        val cy = e.h / 2f
        stars.draw(c, p, e)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * e.dp
        p.color = col(40)
        for (i in 0 until k) {
            val o = orbit(i)
            rect.set(cx - o, cy - o * ysc(), cx + o, cy + o * ysc())
            c.drawOval(rect, p)
        }
        val glow = 90f * e.dp
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, glow, Color.argb(150, 255, 190, 80), Color.argb(0, 255, 140, 40), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, glow, p)
        p.shader = RadialGradient(cx, cy, 26f * e.dp, Color.rgb(255, 240, 180), Color.rgb(255, 160, 50), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, 26f * e.dp, p)
        p.shader = null
        for (i in 0 until k) {
            drawPlanet(c, p, sx[i], sy[i], size[i] * e.dp, pal[i], i == 4, -20f)
            if (i == 2) {
                val a = e.t * 2.2f * e.speed
                p.style = Paint.Style.FILL
                p.color = Color.argb(230, 220, 220, 220)
                c.drawCircle(sx[i] + cos(a) * 18f * e.dp, sy[i] + sin(a) * 18f * e.dp, 2.6f * e.dp, p)
            }
        }
    }
}

// ---------- Galaxy ----------
class Galaxy(e: Env) : Scene(e) {
    private val cap = 400
    private val ang = FloatArray(cap)
    private val rad = FloatArray(cap)
    private val sz = FloatArray(cap)
    private val ox = FloatArray(cap)
    private val oy = FloatArray(cap)
    private val sx = FloatArray(cap)
    private val sy = FloatArray(cap)
    private var n = 0

    override fun reset() {
        n = (260 * e.amount).toInt().coerceIn(60, cap)
        for (i in 0 until n) {
            rad[i] = Random.nextFloat().pow(1.6f)
            ang[i] = rad[i] * 7f + Random.nextInt(3) * 2.0944f + rf(-0.28f, 0.28f)
            sz[i] = rf(0.8f, 2.4f)
            ox[i] = 0f; oy[i] = 0f
        }
    }

    override fun update(dt: Float) {
        val cx = e.w / 2f
        val cy = e.h / 2f
        val rr = min(e.w, e.h) * 0.62f
        val smooth = min(1f, 7f * dt)
        for (i in 0 until n) {
            val th = ang[i] + e.t * 0.3f * e.speed
            val bx = cx + cos(th) * rad[i] * rr
            val by = cy + sin(th) * rad[i] * rr * 0.62f
            var gx = 0f
            var gy = 0f
            if (e.touching && e.touchOn) {
                val dx = e.tx - bx; val dy = e.ty - by
                val d = sqrt(dx * dx + dy * dy)
                if (d in 1f..e.radius) {
                    val k = (1f - d / e.radius) * 0.85f * e.dir
                    gx = dx * k; gy = dy * k
                }
            }
            ox[i] += (gx - ox[i]) * smooth
            oy[i] += (gy - oy[i]) * smooth
            sx[i] = bx + ox[i]
            sy[i] = by + oy[i]
        }
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        val gr = 110f * e.dp
        p.shader = RadialGradient(e.w / 2f, e.h / 2f, gr, col(110), col(0), Shader.TileMode.CLAMP)
        c.drawCircle(e.w / 2f, e.h / 2f, gr, p)
        p.shader = null
        for (i in 0 until n) {
            p.color = col((110 + (1f - rad[i]) * 140).toInt())
            c.drawCircle(sx[i], sy[i], sz[i] * e.dp, p)
        }
    }
}

// ---------- Waves ----------
class Waves(e: Env) : Scene(e) {
    private val path = Path()
    private var bump = 0f
    private var lx = 0f
    private var ly = 0f

    override fun reset() { bump = 0f }

    override fun update(dt: Float) {
        val on = e.touching && e.touchOn
        if (on) { lx = e.tx; ly = e.ty }
        bump += ((if (on) 1f else 0f) - bump) * min(1f, 5f * dt)
    }

    override fun draw(c: Canvas) {
        val w = e.w.toFloat()
        val h = e.h.toFloat()
        val sig = e.radius * 0.6f
        for (k in 0 until 6) {
            val baseY = h * (0.3f + 0.1f * k)
            val amp = (26f + 6f * k) * e.dp
            val sign = if (k % 2 == 0) 1f else -1f
            path.reset()
            var x = 0f
            var first = true
            while (x <= w + 12f) {
                val ph = x / w * 6.283f * (1.2f + 0.25f * k) + e.t * (0.6f + 0.2f * k) * e.speed * sign
                var y = baseY + sin(ph) * amp
                val dx = x - lx
                val g = exp(-(dx * dx) / (2f * sig * sig))
                y += (ly - y) * g * 0.55f * bump * e.dir
                if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
                x += 10f
            }
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.5f * e.dp
            p.color = col(60 + k * 30)
            c.drawPath(path, p)
            path.lineTo(w + 12f, h)
            path.lineTo(0f, h)
            path.close()
            p.style = Paint.Style.FILL
            p.color = col(14)
            c.drawPath(path, p)
        }
    }
}

// ---------- Aurora ----------
class Aurora(e: Env) : Scene(e) {
    private val path = Path()
    private var bump = 0f
    private var lx = 0f
    private var ly = 0f

    override fun reset() { bump = 0f }

    override fun update(dt: Float) {
        val on = e.touching && e.touchOn
        if (on) { lx = e.tx; ly = e.ty }
        bump += ((if (on) 1f else 0f) - bump) * min(1f, 4f * dt)
    }

    private fun top(x: Float, k: Int): Float {
        val w = e.w.toFloat()
        val sign = if (k % 2 == 0) 1f else -1f
        val base = e.h * (0.16f + 0.13f * k)
        val ph = x / w * 6.283f * (0.8f + 0.3f * k) + e.t * (0.25f + 0.1f * k) * e.speed * sign
        var y = base + sin(ph) * 60f * e.dp
        val sig = e.radius * 0.8f
        val dx = x - lx
        val g = exp(-(dx * dx) / (2f * sig * sig))
        y += (ly - y) * g * 0.5f * bump * e.dir
        return y
    }

    private fun thick(x: Float, k: Int): Float =
        e.h * 0.26f * (0.75f + 0.25f * sin(x / e.w * 9f + e.t * 0.5f * e.speed + k))

    override fun draw(c: Canvas) {
        val w = e.w.toFloat()
        p.style = Paint.Style.FILL
        for (k in 0 until 4) {
            val off = k * 35f
            path.reset()
            var x = 0f
            var first = true
            while (x <= w + 14f) {
                val y = top(x, k)
                if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
                x += 14f
            }
            x = w + 14f
            while (x >= 0f) {
                path.lineTo(x, top(x, k) + thick(x, k))
                x -= 14f
            }
            path.close()
            val y0 = e.h * (0.16f + 0.13f * k) - 70f * e.dp
            val y1 = e.h * (0.16f + 0.13f * k) + e.h * 0.26f + 70f * e.dp
            p.shader = LinearGradient(
                0f, y0, 0f, y1,
                intArrayOf(hcol(off, 0), hcol(off, 120), hcol(off + 25f, 0)),
                floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP
            )
            c.drawPath(path, p)
        }
        p.shader = null
    }
}

// ---------- Code rain ----------
class Matrix(e: Env) : Scene(e) {
    private val cap = 80
    private val head = FloatArray(cap)
    private val spd = FloatArray(cap)
    private val len = IntArray(cap)
    private val ox = FloatArray(cap)
    private var cols = 0
    private var cell = 0f
    private val chars = "0123456789ABCDEFGHJKLMNPRSTXYZ<>+=*#@".toCharArray()
    private val buf = CharArray(1)

    override fun reset() {
        val c0 = 16f * e.dp
        cols = min(cap, max(4, (e.w / c0).toInt()))
        cell = e.w.toFloat() / cols
        for (i in 0 until cols) respawn(i, true)
    }

    private fun respawn(i: Int, initial: Boolean) {
        head[i] = if (initial) rf(-e.h * 0.5f, e.h.toFloat()) else rf(-e.h * 0.3f, 0f)
        spd[i] = rf(120f, 320f) * e.dp
        len[i] = 8 + Random.nextInt(14)
        ox[i] = 0f
    }

    override fun update(dt: Float) {
        val smooth = min(1f, 7f * dt)
        for (i in 0 until cols) {
            head[i] += spd[i] * dt * e.speed
            if (head[i] - len[i] * cell > e.h) respawn(i, false)
            val colX = i * cell + cell / 2f
            var gx = 0f
            if (e.touching && e.touchOn) {
                val dx = e.tx - colX
                val ad = abs(dx)
                if (ad in 1f..e.radius) gx = dx * (1f - ad / e.radius) * 0.6f * e.dir
            }
            ox[i] += (gx - ox[i]) * smooth
        }
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        p.typeface = Typeface.MONOSPACE
        p.textAlign = Paint.Align.CENTER
        p.textSize = cell * 0.95f
        val tick = (e.t * 6f).toInt()
        val nChars = chars.size
        for (i in 0 until cols) {
            val x = i * cell + cell / 2f + ox[i]
            val headRow = floor(head[i] / cell).toInt()
            for (j in 0 until len[i]) {
                val row = headRow - j
                val y = (row + 1) * cell
                if (y < 0f || y > e.h + cell) continue
                p.color = if (j == 0) Color.argb(255, 235, 255, 245)
                else col((210 * (1f - j.toFloat() / len[i])).toInt())
                val hsh = row * 73 + i * 131 + (if (j < 2) tick * 7 else 0)
                val idx = ((hsh % nChars) + nChars) % nChars
                buf[0] = chars[idx]
                c.drawText(buf, 0, 1, x, y, p)
            }
        }
    }
}

// ---------- Ripples ----------
class Ripples(e: Env) : Scene(e) {
    private val cap = 30
    private val rx = FloatArray(cap)
    private val ry = FloatArray(cap)
    private val age = FloatArray(cap)
    private val maxR = FloatArray(cap)
    private val life = 2.5f
    private var amb = 0f
    private var fin = 0f

    override fun reset() { for (i in 0 until cap) age[i] = life }

    private fun add(x: Float, y: Float, mr: Float) {
        for (i in 0 until cap) {
            if (age[i] >= life) { rx[i] = x; ry[i] = y; maxR[i] = mr; age[i] = 0f; return }
        }
    }

    override fun update(dt: Float) {
        amb -= dt
        if (amb <= 0f) {
            add(rf(0f, e.w.toFloat()), rf(0f, e.h.toFloat()), rf(110f, 220f) * e.dp)
            amb = rf(0.5f, 1.3f) / e.speed
        }
        if (e.touching && e.touchOn) {
            fin -= dt
            if (fin <= 0f) { add(e.tx, e.ty, e.radius * 1.3f); fin = 0.12f }
        }
        for (i in 0 until cap) if (age[i] < life) age[i] += dt * e.speed
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.STROKE
        for (i in 0 until cap) {
            val k = age[i] / life
            if (k >= 1f) continue
            val rr = maxR[i] * (1f - (1f - k) * (1f - k))
            val al = ((1f - k) * 210).toInt()
            p.strokeWidth = 2.5f * e.dp
            p.color = col(al)
            c.drawCircle(rx[i], ry[i], rr, p)
            p.strokeWidth = 1.5f * e.dp
            p.color = col(al / 2)
            c.drawCircle(rx[i], ry[i], rr * 0.7f, p)
        }
    }
}

// ---------- Neon grid ----------
class NeonGrid(e: Env) : Scene(e) {
    private var vpx = 0f

    override fun reset() { vpx = e.w / 2f }

    override fun update(dt: Float) {
        val cx = e.w / 2f
        val target = if (e.touching && e.touchOn) cx + (e.tx - cx) * 0.6f * e.dir else cx
        vpx += (target - vpx) * min(1f, 4f * dt)
    }

    override fun draw(c: Canvas) {
        val w = e.w.toFloat()
        val h = e.h.toFloat()
        val cx = w / 2f
        val horizon = h * 0.55f
        val sunR = w * 0.24f
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, horizon - sunR, 0f, horizon, hcol(50f, 255), hcol(-50f, 255), Shader.TileMode.CLAMP)
        c.drawCircle(vpx, horizon, sunR, p)
        p.shader = null
        p.color = bgColor()
        c.drawRect(0f, horizon, w, h, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * e.dp
        for (i in -8..8) {
            p.color = col(130)
            c.drawLine(vpx + i * w * 0.025f, horizon, cx + i * w * 0.22f, h, p)
        }
        val n = 14
        val shift = (e.t * 0.35f * e.speed) % 1f
        for (j in 0 until n) {
            val f = (j + shift) / n
            val y = horizon + (h - horizon) * f * f
            p.color = col((f * 230).toInt())
            c.drawLine(0f, y, w, y, p)
        }
        p.color = col(230)
        p.strokeWidth = 2f * e.dp
        c.drawLine(0f, horizon, w, horizon, p)
    }
}

// ---------- Hyperspace ----------
class Warp(e: Env) : Scene(e) {
    private val cap = 400
    private val x = FloatArray(cap)
    private val y = FloatArray(cap)
    private val z = FloatArray(cap)
    private var n = 0
    private var vpx = 0f
    private var vpy = 0f

    override fun reset() {
        n = (220 * e.amount).toInt().coerceIn(50, cap)
        for (i in 0 until n) { spawn(i); z[i] = rf(0.05f, 1f) }
        vpx = e.w / 2f; vpy = e.h / 2f
    }

    private fun spawn(i: Int) {
        x[i] = rf(-1f, 1f); y[i] = rf(-1f, 1f); z[i] = 1f
    }

    override fun update(dt: Float) {
        val cx = e.w / 2f
        val cy = e.h / 2f
        var tx = cx
        var ty = cy
        if (e.touching && e.touchOn) {
            tx = if (e.dir > 0) e.tx else 2f * cx - e.tx
            ty = if (e.dir > 0) e.ty else 2f * cy - e.ty
        }
        val sm = min(1f, 4f * dt)
        vpx += (tx - vpx) * sm
        vpy += (ty - vpy) * sm
        for (i in 0 until n) {
            z[i] -= dt * 0.35f * e.speed
            if (z[i] < 0.03f) spawn(i)
        }
    }

    override fun draw(c: Canvas) {
        val k = max(e.w, e.h) * 0.2f
        p.style = Paint.Style.STROKE
        for (i in 0 until n) {
            val z1 = z[i]
            val z0 = z1 + 0.06f * e.speed
            val x1 = vpx + x[i] / z1 * k
            val y1 = vpy + y[i] / z1 * k
            val x0 = vpx + x[i] / z0 * k
            val y0 = vpy + y[i] / z0 * k
            val near = 1f - z1
            p.strokeWidth = (0.6f + near * 2.2f) * e.dp
            p.color = col((near * 300).toInt())
            c.drawLine(x0, y0, x1, y1, p)
        }
    }
}

object Scenes {
    val list = listOf(
        Triple("constellation", "Stars & lines", "Classic NOVA stars"),
        Triple("planets", "Planets", "Floating planets & rings"),
        Triple("solar", "Solar system", "Planets orbit the sun"),
        Triple("galaxy", "Galaxy", "Spiral of stars"),
        Triple("warp", "Hyperspace", "Fly through stars"),
        Triple("cubes", "3D cubes", "Spinning wireframes"),
        Triple("triangles", "Triangles", "Drifting shapes"),
        Triple("bubbles", "Bubbles", "Rising soap bubbles"),
        Triple("fireflies", "Fireflies", "Glowing lights"),
        Triple("aurora", "Aurora", "Northern lights"),
        Triple("waves", "Waves", "Flowing lines"),
        Triple("ripples", "Ripples", "Water rings"),
        Triple("grid", "Neon grid", "Synthwave horizon"),
        Triple("matrix", "Code rain", "Falling symbols"),
        Triple("rain", "Rain", "Heavy rainfall"),
        Triple("snow", "Snowfall", "Soft snow"),
        Triple("fog", "Fog", "Drifting mist")
    )

    fun create(id: String, e: Env): Scene {
        val s: Scene = when (id) {
            "planets" -> Planets(e)
            "solar" -> SolarSystem(e)
            "galaxy" -> Galaxy(e)
            "warp" -> Warp(e)
            "cubes" -> Cubes(e)
            "triangles" -> Triangles(e)
            "bubbles" -> Bubbles(e)
            "fireflies" -> Fireflies(e)
            "aurora" -> Aurora(e)
            "waves" -> Waves(e)
            "ripples" -> Ripples(e)
            "grid" -> NeonGrid(e)
            "matrix" -> Matrix(e)
            "rain" -> Rain(e)
            "snow" -> Snow(e)
            "fog" -> Fog(e)
            else -> Constellation(e)
        }
        s.reset()
        return s
    }
}
