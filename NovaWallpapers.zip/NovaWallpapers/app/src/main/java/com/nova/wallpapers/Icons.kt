package com.nova.wallpapers

import android.content.Context
import android.graphics.*
import android.view.View

/** Small vector icons drawn in code (24x24 grid). */
class IconView(ctx: Context, var kind: String, var color: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    fun set(kind: String, color: Int) {
        this.kind = kind
        this.color = color
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val s = min(width, height) / 24f
        c.save()
        c.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        c.scale(s, s)
        p.color = color
        p.strokeWidth = 2f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.style = Paint.Style.STROKE
        path.reset()
        when (kind) {
            "scenes" -> {
                for (i in 0..1) for (j in 0..1) c.drawRoundRect(RectF(3f + i * 10f, 3f + j * 10f, 11f + i * 10f, 11f + j * 10f), 2f, 2f, p)
            }
            "touch" -> {
                c.drawCircle(12f, 12f, 8f, p)
                p.style = Paint.Style.FILL
                c.drawCircle(12f, 12f, 2.6f, p)
            }
            "color" -> {
                c.drawCircle(12f, 12f, 9f, p)
                p.style = Paint.Style.FILL
                c.drawCircle(8f, 10f, 1.6f, p); c.drawCircle(12f, 7f, 1.6f, p); c.drawCircle(16f, 10f, 1.6f, p); c.drawCircle(9f, 15f, 1.6f, p)
            }
            "more" -> {
                c.drawLine(4f, 7f, 20f, 7f, p); c.drawLine(4f, 12f, 20f, 12f, p); c.drawLine(4f, 17f, 20f, 17f, p)
                p.style = Paint.Style.FILL
                c.drawCircle(9f, 7f, 2.4f, p); c.drawCircle(15f, 12f, 2.4f, p); c.drawCircle(8f, 17f, 2.4f, p)
            }
            "sound", "mute" -> {
                p.style = Paint.Style.FILL
                path.moveTo(4f, 9f); path.lineTo(8f, 9f); path.lineTo(13f, 5f); path.lineTo(13f, 19f); path.lineTo(8f, 15f); path.lineTo(4f, 15f); path.close()
                c.drawPath(path, p)
                p.style = Paint.Style.STROKE
                if (kind == "sound") {
                    c.drawArc(RectF(10f, 8f, 18f, 16f), -50f, 100f, false, p)
                    c.drawArc(RectF(8f, 4.5f, 22f, 19.5f), -50f, 100f, false, p)
                } else {
                    c.drawLine(16f, 9f, 22f, 15f, p); c.drawLine(22f, 9f, 16f, 15f, p)
                }
            }
            "bolt" -> {
                path.moveTo(13f, 2f); path.lineTo(5f, 13f); path.lineTo(11f, 13f); path.lineTo(10f, 22f); path.lineTo(19f, 10f); path.lineTo(13f, 10f); path.close()
                c.drawPath(path, p)
            }
            "refresh" -> {
                c.drawArc(RectF(4f, 4f, 20f, 20f), -40f, 280f, false, p)
                path.moveTo(15f, 2.5f); path.lineTo(19f, 5f); path.lineTo(15.5f, 8.5f)
                c.drawPath(path, p)
            }
            "shuffle" -> {
                c.drawLine(3f, 7f, 10f, 7f, p); c.drawLine(10f, 7f, 14f, 17f, p); c.drawLine(14f, 17f, 20f, 17f, p)
                c.drawLine(3f, 17f, 10f, 17f, p); c.drawLine(10f, 17f, 14f, 7f, p); c.drawLine(14f, 7f, 20f, 7f, p)
                c.drawLine(17f, 4f, 20f, 7f, p); c.drawLine(17f, 10f, 20f, 7f, p)
                c.drawLine(17f, 14f, 20f, 17f, p); c.drawLine(17f, 20f, 20f, 17f, p)
            }
            "drop" -> {
                path.moveTo(12f, 3f); path.cubicTo(18f, 10f, 19f, 13f, 19f, 15f); path.cubicTo(19f, 19f, 16f, 21f, 12f, 21f)
                path.cubicTo(8f, 21f, 5f, 19f, 5f, 15f); path.cubicTo(5f, 13f, 6f, 10f, 12f, 3f)
                c.drawPath(path, p)
            }
            "boat" -> {
                path.moveTo(3f, 15f); path.lineTo(21f, 15f); path.lineTo(17f, 20f); path.lineTo(7f, 20f); path.close()
                c.drawPath(path, p)
                path.reset(); path.moveTo(5f, 15f); path.lineTo(12f, 3f); path.lineTo(19f, 15f)
                c.drawPath(path, p)
            }
            "stone" -> {
                path.moveTo(5f, 15f); path.lineTo(8f, 7f); path.lineTo(15f, 5f); path.lineTo(20f, 11f); path.lineTo(18f, 18f); path.lineTo(10f, 20f); path.close()
                c.drawPath(path, p)
            }
            "atom" -> {
                for (a in intArrayOf(0, 60, 120)) {
                    c.save(); c.rotate(a.toFloat(), 12f, 12f)
                    c.drawOval(RectF(2f, 8f, 22f, 16f), p)
                    c.restore()
                }
                p.style = Paint.Style.FILL
                c.drawCircle(12f, 12f, 2f, p)
            }
            "plus" -> {
                p.strokeWidth = 2.6f
                c.drawLine(12f, 5f, 12f, 19f, p); c.drawLine(5f, 12f, 19f, 12f, p)
            }
            "back" -> {
                c.drawLine(15f, 5f, 8f, 12f, p); c.drawLine(8f, 12f, 15f, 19f, p)
            }
            "battery" -> {
                c.drawRoundRect(RectF(3f, 7f, 19f, 17f), 2f, 2f, p)
                c.drawLine(21f, 10f, 21f, 14f, p)
                p.style = Paint.Style.FILL
                c.drawRect(5.5f, 9.5f, 13f, 14.5f, p)
            }
            "image" -> {
                c.drawRoundRect(RectF(3f, 4f, 21f, 20f), 2.5f, 2.5f, p)
                path.moveTo(3f, 17f); path.lineTo(9f, 11f); path.lineTo(14f, 16f); path.lineTo(17f, 13f); path.lineTo(21f, 17f)
                c.drawPath(path, p)
                p.style = Paint.Style.FILL
                c.drawCircle(16f, 9f, 1.8f, p)
            }
            "video" -> {
                c.drawRoundRect(RectF(3f, 6f, 17f, 18f), 2.5f, 2.5f, p)
                path.moveTo(17f, 10f); path.lineTo(21f, 7.5f); path.lineTo(21f, 16.5f); path.lineTo(17f, 14f)
                c.drawPath(path, p)
            }
            "trash" -> {
                c.drawLine(4f, 7f, 20f, 7f, p)
                c.drawRoundRect(RectF(6f, 7f, 18f, 21f), 2f, 2f, p)
                c.drawLine(9f, 4f, 15f, 4f, p)
                c.drawLine(10f, 11f, 10f, 17f, p); c.drawLine(14f, 11f, 14f, 17f, p)
            }
            else -> c.drawCircle(12f, 12f, 8f, p)
        }
        c.restore()
    }

    private fun min(a: Int, b: Int) = if (a < b) a else b
}

object Icons {
    fun bitmap(ctx: Context, kind: String, color: Int, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val v = IconView(ctx, kind, color)
        v.layout(0, 0, size, size)
        v.draw(Canvas(bmp))
        return bmp
    }
}
