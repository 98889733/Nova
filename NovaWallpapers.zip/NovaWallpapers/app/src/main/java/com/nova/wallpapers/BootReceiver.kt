package com.nova.wallpapers

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** After a reboot: if the live wallpaper was reset by the system, remind the user to set it again. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        try {
            val prefs = Store.prefs(ctx)
            if (!prefs.getBoolean("active", false) || !prefs.getBoolean("remind", true)) return
            val info = WallpaperManager.getInstance(ctx).wallpaperInfo
            if (info != null && info.packageName == ctx.packageName) return
            prefs.edit().putBoolean("active", false).apply()
            notifyReset(ctx)
        } catch (_: Exception) {
        }
    }

    private fun notifyReset(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val chId = "wallpaper_reset"
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(chId, "Wallpaper reminders", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val open = Intent(ctx, MainActivity::class.java)
        open.putExtra("apply", true)
        open.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        val pi = PendingIntent.getActivity(ctx, 0, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, chId) else Notification.Builder(ctx)
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("NOVA Wallpapers was reset")
            .setContentText("Tap to set your live wallpaper again")
            .setContentIntent(pi)
            .setAutoCancel(true)
        nm.notify(1, b.build())
    }
}
