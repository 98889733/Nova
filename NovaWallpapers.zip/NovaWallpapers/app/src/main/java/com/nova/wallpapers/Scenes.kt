package com.nova.wallpapers

import android.graphics.*
import kotlin.math.*
import kotlin.random.Random

class Env {
    var w = 1
    var h = 1
    var dp = 1f
    var color = Color.CYAN
    var speed = 1f
    var amount = 1f
    var dir = 1f          // 1 = attract to finger, -1 = repel
    var touchOn = true
    var touching = false
    var tx = 0f
    var ty = 0f
    var t = 0f
}

abstract class Scene(protected val e: Env) {
    protected val p = Paint(Paint.ANTI_ALIAS_FLAG)
    protected var fx = 0f
    protected var fy = 0f

    abstract fun reset()
    abstract fun update(dt: Float)
    protected abstract fun draw(c: Canvas)

    fun render(c: Canvas) {
        val r = (Color.red(e.color) * 0.07f).toInt() + 4
        val g = (Color.green(e.color) * 0.07f).toInt() + 5
        val b = (Color.blue(e.color) * 0.07f).toInt() + 9
        c.drawColor(Color.rgb(r, g, b))
        draw(c)
    }

    protected fun rf(a: Float, b: Float) = a + Random.nextFloat() * (b - a)

    protected fun col(alpha: Int): Int =
        Color.argb(alpha.coerceIn(0, 255), Color.red(e.color), Color.green(e.color), Color.blue(e.color))

    protected fun touchForce(px: Float, py: Float, radius: Float, strength: Float) {
        fx = 0f; fy = 0f
        if (!e.touching || !e.touchOn) return
        val dx = e.tx - px
        val dy = e.ty - py
        val d = sqrt(dx * dx + dy * dy)
        if (d < 1f || d > radius) return
        val k = (1f - d / radius) * strength * e.dir
        fx = dx / d * k
        fy = dy / d * k
    }
}

abstract class ParticleScene(e: Env, private val base: Int, private val cap: Int = 300) : Scene(e) {
    val x = FloatArray(cap)
    val y = FloatArray(cap)
    val vx = FloatArray(cap)
    val vy = FloatArray(cap)
    val a = FloatArray(cap)   // base velocity x
    val b = FloatArray(cap)   // base velocity y
    val s = FloatArray(cap)   // size
    val r = FloatArray(cap)   // rotation / phase
    val w = FloatArray(cap)   // rotation rate
    var n = 0

    override fun reset() {
        n = (base * e.amount).toInt().coerceIn(4, cap)
        for (i in 0 until n) spawn(i, true)
    }

    abstract fun spawn(i: Int, initial: Boolean)

    protected fun randomPos(i: Int) {
        x[i] = rf(0f, e.w.toFloat())
        y[i] = rf(0f, e.h.toFloat())
    }

    protected fun drift(dt: Float, radius: Float, strength: Float) {
        val sw = e.w.toFloat()
        val sh = e.h.toFloat()
        val m = 80f * e.dp
        val k = if (e.touching && e.touchOn) 2.8f else 1.2f
        for (i in 0 until n) {
            touchForce(x[i], y[i], radius, strength)
            vx[i] += (a[i] - vx[i]) * k * dt + fx * dt
            vy[i] += (b[i] - vy[i]) * k * dt + fy * dt
            x[i] += vx[i] * dt * e.speed
            y[i] += vy[i] * dt * e.speed
            r[i] += w[i] * dt * e.speed
            if (x[i] < -m) x[i] = sw + m else if (x[i] > sw + m) x[i] = -m
            if (y[i] < -m) y[i] = sh + m else if (y[i] > sh + m) y[i] = -m
        }
    }
}

// ---------- 1. Stars & lines ----------
class Constellation(e: Env) : ParticleScene(e, 90, 150) {
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        val ang = rf(0f, 6.283f)
        val sp = rf(8f, 28f) * e.dp
        a[i] = cos(ang) * sp; b[i] = sin(ang) * sp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(1.2f, 2.8f)
    }

    override fun update(dt: Float) = drift(dt, 420f * e.dp, 2600f * e.dp)

    override fun draw(c: Canvas) {
        val maxD = 120f * e.dp
        val m2 = maxD * maxD
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * e.dp
        for (i in 0 until n) for (j in i + 1 until n) {
            val dx = x[i] - x[j]; val dy = y[i] - y[j]
            val d2 = dx * dx + dy * dy
            if (d2 < m2) {
                p.color = col(((1f - d2 / m2) * 150).toInt())
                c.drawLine(x[i], y[i], x[j], y[j], p)
            }
        }
        if (e.touching && e.touchOn) {
            val rr = 240f * e.dp
            for (i in 0 until n) {
                val dx = x[i] - e.tx; val dy = y[i] - e.ty
                val d = sqrt(dx * dx + dy * dy)
                if (d < rr) {
                    p.color = col(((1f - d / rr) * 200).toInt())
                    c.drawLine(x[i], y[i], e.tx, e.ty, p)
                }
            }
        }
        p.style = Paint.Style.FILL
        p.color = col(235)
        for (i in 0 until n) c.drawCircle(x[i], y[i], s[i] * e.dp, p)
    }
}

// ---------- 2. 3D cubes ----------
class Cubes(e: Env) : ParticleScene(e, 14, 40) {
    private val rx = FloatArray(40); private val ry = FloatArray(40); private val rz = FloatArray(40)
    private val wx = FloatArray(40); private val wy = FloatArray(40); private val wz = FloatArray(40)
    private val vX = floatArrayOf(-1f, 1f, 1f, -1f, -1f, 1f, 1f, -1f)
    private val vY = floatArrayOf(-1f, -1f, 1f, 1f, -1f, -1f, 1f, 1f)
    private val vZ = floatArrayOf(-1f, -1f, -1f, -1f, 1f, 1f, 1f, 1f)
    private val edges = intArrayOf(0, 1, 1, 2, 2, 3, 3, 0, 4, 5, 5, 6, 6, 7, 7, 4, 0, 4, 1, 5, 2, 6, 3, 7)
    private val px = FloatArray(8)
    private val py = FloatArray(8)

    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        val ang = rf(0f, 6.283f)
        val sp = rf(6f, 20f) * e.dp
        a[i] = cos(ang) * sp; b[i] = sin(ang) * sp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(16f, 38f)
        rx[i] = rf(0f, 6.283f); ry[i] = rf(0f, 6.283f); rz[i] = rf(0f, 6.283f)
        wx[i] = rf(-0.8f, 0.8f); wy[i] = rf(-0.8f, 0.8f); wz[i] = rf(-0.6f, 0.6f)
    }

    override fun update(dt: Float) {
        drift(dt, 420f * e.dp, 2200f * e.dp)
        for (i in 0 until n) {
            touchForce(x[i], y[i], 420f * e.dp, 2200f * e.dp)
            val boost = 1f + (abs(fx) + abs(fy)) / (900f * e.dp)
            val k = dt * e.speed * boost
            rx[i] += wx[i] * k; ry[i] += wy[i] * k; rz[i] += wz[i] * k
        }
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * e.dp
        p.color = col(200)
        for (i in 0 until n) {
            val cxr = cos(rx[i]); val sxr = sin(rx[i])
            val cyr = cos(ry[i]); val syr = sin(ry[i])
            val czr = cos(rz[i]); val szr = sin(rz[i])
            val size = s[i] * e.dp
            for (k in 0 until 8) {
                val X = vX[k]; val Y = vY[k]; val Z = vZ[k]
                val y2 = Y * cxr - Z * sxr
                val z2 = Y * sxr + Z * cxr
                val x3 = X * cyr + z2 * syr
                val z3 = -X * syr + z2 * cyr
                val x4 = x3 * czr - y2 * szr
                val y4 = x3 * szr + y2 * czr
                val f = 4f / (4f + z3)
                px[k] = x[i] + x4 * f * size
                py[k] = y[i] + y4 * f * size
            }
            var q = 0
            while (q < edges.size) {
                c.drawLine(px[edges[q]], py[edges[q]], px[edges[q + 1]], py[edges[q + 1]], p)
                q += 2
            }
        }
    }
}

// ---------- 3. Triangles ----------
class Triangles(e: Env) : ParticleScene(e, 30, 80) {
    private val path = Path()

    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        val ang = rf(0f, 6.283f)
        val sp = rf(6f, 24f) * e.dp
        a[i] = cos(ang) * sp; b[i] = sin(ang) * sp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(10f, 34f)
        r[i] = rf(0f, 6.283f)
        w[i] = rf(-0.9f, 0.9f)
    }

    override fun update(dt: Float) = drift(dt, 420f * e.dp, 2400f * e.dp)

    override fun draw(c: Canvas) {
        p.strokeWidth = 1.5f * e.dp
        for (i in 0 until n) {
            path.reset()
            val rad = s[i] * e.dp
            for (k in 0 until 3) {
                val ang = r[i] + k * 2.0944f
                val px = x[i] + cos(ang) * rad
                val py = y[i] + sin(ang) * rad
                if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()
            if (i % 3 == 0) {
                p.style = Paint.Style.FILL
                p.color = col(40)
                c.drawPath(path, p)
            }
            p.style = Paint.Style.STROKE
            p.color = col(170)
            c.drawPath(path, p)
        }
    }
}

// ---------- 4. Bubbles ----------
class Bubbles(e: Env) : ParticleScene(e, 30, 80) {
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        a[i] = rf(-8f, 8f) * e.dp
        b[i] = -rf(25f, 70f) * e.dp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(8f, 36f)
        r[i] = rf(0f, 6.283f)
        w[i] = rf(0.5f, 1.5f)
    }

    override fun update(dt: Float) = drift(dt, 380f * e.dp, 2400f * e.dp)

    override fun draw(c: Canvas) {
        p.strokeWidth = 1.5f * e.dp
        for (i in 0 until n) {
            val cx = x[i] + sin(r[i]) * 6f * e.dp
            val rad = s[i] * e.dp
            p.style = Paint.Style.FILL
            p.color = col(25)
            c.drawCircle(cx, y[i], rad, p)
            p.style = Paint.Style.STROKE
            p.color = col(150)
            c.drawCircle(cx, y[i], rad, p)
            p.style = Paint.Style.FILL
            p.color = Color.argb(120, 255, 255, 255)
            c.drawCircle(cx - rad * 0.35f, y[i] - rad * 0.35f, rad * 0.16f, p)
        }
    }
}

// ---------- 5. Rain ----------
class Rain(e: Env) : ParticleScene(e, 160, 300) {
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        a[i] = rf(-30f, 30f) * e.dp
        b[i] = rf(700f, 1100f) * e.dp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(0.4f, 1f)
    }

    override fun update(dt: Float) = drift(dt, 300f * e.dp, 5000f * e.dp)

    override fun draw(c: Canvas) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * e.dp
        for (i in 0 until n) {
            p.color = col((60 + s[i] * 120).toInt())
            c.drawLine(x[i], y[i], x[i] - vx[i] * 0.035f, y[i] - vy[i] * 0.035f, p)
        }
    }
}

// ---------- 6. Fog ----------
class Fog(e: Env) : ParticleScene(e, 7, 12) {
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        val ang = rf(0f, 6.283f)
        val sp = rf(6f, 20f) * e.dp
        a[i] = cos(ang) * sp; b[i] = sin(ang) * sp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(160f, 320f)
    }

    override fun update(dt: Float) = drift(dt, 600f * e.dp, 500f * e.dp)

    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            val rad = s[i] * e.dp
            p.shader = RadialGradient(x[i], y[i], rad, col(85), col(0), Shader.TileMode.CLAMP)
            c.drawCircle(x[i], y[i], rad, p)
        }
        p.shader = null
    }
}

// ---------- 7. Galaxy ----------
class Galaxy(e: Env) : Scene(e) {
    private val cap = 400
    private val ang = FloatArray(cap)
    private val rad = FloatArray(cap)
    private val sz = FloatArray(cap)
    private val ox = FloatArray(cap)
    private val oy = FloatArray(cap)
    private val sx = FloatArray(cap)
    private val sy = FloatArray(cap)
    private var n = 0

    override fun reset() {
        n = (260 * e.amount).toInt().coerceIn(60, cap)
        for (i in 0 until n) {
            rad[i] = Random.nextFloat().pow(1.6f)
            ang[i] = rad[i] * 7f + Random.nextInt(3) * 2.0944f + rf(-0.28f, 0.28f)
            sz[i] = rf(0.8f, 2.4f)
            ox[i] = 0f; oy[i] = 0f
        }
    }

    override fun update(dt: Float) {
        val cx = e.w / 2f
        val cy = e.h / 2f
        val rr = min(e.w, e.h) * 0.62f
        val reach = 380f * e.dp
        val smooth = min(1f, 7f * dt)
        for (i in 0 until n) {
            val th = ang[i] + e.t * 0.3f * e.speed
            val bx = cx + cos(th) * rad[i] * rr
            val by = cy + sin(th) * rad[i] * rr * 0.62f
            var gx = 0f
            var gy = 0f
            if (e.touching && e.touchOn) {
                val dx = e.tx - bx; val dy = e.ty - by
                val d = sqrt(dx * dx + dy * dy)
                if (d in 1f..reach) {
                    val k = (1f - d / reach) * 0.85f * e.dir
                    gx = dx * k; gy = dy * k
                }
            }
            ox[i] += (gx - ox[i]) * smooth
            oy[i] += (gy - oy[i]) * smooth
            sx[i] = bx + ox[i]
            sy[i] = by + oy[i]
        }
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        val gr = 110f * e.dp
        p.shader = RadialGradient(e.w / 2f, e.h / 2f, gr, col(110), col(0), Shader.TileMode.CLAMP)
        c.drawCircle(e.w / 2f, e.h / 2f, gr, p)
        p.shader = null
        for (i in 0 until n) {
            p.color = col((110 + (1f - rad[i]) * 140).toInt())
            c.drawCircle(sx[i], sy[i], sz[i] * e.dp, p)
        }
    }
}

// ---------- 8. Waves ----------
class Waves(e: Env) : Scene(e) {
    private val path = Path()
    private var bump = 0f
    private var lx = 0f
    private var ly = 0f

    override fun reset() { bump = 0f }

    override fun update(dt: Float) {
        val on = e.touching && e.touchOn
        if (on) { lx = e.tx; ly = e.ty }
        bump += ((if (on) 1f else 0f) - bump) * min(1f, 5f * dt)
    }

    override fun draw(c: Canvas) {
        val w = e.w.toFloat()
        val h = e.h.toFloat()
        val sig = 140f * e.dp
        for (k in 0 until 6) {
            val baseY = h * (0.3f + 0.1f * k)
            val amp = (26f + 6f * k) * e.dp
            val sign = if (k % 2 == 0) 1f else -1f
            path.reset()
            var x = 0f
            var first = true
            while (x <= w + 12f) {
                val ph = x / w * 6.283f * (1.2f + 0.25f * k) + e.t * (0.6f + 0.2f * k) * e.speed * sign
                var y = baseY + sin(ph) * amp
                val dx = x - lx
                val g = exp(-(dx * dx) / (2f * sig * sig))
                y += (ly - y) * g * 0.55f * bump * e.dir
                if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
                x += 10f
            }
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.5f * e.dp
            p.color = col(60 + k * 30)
            c.drawPath(path, p)
            path.lineTo(w + 12f, h)
            path.lineTo(0f, h)
            path.close()
            p.style = Paint.Style.FILL
            p.color = col(14)
            c.drawPath(path, p)
        }
    }
}

// ---------- 9. Fireflies ----------
class Fireflies(e: Env) : ParticleScene(e, 45, 120) {
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        a[i] = rf(-25f, 25f) * e.dp; b[i] = rf(-25f, 25f) * e.dp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(0.7f, 1.3f)
        r[i] = rf(0f, 6.283f)
        w[i] = rf(1f, 3f)
    }

    override fun update(dt: Float) {
        val lim = 35f * e.dp
        for (i in 0 until n) {
            a[i] = (a[i] + rf(-1f, 1f) * 60f * e.dp * dt * 6f).coerceIn(-lim, lim)
            b[i] = (b[i] + rf(-1f, 1f) * 60f * e.dp * dt * 6f).coerceIn(-lim, lim)
        }
        drift(dt, 380f * e.dp, 2200f * e.dp)
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            val pulse = 0.5f + 0.5f * sin(r[i])
            val k = (0.6f + 0.4f * pulse) * s[i] * e.dp
            p.color = col((25 + 30 * pulse).toInt())
            c.drawCircle(x[i], y[i], 18f * k, p)
            p.color = col((60 + 60 * pulse).toInt())
            c.drawCircle(x[i], y[i], 9f * k, p)
            p.color = col((150 + 100 * pulse).toInt())
            c.drawCircle(x[i], y[i], 3.5f * k, p)
        }
    }
}

// ---------- 10. Hyperspace ----------
class Warp(e: Env) : Scene(e) {
    private val cap = 400
    private val x = FloatArray(cap)
    private val y = FloatArray(cap)
    private val z = FloatArray(cap)
    private var n = 0
    private var vpx = 0f
    private var vpy = 0f

    override fun reset() {
        n = (220 * e.amount).toInt().coerceIn(50, cap)
        for (i in 0 until n) { spawn(i); z[i] = rf(0.05f, 1f) }
        vpx = e.w / 2f; vpy = e.h / 2f
    }

    private fun spawn(i: Int) {
        x[i] = rf(-1f, 1f); y[i] = rf(-1f, 1f); z[i] = 1f
    }

    override fun update(dt: Float) {
        val cx = e.w / 2f
        val cy = e.h / 2f
        var tx = cx
        var ty = cy
        if (e.touching && e.touchOn) {
            tx = if (e.dir > 0) e.tx else 2f * cx - e.tx
            ty = if (e.dir > 0) e.ty else 2f * cy - e.ty
        }
        val sm = min(1f, 4f * dt)
        vpx += (tx - vpx) * sm
        vpy += (ty - vpy) * sm
        for (i in 0 until n) {
            z[i] -= dt * 0.35f * e.speed
            if (z[i] < 0.03f) spawn(i)
        }
    }

    override fun draw(c: Canvas) {
        val k = max(e.w, e.h) * 0.2f
        p.style = Paint.Style.STROKE
        for (i in 0 until n) {
            val z1 = z[i]
            val z0 = z1 + 0.06f * e.speed
            val x1 = vpx + x[i] / z1 * k
            val y1 = vpy + y[i] / z1 * k
            val x0 = vpx + x[i] / z0 * k
            val y0 = vpy + y[i] / z0 * k
            val near = 1f - z1
            p.strokeWidth = (0.6f + near * 2.2f) * e.dp
            p.color = col((near * 300).toInt())
            c.drawLine(x0, y0, x1, y1, p)
        }
    }
}

object Scenes {
    val list = listOf(
        "constellation" to "Stars & lines",
        "cubes" to "3D cubes",
        "triangles" to "Triangles",
        "bubbles" to "Bubbles",
        "rain" to "Rain",
        "fog" to "Fog",
        "galaxy" to "Galaxy",
        "waves" to "Waves",
        "fireflies" to "Fireflies",
        "warp" to "Hyperspace"
    )

    fun create(id: String, e: Env): Scene {
        val s: Scene = when (id) {
            "cubes" -> Cubes(e)
            "triangles" -> Triangles(e)
            "bubbles" -> Bubbles(e)
            "rain" -> Rain(e)
            "fog" -> Fog(e)
            "galaxy" -> Galaxy(e)
            "waves" -> Waves(e)
            "fireflies" -> Fireflies(e)
            "warp" -> Warp(e)
            else -> Constellation(e)
        }
        s.reset()
        return s
    }
}
