package com.nova.wallpapers

import android.graphics.*
import kotlin.math.*
import kotlin.random.Random

// ---------- Meteor shower ----------
class Meteors(e: Env) : Scene(e) {
    private val cap = 24
    private val x = FloatArray(cap)
    private val y = FloatArray(cap)
    private val vx = FloatArray(cap)
    private val vy = FloatArray(cap)
    private val alive = BooleanArray(cap)
    private val stars = StarField(90)
    private var timer = 0f

    override fun reset() { alive.fill(false); timer = 0f }

    private fun launch(sx: Float, sy: Float) {
        for (i in 0 until cap) {
            if (!alive[i]) {
                alive[i] = true
                x[i] = sx; y[i] = sy
                val sp = rf(700f, 1100f) * e.dp
                val ang = rf(2.2f, 2.7f)
                vx[i] = cos(ang) * sp
                vy[i] = sin(ang) * sp
                e.sound("whoosh", 0.18f, rf(1.1f, 1.8f))
                return
            }
        }
    }

    override fun update(dt: Float) {
        val w = e.w.toFloat()
        val h = e.h.toFloat()
        timer -= dt
        if (timer <= 0f) {
            launch(rf(0.3f * w, 1.2f * w), -30f * e.dp)
            timer = rf(0.3f, 1.4f) / (e.amount * e.speed)
        }
        if (justTouched && e.touchOn) {
            for (k in 0 until 3) launch(e.tx + rf(-100f, 300f) * e.dp, e.ty - rf(100f, 300f) * e.dp)
        }
        for (i in 0 until cap) {
            if (!alive[i]) continue
            touchForce(x[i], y[i], 3000f * e.dp)
            vx[i] += fx * dt
            vy[i] += fy * dt
            x[i] += vx[i] * dt * e.speed
            y[i] += vy[i] * dt * e.speed
            if (x[i] < -200f * e.dp || y[i] > h + 200f * e.dp) alive[i] = false
        }
    }

    override fun draw(c: Canvas) {
        stars.draw(c, p, e)
        for (i in 0 until cap) {
            if (!alive[i]) continue
            p.style = Paint.Style.STROKE
            for (k in 0 until 7) {
                val t0 = k * 0.018f
                val t1 = (k + 1) * 0.018f
                p.strokeWidth = (3.2f - k * 0.4f).coerceAtLeast(0.8f) * e.dp
                p.color = col(240 - k * 32)
                c.drawLine(x[i] - vx[i] * t0, y[i] - vy[i] * t0, x[i] - vx[i] * t1, y[i] - vy[i] * t1, p)
            }
            p.style = Paint.Style.FILL
            p.color = Color.WHITE
            c.drawCircle(x[i], y[i], 2.6f * e.dp, p)
        }
    }
}

// ---------- Petals ----------
class Petals(e: Env) : ParticleScene(e, 40, 100) {
    override val canBounceY = false
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        a[i] = rf(-12f, 12f) * e.dp
        b[i] = rf(30f, 70f) * e.dp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(5f, 10f)
        r[i] = rf(0f, 6.283f)
        w[i] = rf(-1.6f, 1.6f)
    }

    override fun update(dt: Float) = drift(dt, 1800f * e.dp)

    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        val rect = RectF()
        for (i in 0 until n) {
            val sw = x[i] + sin(r[i] * 0.7f) * 14f * e.dp
            val rad = s[i] * e.dp
            c.save()
            c.translate(sw, y[i])
            c.rotate(r[i] * 57.29578f)
            p.color = hcol(i % 4 * 12f, 185)
            rect.set(-rad, -rad * 0.55f, rad, rad * 0.55f)
            c.drawOval(rect, p)
            p.color = Color.argb(70, 255, 255, 255)
            rect.set(-rad * 0.6f, -rad * 0.25f, rad * 0.4f, rad * 0.1f)
            c.drawOval(rect, p)
            c.restore()
        }
    }
}

// ---------- Lava lamp ----------
class LavaLamp(e: Env) : ParticleScene(e, 7, 12) {
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        a[i] = rf(-8f, 8f) * e.dp
        b[i] = (if (Random.nextBoolean()) 1f else -1f) * rf(12f, 32f) * e.dp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(60f, 140f)
    }

    override fun update(dt: Float) {
        val sw = e.w.toFloat()
        val sh = e.h.toFloat()
        for (i in 0 until n) {
            touchForce(x[i], y[i], 1500f * e.dp)
            vx[i] += ((a[i] - vx[i]) * 0.8f + fx) * dt
            vy[i] += ((b[i] - vy[i]) * 0.8f + fy) * dt
            x[i] += vx[i] * dt * e.speed
            y[i] += vy[i] * dt * e.speed
            val m = s[i] * e.dp * 0.4f
            if (x[i] < m) { x[i] = m; a[i] = abs(a[i]); vx[i] = abs(vx[i]) }
            else if (x[i] > sw - m) { x[i] = sw - m; a[i] = -abs(a[i]); vx[i] = -abs(vx[i]) }
            if (y[i] < m) { y[i] = m; b[i] = abs(b[i]); vy[i] = abs(vy[i]) }
            else if (y[i] > sh - m) { y[i] = sh - m; b[i] = -abs(b[i]); vy[i] = -abs(vy[i]) }
        }
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            val rad = s[i] * e.dp * 1.6f
            p.shader = RadialGradient(x[i], y[i], rad, hcol(i * 14f, 230), hcol(i * 14f, 0), Shader.TileMode.CLAMP)
            c.drawCircle(x[i], y[i], rad, p)
        }
        p.shader = null
    }
}

// ---------- Hex pulse ----------
class HexPulse(e: Env) : Scene(e) {
    override val touchSound: String? = "tick"
    private val path = Path()
    private val cs = FloatArray(6) { cos(it * 1.0471976f) }
    private val sn = FloatArray(6) { sin(it * 1.0471976f) }

    override fun reset() {}
    override fun update(dt: Float) {}

    override fun draw(c: Canvas) {
        val rr = 26f * e.dp
        val dx = 1.5f * rr
        val dy = 1.7320508f * rr
        val cols = (e.w / dx).toInt() + 2
        val rows = (e.h / dy).toInt() + 2
        val reach = e.radius * 1.6f
        for (q in 0 until cols) {
            for (r in 0 until rows) {
                val cx = q * dx
                val cy = r * dy + (if (q % 2 == 1) dy / 2f else 0f)
                val dcen = hypot(cx - e.w / 2f, cy - e.h / 2f)
                var b = 0.5f + 0.5f * sin(dcen / (90f * e.dp) - e.t * 1.6f * e.speed)
                b *= b
                if (e.touching && e.touchOn) {
                    val d = hypot(cx - e.tx, cy - e.ty)
                    if (d < reach) {
                        val k = 1f - d / reach
                        val wv = 0.5f + 0.5f * sin(d / (28f * e.dp) - e.t * 9f * e.dir)
                        b = max(b, k * wv)
                    }
                }
                path.reset()
                for (k in 0 until 6) {
                    val px = cx + cs[k] * rr * 0.9f
                    val py = cy + sn[k] * rr * 0.9f
                    if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                val dh = cx / e.w * 60f
                p.style = Paint.Style.FILL
                p.color = hcol(dh, (b * 110).toInt())
                c.drawPath(path, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.2f * e.dp
                p.color = hcol(dh, (30 + b * 170).toInt())
                c.drawPath(path, p)
            }
        }
    }
}

// ---------- Tunnel ----------
class Tunnel(e: Env) : Scene(e) {
    override val touchSound: String? = "whoosh"
    private var vpx = 0f
    private var vpy = 0f
    private val path = Path()

    override fun reset() { vpx = e.w / 2f; vpy = e.h / 2f }

    override fun update(dt: Float) {
        val cx = e.w / 2f
        val cy = e.h / 2f
        var tx = cx
        var ty = cy
        if (e.touching && e.touchOn) {
            tx = if (e.dir > 0) e.tx else 2f * cx - e.tx
            ty = if (e.dir > 0) e.ty else 2f * cy - e.ty
        }
        val sm = min(1f, 4f * dt)
        vpx += (tx - vpx) * sm
        vpy += (ty - vpy) * sm
    }

    override fun draw(c: Canvas) {
        val cx = e.w / 2f
        val cy = e.h / 2f
        val n = 16
        val off = (e.t * 0.35f * e.speed) % 1f
        val base = min(e.w, e.h) * 0.06f
        p.style = Paint.Style.STROKE
        for (j in n - 1 downTo 0) {
            val u = (j + off) / n
            val rad = base / (u * u + 0.012f)
            val px = cx + (vpx - cx) * (1f - u)
            val py = cy + (vpy - cy) * (1f - u)
            val rot = e.t * 0.3f + j * 0.12f
            path.reset()
            for (k in 0 until 6) {
                val a = rot + k * 1.0471976f
                val qx = px + cos(a) * rad
                val qy = py + sin(a) * rad
                if (k == 0) path.moveTo(qx, qy) else path.lineTo(qx, qy)
            }
            path.close()
            val fade = if (u < 0.12f) u / 0.12f else 1f
            p.strokeWidth = (1f + (1f - u) * 5f) * e.dp
            p.color = hcol(j * 14f, (200f * (1f - u * 0.6f) * fade).toInt())
            c.drawPath(path, p)
        }
    }
}

// ---------- Equalizer ----------
class Equalizer(e: Env) : Scene(e) {
    override val touchSound: String? = "tick"
    private val bars = 28
    private val hgt = FloatArray(bars)
    private val peak = FloatArray(bars)
    private val ph = FloatArray(bars) { Random.nextFloat() * 6.283f }
    private val fr = FloatArray(bars) { 0.8f + Random.nextFloat() * 1.4f }
    private val rect = RectF()

    override fun reset() { hgt.fill(0.2f); peak.fill(0.2f) }

    override fun update(dt: Float) {
        for (i in 0 until bars) {
            var target = (0.35f + 0.3f * sin(e.t * fr[i] * e.speed * 2f + ph[i]) +
                0.2f * sin(e.t * fr[i] * 3.1f * e.speed + ph[i] * 1.7f)).coerceIn(0.05f, 0.9f)
            if (e.touching && e.touchOn) {
                val bx = (i + 0.5f) * e.w / bars
                val d = abs(bx - e.tx)
                if (d < e.radius) {
                    val k = 1f - d / e.radius
                    target = if (e.dir > 0) target + (1f - target) * k else target * (1f - k * 0.9f)
                }
            }
            hgt[i] += (target - hgt[i]) * min(1f, 10f * dt)
            if (hgt[i] > peak[i]) peak[i] = hgt[i] else peak[i] = max(hgt[i], peak[i] - 0.25f * dt)
        }
    }

    override fun draw(c: Canvas) {
        val bw = e.w.toFloat() / bars
        val maxH = e.h * 0.7f
        p.style = Paint.Style.FILL
        for (i in 0 until bars) {
            val x0 = i * bw
            val bh = hgt[i] * maxH
            p.color = hcol(i * 4f - 40f, 225)
            rect.set(x0 + bw * 0.12f, e.h - bh, x0 + bw * 0.88f, e.h.toFloat())
            c.drawRoundRect(rect, bw * 0.2f, bw * 0.2f, p)
            p.color = Color.argb(200, 255, 255, 255)
            val py = e.h - peak[i] * maxH - 8f * e.dp
            c.drawRect(x0 + bw * 0.12f, py, x0 + bw * 0.88f, py + 4f * e.dp, p)
        }
    }
}

// ---------- Thunderstorm ----------
class Storm(e: Env) : ParticleScene(e, 200, 300) {
    override val canBounceY = false
    override val touchSound: String? = null
    private var timer = 2f
    private var flash = 0f
    private var thunderIn = -1f
    private val bx = FloatArray(25)
    private val by = FloatArray(25)
    private var boltLife = 0f
    private val path = Path()

    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        a[i] = rf(-120f, -60f) * e.dp
        b[i] = rf(900f, 1300f) * e.dp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(0.4f, 1f)
    }

    private fun strike(targetX: Float, targetY: Float) {
        val h = e.h.toFloat()
        val endY = targetY
        var cx = targetX + rf(-120f, 120f) * e.dp
        for (k in 0 until 25) {
            by[k] = endY * k / 24f
            val pull = (targetX - cx) * 0.15f
            cx += rf(-40f, 40f) * e.dp + pull
            bx[k] = cx
        }
        boltLife = 0.25f
        flash = 1f
        thunderIn = rf(0.25f, 1.1f)
    }

    override fun update(dt: Float) {
        drift(dt, 5000f * e.dp)
        timer -= dt
        if (timer <= 0f) {
            strike(rf(0.15f, 0.85f) * e.w, rf(0.5f, 0.85f) * e.h)
            timer = rf(3f, 8f)
        }
        if (justTouched && e.touchOn) strike(e.tx, e.ty)
        if (flash > 0f) flash = max(0f, flash - dt * 3f)
        if (boltLife > 0f) boltLife -= dt
        if (thunderIn > 0f) {
            thunderIn -= dt
            if (thunderIn <= 0f) e.sound("thunder", 0.9f, rf(0.85f, 1.1f))
        }
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * e.dp
        for (i in 0 until n) {
            p.color = col((50 + s[i] * 110).toInt())
            c.drawLine(x[i], y[i], x[i] - vx[i] * 0.035f, y[i] - vy[i] * 0.035f, p)
        }
        if (boltLife > 0f) {
            path.reset()
            for (k in 0 until 25) if (k == 0) path.moveTo(bx[k], by[k]) else path.lineTo(bx[k], by[k])
            p.strokeWidth = 9f * e.dp
            p.color = Color.argb(60, 200, 220, 255)
            c.drawPath(path, p)
            p.strokeWidth = 2.5f * e.dp
            p.color = Color.argb(255, 255, 255, 255)
            c.drawPath(path, p)
        }
        if (flash > 0f) c.drawColor(Color.argb((flash * 110).toInt(), 220, 230, 255))
    }
}

// ---------- Fireworks ----------
class Fireworks(e: Env) : Scene(e) {
    private val cap = 420
    private val sx = FloatArray(cap)
    private val sy = FloatArray(cap)
    private val svx = FloatArray(cap)
    private val svy = FloatArray(cap)
    private val sl = FloatArray(cap)
    private val sm = FloatArray(cap)
    private val sh = FloatArray(cap)
    private val rx = FloatArray(6)
    private val ry = FloatArray(6)
    private val rvy = FloatArray(6)
    private val rtg = FloatArray(6)
    private val rh = FloatArray(6)
    private val ra = BooleanArray(6)
    private val hsv = FloatArray(3)
    private var timer = 0.3f

    override fun reset() { sl.fill(0f); ra.fill(false); timer = 0.3f }

    private fun launch(x: Float, target: Float) {
        for (i in 0 until 6) {
            if (!ra[i]) {
                ra[i] = true
                rx[i] = x
                ry[i] = e.h + 10f * e.dp
                rvy[i] = -rf(750f, 1000f) * e.dp
                rtg[i] = target
                rh[i] = rf(0f, 360f)
                e.sound("fizz", 0.3f, rf(0.9f, 1.3f))
                return
            }
        }
    }

    private fun burst(x: Float, y: Float, hue: Float) {
        val cnt = (60 * e.amount).toInt().coerceIn(30, 110)
        var made = 0
        for (k in 0 until cap) {
            if (made >= cnt) break
            if (sl[k] <= 0f) {
                val ang = rf(0f, 6.283f)
                val sp = rf(0.25f, 1f) * 280f * e.dp
                sx[k] = x; sy[k] = y
                svx[k] = cos(ang) * sp
                svy[k] = sin(ang) * sp
                sm[k] = rf(0.9f, 1.7f)
                sl[k] = sm[k]
                sh[k] = hue + rf(-25f, 25f)
                made++
            }
        }
        e.sound("pop", 0.55f, rf(0.85f, 1.2f))
    }

    override fun update(dt: Float) {
        timer -= dt
        if (timer <= 0f) {
            launch(rf(0.15f, 0.85f) * e.w, rf(0.15f, 0.5f) * e.h)
            timer = rf(0.7f, 1.8f) / e.speed
        }
        if (justTouched && e.touchOn) launch(e.tx, e.ty)
        for (i in 0 until 6) {
            if (!ra[i]) continue
            ry[i] += rvy[i] * dt
            if (ry[i] <= rtg[i]) {
                burst(rx[i], ry[i], rh[i])
                ra[i] = false
            }
        }
        for (k in 0 until cap) {
            if (sl[k] <= 0f) continue
            svy[k] += 160f * e.dp * dt
            svx[k] *= (1f - 0.5f * dt)
            svy[k] *= (1f - 0.3f * dt)
            sx[k] += svx[k] * dt
            sy[k] += svy[k] * dt
            sl[k] -= dt
        }
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * e.dp
        for (i in 0 until 6) {
            if (!ra[i]) continue
            p.color = Color.argb(230, 255, 240, 200)
            c.drawLine(rx[i], ry[i], rx[i], ry[i] - rvy[i] * 0.05f, p)
        }
        p.style = Paint.Style.FILL
        for (k in 0 until cap) {
            if (sl[k] <= 0f) continue
            val f = (sl[k] / sm[k]).coerceIn(0f, 1f)
            hsv[0] = ((sh[k] % 360f) + 360f) % 360f
            hsv[1] = 0.65f
            hsv[2] = 1f
            p.color = Color.HSVToColor((f * 255).toInt(), hsv)
            c.drawCircle(sx[k], sy[k], (1.2f + f * 1.8f) * e.dp, p)
        }
    }
}

// ---------- Plasma ----------
class Plasma(e: Env) : Scene(e) {
    private val hsv = FloatArray(3)
    override fun reset() {}
    override fun update(dt: Float) {}

    override fun draw(c: Canvas) {
        val cell = 18f * e.dp
        val cols = ceil(e.w / cell).toInt()
        val rows = ceil(e.h / cell).toInt()
        val t = e.t * e.speed
        p.style = Paint.Style.FILL
        for (r in 0 until rows) {
            val cy = (r + 0.5f) * cell
            for (q in 0 until cols) {
                val cx = (q + 0.5f) * cell
                var v = sin(cx / (70f * e.dp) + t) + sin(cy / (55f * e.dp) - t * 1.3f) +
                    sin((cx + cy) / (90f * e.dp) + t * 0.7f) +
                    sin(hypot(cx - e.w / 2f, cy - e.h / 2f) / (70f * e.dp) - t)
                if (e.touching && e.touchOn) {
                    val d = hypot(cx - e.tx, cy - e.ty) / e.radius
                    v += e.dir * 3f * exp(-d * d)
                }
                val nv = ((v + 4f) / 8f).coerceIn(0f, 1f)
                hsv[0] = ((e.hue + nv * 80f) % 360f + 360f) % 360f
                hsv[1] = e.sat
                hsv[2] = 0.2f + 0.7f * nv
                p.color = Color.HSVToColor(hsv)
                c.drawRect(q * cell, r * cell, (q + 1) * cell + 1f, (r + 1) * cell + 1f, p)
            }
        }
    }
}

// ---------- Black hole ----------
class BlackHole(e: Env) : Scene(e) {
    override val touchSound: String? = "whoosh"
    private val cap = 400
    private val rad = FloatArray(cap)
    private val ang = FloatArray(cap)
    private val sz = FloatArray(cap)
    private var n = 0
    private var hx = 0f
    private var hy = 0f

    private fun rmax() = min(e.w, e.h) * 0.5f

    private fun respawn(i: Int, initial: Boolean) {
        rad[i] = if (initial) rf(0.15f, 1f) * rmax() else rf(0.85f, 1f) * rmax()
        ang[i] = rf(0f, 6.283f)
        sz[i] = rf(0.8f, 2.2f)
    }

    override fun reset() {
        n = (300 * e.amount).toInt().coerceIn(80, cap)
        for (i in 0 until n) respawn(i, true)
        hx = e.w / 2f; hy = e.h / 2f
    }

    override fun update(dt: Float) {
        val cx = e.w / 2f
        val cy = e.h / 2f
        var tx = cx
        var ty = cy
        if (e.touching && e.touchOn) {
            tx = cx + (e.tx - cx) * 0.35f * e.dir
            ty = cy + (e.ty - cy) * 0.35f * e.dir
        }
        val sm = min(1f, 4f * dt)
        hx += (tx - hx) * sm
        hy += (ty - hy) * sm
        val holeR = 34f * e.dp
        val r0 = rmax() * 0.3f
        for (i in 0 until n) {
            val om = (1.4f * (r0 / rad[i]).pow(1.5f)).coerceAtMost(6f)
            ang[i] += om * dt * e.speed
            rad[i] -= (8f * e.dp + 30f * e.dp * (r0 / rad[i])) * dt * e.speed
            if (rad[i] < holeR * 0.9f) respawn(i, false)
        }
    }

    private fun drawParticles(c: Canvas, back: Boolean) {
        p.style = Paint.Style.FILL
        val rm = rmax()
        val cr = Color.red(e.color)
        val cg = Color.green(e.color)
        val cb = Color.blue(e.color)
        for (i in 0 until n) {
            val sa = sin(ang[i])
            if ((sa < 0f) != back) continue
            val t = (1f - rad[i] / rm).coerceIn(0f, 1f)
            p.color = Color.argb(
                (120 + t * 135).toInt(),
                (cr + (255 - cr) * t).toInt(), (cg + (240 - cg) * t).toInt(), (cb + (200 - cb) * t).toInt()
            )
            c.drawCircle(hx + cos(ang[i]) * rad[i], hy + sa * rad[i] * 0.38f, sz[i] * e.dp, p)
        }
    }

    override fun draw(c: Canvas) {
        val holeR = 34f * e.dp
        c.save()
        c.rotate(-18f, hx, hy)
        drawParticles(c, true)
        val gr = holeR * 2.4f
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            hx, hy, gr,
            intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(170, 255, 225, 170), Color.argb(0, 255, 200, 120)),
            floatArrayOf(0.3f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(hx, hy, gr, p)
        p.shader = null
        p.color = Color.BLACK
        c.drawCircle(hx, hy, holeR, p)
        drawParticles(c, false)
        c.restore()
    }
}

// ---------- Lissajous ----------
class Lissajous(e: Env) : Scene(e) {
    override val touchSound: String? = "chime"
    private var cx = 0f
    private var cy = 0f
    private val path = Path()

    override fun reset() { cx = e.w / 2f; cy = e.h / 2f }

    override fun update(dt: Float) {
        var tx = e.w / 2f
        var ty = e.h / 2f
        if (e.touching && e.touchOn) {
            tx += (e.tx - tx) * 0.5f * e.dir
            ty += (e.ty - ty) * 0.5f * e.dir
        }
        val sm = min(1f, 4f * dt)
        cx += (tx - cx) * sm
        cy += (ty - cy) * sm
    }

    override fun draw(c: Canvas) {
        val aa = e.w * 0.42f
        val bb = e.h * 0.3f
        val fb = 2f + 0.15f * sin(e.t * 0.2f * e.speed)
        val delta = e.t * 0.5f * e.speed
        val widths = floatArrayOf(7f, 3.5f, 1.8f)
        val alphas = intArrayOf(30, 70, 230)
        p.style = Paint.Style.STROKE
        for (layer in 0 until 3) {
            path.reset()
            for (i in 0..360) {
                val tt = i / 360f * 6.283f
                val x = cx + aa * sin(3f * tt + delta + layer * 0.06f)
                val y = cy + bb * sin(fb * tt)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            p.strokeWidth = widths[layer] * e.dp
            p.color = col(alphas[layer])
            c.drawPath(path, p)
        }
    }
}

// ---------- Moonlight ----------
class Moonlight(e: Env) : Scene(e) {
    override val touchSound: String? = "whoosh"
    private val stars = StarField(130)
    private val cloudX = FloatArray(4)
    private val cloudY = FloatArray(4)
    private val cloudR = FloatArray(4)
    private var sx = 0f
    private var sy = 0f
    private var svx = 0f
    private var svy = 0f
    private var sAlive = false
    private var sTimer = 4f

    override fun reset() {
        for (i in 0 until 4) {
            cloudX[i] = rf(0f, e.w.toFloat())
            cloudY[i] = rf(0.1f, 0.6f) * e.h
            cloudR[i] = rf(120f, 220f) * e.dp
        }
        sAlive = false
        sTimer = rf(3f, 7f)
    }

    private fun launch(x: Float, y: Float) {
        sAlive = true
        sx = x; sy = y
        val sp = rf(700f, 1000f) * e.dp
        val a = rf(2.3f, 2.6f)
        svx = cos(a) * sp; svy = sin(a) * sp
        e.sound("whoosh", 0.2f, rf(1.2f, 1.8f))
    }

    override fun update(dt: Float) {
        for (i in 0 until 4) {
            cloudX[i] += (8f + i * 4f) * e.dp * dt * e.speed
            if (cloudX[i] > e.w + cloudR[i] * 1.5f) cloudX[i] = -cloudR[i] * 1.5f
        }
        sTimer -= dt
        if (sTimer <= 0f && !sAlive) { launch(rf(0.4f, 1f) * e.w, rf(0f, 0.2f) * e.h); sTimer = rf(5f, 12f) }
        if (justTouched && e.touchOn) launch(e.tx, e.ty)
        if (sAlive) {
            sx += svx * dt; sy += svy * dt
            if (sx < -100f || sy > e.h + 100f) sAlive = false
        }
    }

    override fun draw(c: Canvas) {
        stars.draw(c, p, e)
        val mr = e.w * 0.15f
        val mx = e.w * 0.72f
        val my = e.h * 0.2f
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(mx, my, mr * 3.2f, Color.argb(80, 255, 246, 220), Color.argb(0, 255, 246, 220), Shader.TileMode.CLAMP)
        c.drawCircle(mx, my, mr * 3.2f, p)
        p.shader = RadialGradient(mx - mr * 0.3f, my - mr * 0.3f, mr * 1.4f, Color.rgb(255, 250, 235), Color.rgb(215, 205, 180), Shader.TileMode.CLAMP)
        c.drawCircle(mx, my, mr, p)
        p.shader = null
        p.color = Color.argb(40, 90, 80, 60)
        c.drawCircle(mx - mr * 0.3f, my + mr * 0.2f, mr * 0.22f, p)
        c.drawCircle(mx + mr * 0.35f, my - mr * 0.25f, mr * 0.15f, p)
        c.drawCircle(mx + mr * 0.15f, my + mr * 0.5f, mr * 0.12f, p)
        c.drawCircle(mx - mr * 0.5f, my - mr * 0.4f, mr * 0.1f, p)
        for (i in 0 until 4) {
            c.save()
            c.translate(cloudX[i], cloudY[i])
            c.scale(1f, 0.32f)
            p.shader = RadialGradient(0f, 0f, cloudR[i], Color.argb(70, 200, 210, 230), Color.argb(0, 200, 210, 230), Shader.TileMode.CLAMP)
            c.drawCircle(0f, 0f, cloudR[i], p)
            p.shader = null
            c.restore()
        }
        if (sAlive) {
            p.style = Paint.Style.STROKE
            for (k in 0 until 7) {
                p.strokeWidth = (3f - k * 0.35f).coerceAtLeast(0.8f) * e.dp
                p.color = Color.argb(240 - k * 32, 255, 255, 255)
                c.drawLine(sx - svx * k * 0.018f, sy - svy * k * 0.018f, sx - svx * (k + 1) * 0.018f, sy - svy * (k + 1) * 0.018f, p)
            }
        }
    }
}

// ---------- DNA helix ----------
class Dna(e: Env) : Scene(e) {
    private var bump = 0f
    private var lx = 0f
    private var ly = 0f

    override fun reset() { bump = 0f }

    override fun update(dt: Float) {
        val on = e.touching && e.touchOn
        if (on) { lx = e.tx; ly = e.ty }
        bump += ((if (on) 1f else 0f) - bump) * min(1f, 5f * dt)
    }

    override fun draw(c: Canvas) {
        val cx = e.w / 2f
        val aa = e.w * 0.22f
        val step = 16f * e.dp
        var y = -step
        var idx = 0
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * e.dp
        while (y < e.h + step) {
            val ph = y / (70f * e.dp) + e.t * 1.2f * e.speed
            var off = 0f
            if (bump > 0.01f) {
                val dyy = (y - ly) / (e.radius * 1.2f)
                off = (lx - cx) * exp(-dyy * dyy) * 0.8f * bump * e.dir
            }
            val s1 = sin(ph)
            val x1 = cx + off + s1 * aa
            val x2 = cx + off - s1 * aa
            val z = cos(ph)
            if (idx % 2 == 0) {
                p.style = Paint.Style.STROKE
                p.color = col(70)
                c.drawLine(x1, y, x2, y, p)
            }
            p.style = Paint.Style.FILL
            val r1 = (4.5f + 2.5f * z) * e.dp
            val r2 = (4.5f - 2.5f * z) * e.dp
            if (z > 0f) {
                p.color = hcol(140f, 230); c.drawCircle(x2, y, r2, p)
                p.color = hcol(0f, 230); c.drawCircle(x1, y, r1, p)
            } else {
                p.color = hcol(0f, 230); c.drawCircle(x1, y, r1, p)
                p.color = hcol(140f, 230); c.drawCircle(x2, y, r2, p)
            }
            y += step
            idx++
        }
    }
}
