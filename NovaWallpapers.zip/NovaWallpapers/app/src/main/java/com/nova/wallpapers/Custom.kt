package com.nova.wallpapers

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** User-added backgrounds: images (with optional effect on top) and videos. */
object Custom {
    class Item(val id: String, val type: String, val name: String, val overlay: String)

    // overlays that look good on top of a photo
    val overlays = listOf(
        "none" to "None", "constellation" to "Stars & lines", "snow" to "Snow", "rain" to "Rain",
        "fireflies" to "Fireflies", "bubbles" to "Bubbles", "petals" to "Petals", "meteors" to "Meteors",
        "hearts" to "Hearts", "confetti" to "Confetti", "embers" to "Embers", "dust" to "Dust"
    )

    fun list(prefs: SharedPreferences): List<Item> {
        val raw = prefs.getString("customs", "") ?: ""
        return raw.split("\n").mapNotNull { line ->
            val p = line.split("|")
            if (p.size >= 4) Item(p[0], p[1], p[2], p[3]) else null
        }
    }

    fun save(prefs: SharedPreferences, items: List<Item>) {
        prefs.edit().putString("customs", items.joinToString("\n") { "${it.id}|${it.type}|${it.name}|${it.overlay}" }).apply()
    }

    fun file(storeCtx: Context, it: Item): File =
        File(storeCtx.filesDir, "c_${it.id}." + (if (it.type == "v") "mp4" else "jpg"))

    fun decode(f: File, maxW: Int, maxH: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(f.absolutePath, o)
            var s = 1
            while (o.outWidth / (s * 2) >= maxW && o.outHeight / (s * 2) >= maxH) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            BitmapFactory.decodeFile(f.absolutePath, o2)
        } catch (_: Throwable) {
            null
        }
    }

    fun videoThumb(f: File): Bitmap? {
        return try {
            val r = MediaMetadataRetriever()
            r.setDataSource(f.absolutePath)
            val b = r.getFrameAtTime(1_000_000L)
            r.release()
            b
        } catch (_: Throwable) {
            null
        }
    }

    private fun newId() = System.currentTimeMillis().toString(36)

    fun addImage(app: Context, uri: Uri, name: String): Item? {
        return try {
            val cr = app.contentResolver
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > 2400 || o.outHeight / s > 2400) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
            var rot = 0
            try {
                cr.openInputStream(uri)?.use {
                    val ex = ExifInterface(it)
                    rot = when (ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                        6 -> 90
                        3 -> 180
                        8 -> 270
                        else -> 0
                    }
                }
            } catch (_: Throwable) {
            }
            if (rot != 0) {
                val m = Matrix()
                m.postRotate(rot.toFloat())
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            val item = Item(newId(), "i", name.replace("|", " ").replace("\n", " "), "none")
            FileOutputStream(file(Store.ctx(app), item)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            bmp.recycle()
            item
        } catch (_: Throwable) {
            null
        }
    }

    /** Returns null when the file is too big or cannot be copied. */
    fun addVideo(app: Context, uri: Uri, name: String): Item? {
        val item = Item(newId(), "v", name.replace("|", " ").replace("\n", " "), "none")
        val f = file(Store.ctx(app), item)
        return try {
            var total = 0L
            app.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(f).use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > 150L * 1024 * 1024) throw IllegalStateException("too big")
                        out.write(buf, 0, n)
                    }
                }
            } ?: return null
            item
        } catch (_: Throwable) {
            f.delete()
            null
        }
    }

    fun delete(app: Context, prefs: SharedPreferences, id: String) {
        val items = list(prefs)
        items.firstOrNull { it.id == id }?.let { file(Store.ctx(app), it).delete() }
        save(prefs, items.filter { it.id != id })
        if (prefs.getString("scene", "") == "c:$id") prefs.edit().putString("scene", "constellation").apply()
        if (prefs.getString("video_id", "") == id) prefs.edit().remove("video_id").apply()
    }
}

/** Shows the user's picture slowly moving, with an optional effect scene on top. */
class CustomImageScene(e: Env, private var bmp: Bitmap?, private val overlay: Scene?) : Scene(e) {
    private val m = Matrix()
    private var px = 0f
    private var py = 0f

    override fun reset() {}

    override fun update(dt: Float) {
        var tx = 0f
        var ty = 0f
        if (e.touching && e.touchOn) {
            tx = (e.tx - e.w / 2f) / e.w * -0.04f * e.dir
            ty = (e.ty - e.h / 2f) / e.h * -0.03f * e.dir
        }
        val k = min(1f, 3f * dt)
        px += (tx - px) * k
        py += (ty - py) * k
        overlay?.step(dt)
    }

    override fun draw(c: Canvas) {
        val b = bmp ?: return
        val sc = max(e.w.toFloat() / b.width, e.h.toFloat() / b.height) * 1.12f
        val ox = (e.w - b.width * sc) / 2f + sin(e.t * 0.12f * e.speed) * e.w * 0.025f + px * e.w
        val oy = (e.h - b.height * sc) / 2f + cos(e.t * 0.09f * e.speed) * e.h * 0.015f + py * e.h
        m.reset()
        m.postScale(sc, sc)
        m.postTranslate(ox, oy)
        p.isFilterBitmap = true
        c.drawBitmap(b, m, p)
        overlay?.renderOver(c)
    }

    override fun release() {
        try { bmp?.recycle() } catch (_: Throwable) { }
        bmp = null
    }
}
