package com.nova.wallpapers

import android.media.MediaPlayer
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

/** Plays a video the user added as a (muted, looping) live wallpaper. */
class VideoWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = VideoEngine()

    inner class VideoEngine : Engine() {
        private var mp: MediaPlayer? = null
        private var prepared = false
        private var shown = false

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            begin(holder)
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            end()
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            end()
            super.onDestroy()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            shown = visible
            try {
                val p = mp
                if (p != null && prepared) {
                    if (visible) p.start() else if (p.isPlaying) p.pause()
                }
            } catch (_: Exception) {
            }
        }

        private fun begin(holder: SurfaceHolder) {
            end()
            try {
                val prefs = Store.prefs(this@VideoWallpaperService)
                val id = prefs.getString("video_id", null) ?: return
                val item = Custom.list(prefs).firstOrNull { it.id == id && it.type == "v" } ?: return
                val f = Custom.file(Store.ctx(this@VideoWallpaperService), item)
                if (!f.exists()) return
                val p = MediaPlayer()
                p.setDataSource(f.absolutePath)
                p.setSurface(holder.surface)
                p.isLooping = true
                p.setVolume(0f, 0f)
                p.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING)
                p.setOnPreparedListener {
                    prepared = true
                    if (shown) try { it.start() } catch (_: Exception) { }
                }
                p.setOnErrorListener { _, _, _ -> true }
                p.prepareAsync()
                mp = p
            } catch (_: Throwable) {
            }
        }

        private fun end() {
            try { mp?.release() } catch (_: Exception) { }
            mp = null
            prepared = false
        }
    }
}
