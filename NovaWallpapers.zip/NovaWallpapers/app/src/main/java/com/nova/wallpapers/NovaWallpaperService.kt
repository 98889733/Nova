package com.nova.wallpapers

import android.app.ActivityManager
import android.app.WallpaperManager
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.sqrt

object Prefs {
    const val NAME = "nova_wallpapers"
}

/** Settings live in device-protected storage so the wallpaper also works right after a reboot, before unlock. */
object Store {
    fun ctx(c: Context): Context =
        if (Build.VERSION.SDK_INT >= 24) c.createDeviceProtectedStorageContext() else c

    fun prefs(c: Context): SharedPreferences = ctx(c).getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)

    fun migrate(c: Context) {
        if (Build.VERSION.SDK_INT < 24) return
        try {
            val dp = prefs(c)
            if (dp.all.isNotEmpty()) return
            val old = c.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
            if (old.all.isEmpty()) return
            val ed = dp.edit()
            for ((k, v) in old.all) {
                when (v) {
                    is Boolean -> ed.putBoolean(k, v)
                    is Int -> ed.putInt(k, v)
                    is String -> ed.putString(k, v)
                    is Float -> ed.putFloat(k, v)
                    is Long -> ed.putLong(k, v)
                    else -> {}
                }
            }
            ed.apply()
        } catch (_: Exception) {
        }
    }
}

class NovaWallpaperService : WallpaperService() {
    private var sfx: Sfx? = null

    override fun onCreate() {
        super.onCreate()
        try {
            sfx = Sfx(Store.ctx(this)).also { it.start() }
        } catch (_: Throwable) {
        }
    }

    override fun onDestroy() {
        try { sfx?.release() } catch (_: Throwable) { }
        super.onDestroy()
    }

    override fun onCreateEngine(): Engine = NovaEngine()

    inner class NovaEngine : Engine(), SharedPreferences.OnSharedPreferenceChangeListener {
        private val env = Env()
        private var scene: Scene? = null
        private var sceneId = ""
        private var amountKey = -1
        private var baseAmount = 1f
        private var visible = false
        private var fingerDown = false
        private var tapUntil = 0L
        private var lastNs = 0L
        private var fps30 = false
        private var rainbow = false
        private var errors = 0

        // lag protection
        private var adaptive = true
        private var lowEnd = false
        private var forceFull = false
        private var tier = 0
        private var floorTier = 0
        private var quality = 1f
        private var gapEma = 16f
        private var workEma = 4f
        private var badMs = 0f
        private var goodMs = 0f
        private var lastCbNs = 0L
        private var envCheckMs = 0f
        private val tierCapMs = longArrayOf(0L, 28L, 45L, 95L)
        private val tierQuality = floatArrayOf(1f, 0.7f, 0.5f, 0.3f)
        private val pm: PowerManager? = try { this@NovaWallpaperService.getSystemService(Context.POWER_SERVICE) as PowerManager } catch (_: Throwable) { null }

        private val sm: SensorManager? = try { this@NovaWallpaperService.getSystemService(Context.SENSOR_SERVICE) as SensorManager } catch (_: Throwable) { null }
        private val accel: Sensor? = try { sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) } catch (_: Throwable) { null }
        private var sensing = false
        private val sl = object : SensorEventListener {
            override fun onSensorChanged(ev: SensorEvent) {
                val ax = ev.values[0]
                val ay = ev.values[1]
                @Suppress("DEPRECATION")
                val rot = (this@NovaWallpaperService.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
                val gx: Float
                val gy: Float
                when (rot) {
                    Surface.ROTATION_90 -> { gx = ay; gy = ax }
                    Surface.ROTATION_180 -> { gx = ax; gy = -ay }
                    Surface.ROTATION_270 -> { gx = -ay; gy = -ax }
                    else -> { gx = -ax; gy = ay }
                }
                val m = sqrt(gx * gx + gy * gy)
                if (m > 2.5f) { env.gx = gx / m; env.gy = gy / m }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        private var baseHue = 200f
        private var autoSec = 0
        private var autoId: String? = null
        private var lastPrefId = ""
        private var lastAutoMs = 0L
        private var lastAmb = 1f
        private var customSig = 0
        private val autoOpts = intArrayOf(0, -1, 60, 300, 900, 1800, 3600)
        private val prefs = Store.prefs(this@NovaWallpaperService)
        private val choreo = Choreographer.getInstance()
        private val cb = Choreographer.FrameCallback { ns -> frame(ns) }

        private fun updateSensing() {
            val want = visible && sceneId == "water" && env.phys == 2 && accel != null
            try {
                if (want && !sensing) {
                    sm?.registerListener(sl, accel, SensorManager.SENSOR_DELAY_GAME)
                    sensing = true
                } else if (!want && sensing) {
                    sm?.unregisterListener(sl)
                    sensing = false
                }
            } catch (_: Exception) {
            }
            if (!want) { env.gx = 0f; env.gy = 1f }
            updateAudio()
        }

        private fun updateAudio() {
            val s = sfx ?: return
            val a = Scenes.ambient[sceneId]
            if (visible && a != null) s.setLoop(this, a.first, a.second * env.amb) else s.clearLoop(this)
        }

        override fun onCreate(holder: SurfaceHolder) {
            super.onCreate(holder)
            setTouchEventsEnabled(true)
            env.dp = resources.displayMetrics.density
            env.snd = { n, v, r -> sfx?.play(n, v, r) }
            lastAutoMs = SystemClock.uptimeMillis()
            prefs.registerOnSharedPreferenceChangeListener(this)
            if (!isPreview) {
                try { prefs.edit().putBoolean("active", true).apply() } catch (_: Exception) { }
            }
            try {
                val am = this@NovaWallpaperService.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                lowEnd = am.isLowRamDevice || mi.totalMem <= 4_700_000_000L
            } catch (_: Exception) { }
            try { loadPrefs() } catch (_: Exception) { }
            try { powerFloor() } catch (_: Exception) { }
        }

        override fun onDestroy() {
            visible = false
            updateSensing()
            choreo.removeFrameCallback(cb)
            prefs.unregisterOnSharedPreferenceChangeListener(this)
            try { scene?.release() } catch (_: Throwable) { }
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            env.w = width
            env.h = height
            try { rebuild() } catch (_: Throwable) { }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            updateSensing()
            choreo.removeFrameCallback(cb)
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            choreo.removeFrameCallback(cb)
            if (visible) {
                try { loadPrefs() } catch (_: Exception) { }
                try { powerFloor() } catch (_: Exception) { }
                if (autoSec == -1) autoSwitch()
                updateSensing()
                lastNs = 0L
                lastCbNs = 0L
                choreo.postFrameCallback(cb)
            } else {
                updateAudio()
            }
        }

        override fun onTouchEvent(event: MotionEvent) {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    fingerDown = true
                    env.tx = event.x
                    env.ty = event.y
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> fingerDown = false
            }
        }

        override fun onCommand(
            action: String?, x: Int, y: Int, z: Int, extras: Bundle?, resultRequested: Boolean
        ): Bundle? {
            if (action == WallpaperManager.COMMAND_TAP || action == WallpaperManager.COMMAND_DROP) {
                env.tx = x.toFloat()
                env.ty = y.toFloat()
                tapUntil = SystemClock.uptimeMillis() + 700L
            }
            return null
        }

        override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
            try { loadPrefs() } catch (_: Exception) { }
        }

        private fun loadPrefs() {
            val dm = resources.displayMetrics
            baseHue = prefs.getInt("hue", 200).toFloat().coerceIn(0f, 359.9f)
            env.hue = baseHue
            env.sat = prefs.getInt("sat", 70) / 100f
            env.color = Color.HSVToColor(floatArrayOf(baseHue, env.sat, 1f))
            rainbow = prefs.getBoolean("rainbow", false)
            env.speed = 0.3f + prefs.getInt("speed", 50) / 100f * 1.4f
            val amt = prefs.getInt("amount", 50)
            baseAmount = 0.3f + amt / 100f * 1.4f
            env.amount = baseAmount * quality
            when (prefs.getString("mode", "attract")) {
                "repel" -> { env.touchOn = true; env.dir = -1f }
                "off" -> { env.touchOn = false; env.dir = 1f }
                else -> { env.touchOn = true; env.dir = 1f }
            }
            val cm = prefs.getInt("radius", 25) / 10f
            env.radius = cm / 2.54f * ((dm.xdpi + dm.ydpi) / 2f)
            env.bounce = prefs.getBoolean("bounce", false)
            env.ring = prefs.getBoolean("ring", false)
            env.dim = prefs.getInt("dim", 0) / 100f
            fps30 = prefs.getBoolean("fps30", false)
            WaterPrefs.apply(env, prefs)
            sfx?.configure(prefs.getBoolean("sound", true), prefs.getInt("vol", 50) / 100f)
            adaptive = prefs.getBoolean("adaptive", true)
            forceFull = prefs.getBoolean("forcefull", false)
            if (!adaptive && tier != 0) setTier(0)
            autoSec = autoOpts[prefs.getInt("auto", 0).coerceIn(0, autoOpts.size - 1)]
            val prefId = prefs.getString("scene", "constellation") ?: "constellation"
            if (prefId != lastPrefId) { lastPrefId = prefId; autoId = null }
            if (autoSec == 0) autoId = null
            val id = autoId ?: prefId
            val cs = prefs.getString("customs", "")?.hashCode() ?: 0
            val customChanged = id.startsWith("c:") && cs != customSig
            customSig = cs
            if (id != sceneId || amt != amountKey || scene == null || customChanged) {
                sceneId = id
                amountKey = amt
                rebuild()
            }
            updateSensing()
        }

        private fun autoSwitch() {
            lastAutoMs = SystemClock.uptimeMillis()
            val ids = Scenes.list.map { it.first }.filter { it != sceneId }
            autoId = ids.random()
            sceneId = autoId!!
            rebuild()
        }

        private fun rebuild() {
            if (env.w > 1 && env.h > 1) {
                env.amb = 1f
                lastAmb = 1f
                try { scene?.release() } catch (_: Throwable) { }
                scene = try {
                    if (sceneId.startsWith("c:")) createCustom(sceneId.substring(2)) else Scenes.create(sceneId, env)
                } catch (_: Throwable) {
                    try { Scenes.create("constellation", env) } catch (_: Throwable) { null }
                }
            }
            updateSensing()
        }

        private fun createCustom(id: String): Scene {
            val item = Custom.list(prefs).firstOrNull { it.id == id && it.type == "i" }
                ?: return Scenes.create("constellation", env)
            val bmp = Custom.decode(Custom.file(Store.ctx(this@NovaWallpaperService), item), env.w, env.h)
                ?: return Scenes.create("constellation", env)
            val ov = if (item.overlay != "none") Scenes.create(item.overlay, env) else null
            val sc = CustomImageScene(env, bmp, ov)
            sc.reset()
            return sc
        }

        // ---------- lag protection ----------
        private fun setTier(t: Int) {
            val nt = t.coerceIn(0, 3)
            if (nt == tier) return
            tier = nt
            quality = tierQuality[nt]
            env.quality = quality
            env.amount = baseAmount * quality
            gapEma = 16f
            workEma = 5f
            badMs = 0f
            goodMs = 0f
            rebuild()
        }

        private fun powerFloor() {
            var f = 0
            try {
                if (pm?.isPowerSaveMode == true) f = 1
                if (Build.VERSION.SDK_INT >= 29) {
                    val th = pm?.currentThermalStatus ?: 0
                    if (th >= PowerManager.THERMAL_STATUS_SEVERE) f = 3
                    else if (th >= PowerManager.THERMAL_STATUS_MODERATE) f = max(f, 2)
                }
            } catch (_: Exception) {
            }
            if (lowEnd && !forceFull) f = max(f, 1)
            if (!adaptive) f = 0
            floorTier = f
            if (tier < f) setTier(f)
        }

        private fun perf(gapMs: Float, workMs: Float) {
            if (!adaptive) return
            gapEma += (gapMs - gapEma) * 0.05f
            if (workMs >= 0f) workEma += (workMs - workEma) * 0.05f
            val bad = gapEma > 26f || workEma > 13f
            val good = gapEma < 20f && workEma < 5f
            if (bad) {
                badMs += gapMs
                goodMs = 0f
            } else {
                badMs = 0f
                if (good) goodMs += gapMs else goodMs = 0f
            }
            if (badMs > 2000f && tier < 3) setTier(tier + 1)
            else if (goodMs > 45000f && tier > floorTier) setTier(tier - 1)
        }

        private fun frame(ns: Long) {
            if (!visible) return
            val gapMs = if (lastCbNs == 0L) 16f else ((ns - lastCbNs) / 1e6f).coerceAtMost(500f)
            lastCbNs = ns
            envCheckMs += gapMs
            if (envCheckMs > 4000f) {
                envCheckMs = 0f
                powerFloor()
            }
            val capMs = max(if (fps30) 28L else 0L, tierCapMs[tier])
            if (lastNs != 0L && ns - lastNs < capMs * 1_000_000L - 2_000_000L) {
                perf(gapMs, -1f)
                choreo.postFrameCallback(cb)
                return
            }
            val dtMax = if (tier >= 2) 0.1f else 0.05f
            val dt = if (lastNs == 0L) 0.016f else ((ns - lastNs) / 1e9f).coerceAtMost(dtMax)
            lastNs = ns
            val w0 = System.nanoTime()
            env.t += dt
            if (rainbow) {
                env.hue = (baseHue + env.t * 25f) % 360f
                env.color = Color.HSVToColor(floatArrayOf(env.hue, env.sat, 1f))
            }
            if (autoSec > 0 && SystemClock.uptimeMillis() - lastAutoMs > autoSec * 1000L) autoSwitch()
            env.touching = fingerDown || SystemClock.uptimeMillis() < tapUntil
            val s = scene
            if (s != null) {
                try {
                    s.step(dt)
                    drawScene(s)
                    errors = 0
                } catch (_: Throwable) {
                    errors++
                    if (errors > 3) {
                        errors = 0
                        scene = try { Scenes.create("constellation", env) } catch (_: Throwable) { null }
                    }
                }
                if (kotlin.math.abs(env.amb - lastAmb) > 0.04f) {
                    lastAmb = env.amb
                    val a = Scenes.ambient[sceneId]
                    if (a != null) sfx?.setLevel(a.second * env.amb)
                }
            }
            perf(gapMs, (System.nanoTime() - w0) / 1e6f)
            choreo.postFrameCallback(cb)
        }

        private fun drawScene(s: Scene) {
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = if (Build.VERSION.SDK_INT >= 26) holder.lockHardwareCanvas() else holder.lockCanvas()
                if (c != null) s.render(c)
            } catch (_: Exception) {
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c) } catch (_: Exception) {}
                }
            }
        }
    }
}
