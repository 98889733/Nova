package com.nova.wallpapers

import android.app.WallpaperManager
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.WindowManager
import kotlin.math.sqrt

object Prefs {
    const val NAME = "nova_wallpapers"
}

class NovaWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = NovaEngine()

    inner class NovaEngine : Engine(), SharedPreferences.OnSharedPreferenceChangeListener {
        private val env = Env()
        private var scene: Scene? = null
        private var sceneId = ""
        private var amountKey = -1
        private var visible = false
        private var fingerDown = false
        private var tapUntil = 0L
        private var lastNs = 0L
        private var fps30 = false
        private var rainbow = false
        private val sm = this@NovaWallpaperService.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        private val accel: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        private var sensing = false
        private val sl = object : SensorEventListener {
            override fun onSensorChanged(ev: SensorEvent) {
                val ax = ev.values[0]
                val ay = ev.values[1]
                @Suppress("DEPRECATION")
                val rot = (this@NovaWallpaperService.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
                val gx: Float
                val gy: Float
                when (rot) {
                    Surface.ROTATION_90 -> { gx = ay; gy = ax }
                    Surface.ROTATION_180 -> { gx = ax; gy = -ay }
                    Surface.ROTATION_270 -> { gx = -ay; gy = -ax }
                    else -> { gx = -ax; gy = ay }
                }
                val m = sqrt(gx * gx + gy * gy)
                if (m > 2.5f) { env.gx = gx / m; env.gy = gy / m }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        private fun updateSensing() {
            val want = visible && sceneId == "water" && env.phys == 2 && accel != null
            if (want && !sensing) {
                sm.registerListener(sl, accel, SensorManager.SENSOR_DELAY_GAME)
                sensing = true
            } else if (!want && sensing) {
                sm.unregisterListener(sl)
                sensing = false
            }
            if (!want) { env.gx = 0f; env.gy = 1f }
        }

        private var baseHue = 200f
        private var autoSec = 0
        private var autoId: String? = null
        private var lastPrefId = ""
        private var lastAutoMs = 0L
        private val autoOpts = intArrayOf(0, -1, 60, 300, 900, 1800, 3600)
        private val prefs = getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        private val choreo = Choreographer.getInstance()
        private val cb = Choreographer.FrameCallback { ns -> frame(ns) }

        override fun onCreate(holder: SurfaceHolder) {
            super.onCreate(holder)
            setTouchEventsEnabled(true)
            env.dp = resources.displayMetrics.density
            lastAutoMs = SystemClock.uptimeMillis()
            prefs.registerOnSharedPreferenceChangeListener(this)
            loadPrefs()
        }

        override fun onDestroy() {
            visible = false
            updateSensing()
            choreo.removeFrameCallback(cb)
            prefs.unregisterOnSharedPreferenceChangeListener(this)
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            env.w = width
            env.h = height
            rebuild()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            updateSensing()
            choreo.removeFrameCallback(cb)
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            choreo.removeFrameCallback(cb)
            if (visible) {
                loadPrefs()
                if (autoSec == -1) autoSwitch()
                updateSensing()
                lastNs = 0L
                choreo.postFrameCallback(cb)
            }
        }

        override fun onTouchEvent(event: MotionEvent) {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    fingerDown = true
                    env.tx = event.x
                    env.ty = event.y
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> fingerDown = false
            }
        }

        override fun onCommand(
            action: String?, x: Int, y: Int, z: Int, extras: Bundle?, resultRequested: Boolean
        ): Bundle? {
            if (action == WallpaperManager.COMMAND_TAP || action == WallpaperManager.COMMAND_DROP) {
                env.tx = x.toFloat()
                env.ty = y.toFloat()
                tapUntil = SystemClock.uptimeMillis() + 700L
            }
            return null
        }

        override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
            loadPrefs()
        }

        private fun loadPrefs() {
            val dm = resources.displayMetrics
            baseHue = prefs.getInt("hue", 200).toFloat().coerceIn(0f, 359.9f)
            env.hue = baseHue
            env.sat = prefs.getInt("sat", 70) / 100f
            env.color = Color.HSVToColor(floatArrayOf(baseHue, env.sat, 1f))
            rainbow = prefs.getBoolean("rainbow", false)
            env.speed = 0.3f + prefs.getInt("speed", 50) / 100f * 1.4f
            val amt = prefs.getInt("amount", 50)
            env.amount = 0.3f + amt / 100f * 1.4f
            when (prefs.getString("mode", "attract")) {
                "repel" -> { env.touchOn = true; env.dir = -1f }
                "off" -> { env.touchOn = false; env.dir = 1f }
                else -> { env.touchOn = true; env.dir = 1f }
            }
            val cm = prefs.getInt("radius", 25) / 10f
            env.radius = cm / 2.54f * ((dm.xdpi + dm.ydpi) / 2f)
            env.bounce = prefs.getBoolean("bounce", false)
            env.ring = prefs.getBoolean("ring", false)
            env.dim = prefs.getInt("dim", 0) / 100f
            fps30 = prefs.getBoolean("fps30", false)
            WaterPrefs.apply(env, prefs)
            autoSec = autoOpts[prefs.getInt("auto", 0).coerceIn(0, autoOpts.size - 1)]
            val prefId = prefs.getString("scene", "constellation") ?: "constellation"
            if (prefId != lastPrefId) { lastPrefId = prefId; autoId = null }
            if (autoSec == 0) autoId = null
            val id = autoId ?: prefId
            if (id != sceneId || amt != amountKey || scene == null) {
                sceneId = id
                amountKey = amt
                rebuild()
            }
            updateSensing()
        }

        private fun autoSwitch() {
            lastAutoMs = SystemClock.uptimeMillis()
            val ids = Scenes.list.map { it.first }.filter { it != sceneId }
            autoId = ids.random()
            sceneId = autoId!!
            rebuild()
        }

        private fun rebuild() {
            if (env.w > 1 && env.h > 1) scene = Scenes.create(sceneId, env)
            updateSensing()
        }

        private fun frame(ns: Long) {
            if (!visible) return
            if (fps30 && lastNs != 0L && ns - lastNs < 28_000_000L) {
                choreo.postFrameCallback(cb)
                return
            }
            val dt = if (lastNs == 0L) 0.016f else ((ns - lastNs) / 1e9f).coerceAtMost(0.05f)
            lastNs = ns
            env.t += dt
            if (rainbow) {
                env.hue = (baseHue + env.t * 25f) % 360f
                env.color = Color.HSVToColor(floatArrayOf(env.hue, env.sat, 1f))
            }
            if (autoSec > 0 && SystemClock.uptimeMillis() - lastAutoMs > autoSec * 1000L) autoSwitch()
            env.touching = fingerDown || SystemClock.uptimeMillis() < tapUntil
            scene?.let { s ->
                s.update(dt)
                drawScene(s)
            }
            choreo.postFrameCallback(cb)
        }

        private fun drawScene(s: Scene) {
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = if (Build.VERSION.SDK_INT >= 26) holder.lockHardwareCanvas() else holder.lockCanvas()
                if (c != null) s.render(c)
            } catch (_: Exception) {
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c) } catch (_: Exception) {}
                }
            }
        }
    }
}
