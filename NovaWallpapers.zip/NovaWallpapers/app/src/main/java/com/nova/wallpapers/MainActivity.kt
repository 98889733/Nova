package com.nova.wallpapers

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var swatch: View
    private var dpi = 1f

    private fun px(v: Int) = (v * dpi).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        dpi = resources.displayMetrics.density

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(20), px(32), px(20), px(36))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.rgb(10, 12, 20))
        scroll.addView(root)
        setContentView(scroll)

        root.addView(label("NOVA Wallpapers", 26f, Color.WHITE, true))
        root.addView(label("Live wallpapers that react to your touch", 14f, Color.LTGRAY, false))

        val setBtn = Button(this)
        setBtn.text = "Set as wallpaper"
        setBtn.setOnClickListener { setWallpaper() }
        root.addView(setBtn, spaced(16))

        root.addView(label("Background", 18f, Color.WHITE, true), spaced(20))
        val cur = prefs.getString("scene", "constellation")
        val rg = RadioGroup(this)
        Scenes.list.forEachIndexed { i, pair ->
            val rb = RadioButton(this)
            rb.text = pair.second
            rb.textSize = 16f
            rb.id = 1000 + i
            rb.isChecked = pair.first == cur
            rg.addView(rb)
        }
        rg.setOnCheckedChangeListener { _, cid ->
            prefs.edit().putString("scene", Scenes.list[cid - 1000].first).apply()
        }
        root.addView(rg)

        root.addView(label("Touch reaction", 18f, Color.WHITE, true), spaced(20))
        val modes = listOf("attract" to "Fly to my finger", "repel" to "Fly away from my finger", "off" to "Off")
        val curMode = prefs.getString("mode", "attract")
        val mg = RadioGroup(this)
        modes.forEachIndexed { i, pair ->
            val rb = RadioButton(this)
            rb.text = pair.second
            rb.textSize = 16f
            rb.id = 2000 + i
            rb.isChecked = pair.first == curMode
            mg.addView(rb)
        }
        mg.setOnCheckedChangeListener { _, cid ->
            prefs.edit().putString("mode", modes[cid - 2000].first).apply()
        }
        root.addView(mg)
        root.addView(
            label("Tap or hold an empty spot on the home screen to trigger it.", 12f, Color.GRAY, false),
            spaced(4)
        )

        root.addView(label("Look", 18f, Color.WHITE, true), spaced(20))
        swatch = View(this)
        root.addView(swatch, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(22)))
        val rainbow = View(this)
        rainbow.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(
                Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED
            )
        )
        root.addView(rainbow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(10)))
        slider(root, "Color", "hue", 200, 360)
        slider(root, "Saturation (left = white)", "sat", 70, 100)
        slider(root, "Speed", "speed", 50, 100)
        slider(root, "Amount", "amount", 50, 100)

        val sw = Switch(this)
        sw.text = "Battery saver (30 FPS)"
        sw.isChecked = prefs.getBoolean("fps30", false)
        sw.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("fps30", v).apply() }
        root.addView(sw, spaced(20))

        updateSwatch()
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = size
        tv.setTextColor(color)
        if (bold) tv.setTypeface(tv.typeface, android.graphics.Typeface.BOLD)
        return tv
    }

    private fun spaced(top: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = px(top)
        return lp
    }

    private fun slider(parent: LinearLayout, title: String, key: String, def: Int, maxV: Int) {
        parent.addView(label(title, 14f, Color.LTGRAY, false), spaced(12))
        val sb = SeekBar(this)
        sb.max = maxV
        sb.progress = prefs.getInt(key, def)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                prefs.edit().putInt(key, value).apply()
                updateSwatch()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(sb)
    }

    private fun updateSwatch() {
        val h = prefs.getInt("hue", 200).toFloat().coerceIn(0f, 359.9f)
        val s = prefs.getInt("sat", 70) / 100f
        swatch.setBackgroundColor(Color.HSVToColor(floatArrayOf(h, s, 1f)))
    }

    private fun setWallpaper() {
        try {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            i.putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this, NovaWallpaperService::class.java)
            )
            startActivity(i)
        } catch (ex: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }
}
