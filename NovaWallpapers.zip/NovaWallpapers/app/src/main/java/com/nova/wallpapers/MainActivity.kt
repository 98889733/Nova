package com.nova.wallpapers

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private val tabViews = mutableListOf<TextView>()
    private var tab = 0
    private var dpi = 1f
    private val thumbCache = ConcurrentHashMap<String, Bitmap>()

    private val cBg1 = Color.parseColor("#060914")
    private val cBg2 = Color.parseColor("#0E1233")
    private val cCard = Color.parseColor("#151B3D")
    private val cCardSel = Color.parseColor("#1F2A63")
    private val cChip = Color.parseColor("#1D2550")
    private val cAccent = Color.parseColor("#6C8CFF")
    private val cAccent2 = Color.parseColor("#A068FF")
    private val cSub = Color.parseColor("#8F9ACB")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private fun px(v: Int) = (v * dpi).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        dpi = resources.displayMetrics.density
        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(cBg1, cBg2)))
        window.statusBarColor = cBg1
        window.navigationBarColor = cBg2

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(18), px(16), px(18), 0)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.BOTTOM
        val t1 = tv("NOVA", 32f, Color.WHITE, true)
        t1.letterSpacing = 0.15f
        val t2 = tv("  WALLPAPERS", 13f, cAccent, true)
        t2.letterSpacing = 0.2f
        t2.setPadding(0, 0, 0, px(6))
        head.addView(t1)
        head.addView(t2)
        root.addView(head)
        root.addView(tv("Live wallpapers that react to your touch", 13f, cSub, false), lp(top = 2))

        val set = tv("SET AS WALLPAPER", 15f, Color.WHITE, true)
        set.gravity = Gravity.CENTER
        set.letterSpacing = 0.1f
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cAccent, cAccent2))
        g.cornerRadius = px(16).toFloat()
        set.background = g
        set.setPadding(0, px(16), 0, px(16))
        set.setOnClickListener { setWallpaper() }
        root.addView(set, lp(top = 16))

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        listOf("Scenes", "Touch", "Color", "More").forEachIndexed { i, name ->
            val t = tv(name, 14f, cSub, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, px(11), 0, px(11))
            t.setOnClickListener { selectTab(i) }
            val par = LinearLayout.LayoutParams(0, WRAP, 1f)
            par.marginEnd = if (i < 3) px(6) else 0
            tabs.addView(t, par)
            tabViews.add(t)
        }
        root.addView(tabs, lp(top = 16))

        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(0, px(14), 0, px(40))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        selectTab(0)
    }

    // ---------- helpers ----------
    private fun lp(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(MATCH, WRAP)
        l.topMargin = px(top)
        l.bottomMargin = px(bottom)
        return l
    }

    private fun tv(t: String, size: Float, color: Int, bold: Boolean): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun bg(color: Int, radius: Int, strokeW: Int = 0, strokeC: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = px(radius).toFloat()
        if (strokeW > 0) g.setStroke(px(strokeW), strokeC)
        return g
    }

    private fun card(title: String, hint: String?): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.background = bg(cCard, 18)
        l.setPadding(px(16), px(14), px(16), px(16))
        l.addView(tv(title, 16f, Color.WHITE, true))
        if (hint != null) l.addView(tv(hint, 12f, cSub, false), lp(top = 2))
        return l
    }

    private fun selectTab(i: Int) {
        tab = i
        tabViews.forEachIndexed { k, t ->
            if (k == i) {
                val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cAccent, cAccent2))
                g.cornerRadius = px(12).toFloat()
                t.background = g
                t.setTextColor(Color.WHITE)
            } else {
                t.background = bg(cCard, 12)
                t.setTextColor(cSub)
            }
        }
        content.removeAllViews()
        when (i) {
            0 -> pageScenes()
            1 -> pageTouch()
            2 -> pageColor()
            else -> pageMore()
        }
        scroll.scrollTo(0, 0)
    }

    private fun slider(parent: LinearLayout, name: String, key: String, def: Int, minV: Int, maxV: Int, fmt: (Int) -> String) {
        val cur = prefs.getInt(key, def)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val v = tv(fmt(cur), 14f, cAccent, true)
        row.addView(tv(name, 14f, Color.WHITE, false), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(v)
        parent.addView(row, lp(top = 14))
        val sb = SeekBar(this)
        sb.max = maxV - minV
        sb.progress = cur - minV
        sb.progressTintList = ColorStateList.valueOf(cAccent)
        sb.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                val real = value + minV
                prefs.edit().putInt(key, real).apply()
                v.text = fmt(real)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(sb)
    }

    private fun switchRow(parent: LinearLayout, title: String, sub: String, key: String, def: Boolean) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(title, 14f, Color.WHITE, false))
        col.addView(tv(sub, 12f, cSub, false))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(this)
        sw.isChecked = prefs.getBoolean(key, def)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(cAccent, Color.GRAY))
        sw.trackTintList = ColorStateList(states, intArrayOf(Color.parseColor("#556CFF"), Color.parseColor("#333A66")))
        sw.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply() }
        row.addView(sw)
        parent.addView(row, lp(top = 14))
    }

    private fun chips(parent: LinearLayout, items: List<String>, cols: Int, selected: Int, onSel: (Int) -> Unit) {
        val views = mutableListOf<TextView>()
        fun restyle(sel: Int) {
            views.forEachIndexed { i, t ->
                if (i == sel) { t.background = bg(cAccent, 12); t.setTextColor(Color.WHITE) }
                else { t.background = bg(cChip, 12); t.setTextColor(cSub) }
            }
        }
        items.chunked(cols).forEachIndexed { r, rowItems ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            rowItems.forEachIndexed { k, label ->
                val idx = r * cols + k
                val t = tv(label, 13f, cSub, true)
                t.gravity = Gravity.CENTER
                t.setPadding(px(4), px(11), px(4), px(11))
                t.setOnClickListener { restyle(idx); onSel(idx) }
                views.add(t)
                val par = LinearLayout.LayoutParams(0, WRAP, 1f)
                par.marginEnd = px(6)
                row.addView(t, par)
            }
            repeat(cols - rowItems.size) { row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            parent.addView(row, lp(top = 10))
        }
        restyle(selected)
    }

    // ---------- pages ----------
    private fun renderThumb(id: String, hue: Int, sat: Int): Bitmap {
        val bmp = Bitmap.createBitmap(360, 225, Bitmap.Config.ARGB_8888)
        val env = Env()
        env.w = 720
        env.h = 450
        env.dp = 2.5f
        env.hue = hue.toFloat().coerceIn(0f, 359.9f)
        env.sat = sat / 100f
        env.color = Color.HSVToColor(floatArrayOf(env.hue, env.sat, 1f))
        env.radius = 300f
        env.touchOn = false
        val scene = Scenes.create(id, env)
        for (i in 0 until 50) {
            env.t += 0.05f
            scene.update(0.05f)
        }
        val c = Canvas(bmp)
        c.scale(0.5f, 0.5f)
        scene.render(c)
        return bmp
    }

    private fun pageScenes() {
        val cards = LinkedHashMap<String, LinearLayout>()
        val views = HashMap<String, ImageView>()
        var cur = prefs.getString("scene", "constellation") ?: "constellation"
        var banner: TextView? = null
        fun restyle() {
            cards.forEach { (id, l) ->
                l.background = if (id == cur) bg(cCardSel, 16, 2, cAccent) else bg(cCard, 16, 2, cCard)
            }
        }
        fun pick(id: String) {
            cur = id
            val ed = prefs.edit()
            if (prefs.getInt("auto", 0) != 0) {
                ed.putInt("auto", 0)
                banner?.visibility = View.GONE
                Toast.makeText(this, "Auto-change turned off", Toast.LENGTH_SHORT).show()
            }
            ed.putString("scene", id).apply()
            restyle()
        }

        if (prefs.getInt("auto", 0) != 0) {
            val bn = tv("Auto-change is ON, so the scene switches by itself. Tap to turn it off.", 12f, Color.WHITE, true)
            bn.background = bg(Color.parseColor("#3A2A7A"), 12, 1, cAccent2)
            bn.setPadding(px(12), px(10), px(12), px(10))
            bn.setOnClickListener {
                prefs.edit().putInt("auto", 0).apply()
                bn.visibility = View.GONE
            }
            banner = bn
            content.addView(bn, lp(bottom = 10))
        }

        val rnd = tv("RANDOM SCENE", 13f, Color.WHITE, true)
        rnd.gravity = Gravity.CENTER
        rnd.letterSpacing = 0.08f
        rnd.background = bg(cChip, 12)
        rnd.setPadding(0, px(12), 0, px(12))
        rnd.setOnClickListener { pick(Scenes.list.map { it.first }.filter { it != cur }.random()) }
        content.addView(rnd, lp())

        Scenes.list.chunked(2).forEach { pair ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            pair.forEachIndexed { k, t ->
                val l = LinearLayout(this)
                l.orientation = LinearLayout.VERTICAL
                l.setPadding(px(8), px(8), px(8), px(10))
                val iv = ImageView(this)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                iv.background = bg(Color.parseColor("#0B0F26"), 12)
                iv.clipToOutline = true
                l.addView(iv, LinearLayout.LayoutParams(MATCH, px(92)))
                views[t.first] = iv
                val nm = tv(t.second, 15f, Color.WHITE, true)
                nm.setPadding(px(4), 0, px(4), 0)
                l.addView(nm, lp(top = 8))
                val ds = tv(t.third, 11f, cSub, false)
                ds.setPadding(px(4), 0, px(4), 0)
                l.addView(ds, lp(top = 2))
                l.setOnClickListener { pick(t.first) }
                cards[t.first] = l
                val par = LinearLayout.LayoutParams(0, WRAP, 1f)
                if (k == 0) par.marginEnd = px(5) else par.marginStart = px(5)
                row.addView(l, par)
            }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            content.addView(row, lp(top = 10))
        }
        restyle()

        val hue = prefs.getInt("hue", 200)
        val sat = prefs.getInt("sat", 70)
        if (thumbCache.size > 34) thumbCache.clear()
        Thread {
            for (t in Scenes.list) {
                try {
                    val bmp = thumbCache.getOrPut("${t.first}-$hue-$sat") { renderThumb(t.first, hue, sat) }
                    runOnUiThread { views[t.first]?.setImageBitmap(bmp) }
                } catch (_: Exception) {
                }
            }
        }.start()
    }

    private fun pageTouch() {
        val c1 = card("Reaction", "What happens when you touch the wallpaper")
        val modes = listOf("attract", "repel", "off")
        chips(c1, listOf("Fly to finger", "Fly away", "Off"), 3, modes.indexOf(prefs.getString("mode", "attract")).coerceAtLeast(0)) {
            prefs.edit().putString("mode", modes[it]).apply()
        }
        content.addView(c1, lp())

        val c2 = card("Touch radius", "Only things inside this circle react to your finger")
        slider(c2, "Radius", "radius", 25, 5, 80) { "%.1f cm".format(it / 10f) }
        switchRow(c2, "Show touch circle", "Draws the radius under your finger", "ring", false)
        content.addView(c2, lp(top = 12))

        val c3 = card("Screen edges", null)
        switchRow(c3, "Keep inside the screen", "Objects bounce off the edges instead of flying out", "bounce", false)
        content.addView(c3, lp(top = 12))

        val c4 = card("Tip", "On the home screen tap or hold an empty spot to trigger the effect. On the lock screen and in the preview, dragging works too.")
        content.addView(c4, lp(top = 12))
    }

    private fun pageColor() {
        val c = card("Color wheel", "Drag on the wheel. Center is white, edge is full color.")
        val wheel = ColorWheel(this)
        wheel.hue = prefs.getInt("hue", 200).toFloat()
        wheel.sat = prefs.getInt("sat", 70) / 100f
        wheel.onPick = { h, s -> prefs.edit().putInt("hue", h.toInt()).putInt("sat", (s * 100).toInt()).apply() }
        val wp = LinearLayout.LayoutParams(px(260), px(260))
        wp.gravity = Gravity.CENTER_HORIZONTAL
        wp.topMargin = px(10)
        c.addView(wheel, wp)

        val sw = LinearLayout(this)
        sw.orientation = LinearLayout.HORIZONTAL
        val presets = listOf(0 to 0, 0 to 100, 28 to 100, 55 to 100, 130 to 90, 185 to 100, 225 to 90, 275 to 80, 325 to 80)
        presets.forEach { (h, s) ->
            val v = View(this)
            val gd = GradientDrawable()
            gd.shape = GradientDrawable.OVAL
            gd.setColor(Color.HSVToColor(floatArrayOf(h.toFloat(), s / 100f, 1f)))
            gd.setStroke(px(2), Color.parseColor("#33FFFFFF"))
            v.background = gd
            v.setOnClickListener {
                wheel.setColor(h.toFloat(), s / 100f)
                prefs.edit().putInt("hue", h).putInt("sat", s).apply()
            }
            val par = LinearLayout.LayoutParams(0, px(30), 1f)
            par.marginEnd = px(5)
            sw.addView(v, par)
        }
        c.addView(sw, lp(top = 14))
        content.addView(c, lp())

        val c2 = card("Rainbow", null)
        switchRow(c2, "Rainbow cycle", "Color slowly changes through the whole wheel", "rainbow", false)
        content.addView(c2, lp(top = 12))
    }

    private fun pageMore() {
        val c1 = card("Auto-change scene", "Switch to a random scene automatically")
        chips(c1, listOf("Off", "On unlock", "1 min", "5 min", "15 min", "30 min", "1 hour"), 4, prefs.getInt("auto", 0)) {
            prefs.edit().putInt("auto", it).apply()
        }
        content.addView(c1, lp())

        val c2 = card("Fine tuning", null)
        slider(c2, "Speed", "speed", 50, 0, 100) { "$it%" }
        slider(c2, "Amount", "amount", 50, 0, 100) { "$it%" }
        slider(c2, "Dim wallpaper", "dim", 0, 0, 80) { "$it%" }
        switchRow(c2, "Battery saver", "Limits animation to 30 FPS", "fps30", false)
        content.addView(c2, lp(top = 12))

        val reset = tv("RESET TO DEFAULTS", 13f, Color.WHITE, true)
        reset.gravity = Gravity.CENTER
        reset.letterSpacing = 0.08f
        reset.background = bg(cChip, 12)
        reset.setPadding(0, px(12), 0, px(12))
        reset.setOnClickListener {
            prefs.edit().clear().apply()
            Toast.makeText(this, "Settings reset", Toast.LENGTH_SHORT).show()
            selectTab(tab)
        }
        content.addView(reset, lp(top = 14))
        val foot = tv("NOVA Wallpapers 1.1", 11f, cSub, false)
        foot.gravity = Gravity.CENTER
        content.addView(foot, lp(top = 14))
    }

    private fun setWallpaper() {
        try {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            i.putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this, NovaWallpaperService::class.java)
            )
            startActivity(i)
        } catch (ex: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }
}
