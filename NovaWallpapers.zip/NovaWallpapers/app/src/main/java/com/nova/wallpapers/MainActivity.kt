package com.nova.wallpapers

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private val tabViews = mutableListOf<TextView>()
    private var tab = 0
    private val tabKinds = listOf("scenes", "touch", "color", "more")
    private var dpi = 1f
    private val thumbCache = ConcurrentHashMap<String, Bitmap>()

    private val cBg1 = Color.parseColor("#060914")
    private val cBg2 = Color.parseColor("#0E1233")
    private val cCard = Color.parseColor("#151B3D")
    private val cCardSel = Color.parseColor("#1F2A63")
    private val cChip = Color.parseColor("#1D2550")
    private val cAccent = Color.parseColor("#6C8CFF")
    private val cAccent2 = Color.parseColor("#A068FF")
    private val cSub = Color.parseColor("#8F9ACB")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private fun px(v: Int) = (v * dpi).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.migrate(this)
        prefs = Store.prefs(this)
        dpi = resources.displayMetrics.density
        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(cBg1, cBg2)))
        window.statusBarColor = cBg1
        window.navigationBarColor = cBg2

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(18), px(16), px(18), 0)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.BOTTOM
        val t1 = tv("NOVA", 32f, Color.WHITE, true)
        t1.letterSpacing = 0.15f
        val t2 = tv("  WALLPAPERS", 13f, cAccent, true)
        t2.letterSpacing = 0.2f
        t2.setPadding(0, 0, 0, px(6))
        head.addView(t1)
        head.addView(t2)
        head.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val snd = IconView(this, if (prefs.getBoolean("sound", true)) "sound" else "mute", cSub)
        snd.setOnClickListener {
            val on = !prefs.getBoolean("sound", true)
            prefs.edit().putBoolean("sound", on).apply()
            snd.set(if (on) "sound" else "mute", cSub)
            Toast.makeText(this, if (on) "Sound on" else "Sound off", Toast.LENGTH_SHORT).show()
        }
        head.addView(snd, LinearLayout.LayoutParams(px(30), px(30)))
        root.addView(head)
        root.addView(tv("Live wallpapers that react to your touch", 13f, cSub, false), lp(top = 2))

        val set = tv("SET AS WALLPAPER", 15f, Color.WHITE, true)
        set.gravity = Gravity.CENTER
        set.letterSpacing = 0.1f
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cAccent, cAccent2))
        g.cornerRadius = px(16).toFloat()
        set.background = g
        set.setPadding(0, px(16), 0, px(16))
        set.setOnClickListener { setWallpaper() }
        root.addView(set, lp(top = 16))

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        listOf("Scenes", "Touch", "Color", "More").forEachIndexed { i, name ->
            val t = tv(name, 14f, cSub, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, px(9), 0, px(9))
            t.compoundDrawablePadding = px(2)
            t.setOnClickListener { selectTab(i) }
            val par = LinearLayout.LayoutParams(0, WRAP, 1f)
            par.marginEnd = if (i < 3) px(6) else 0
            tabs.addView(t, par)
            tabViews.add(t)
        }
        root.addView(tabs, lp(top = 16))

        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(0, px(14), 0, px(40))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        selectTab(0)
        if (intent.getBooleanExtra("apply", false)) setWallpaper()
    }

    // ---------- helpers ----------
    private fun lp(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(MATCH, WRAP)
        l.topMargin = px(top)
        l.bottomMargin = px(bottom)
        return l
    }

    private fun tv(t: String, size: Float, color: Int, bold: Boolean): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun bg(color: Int, radius: Int, strokeW: Int = 0, strokeC: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = px(radius).toFloat()
        if (strokeW > 0) g.setStroke(px(strokeW), strokeC)
        return g
    }

    private fun card(title: String, hint: String?, icon: String? = null): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.background = bg(cCard, 18)
        l.setPadding(px(16), px(14), px(16), px(16))
        if (icon != null) {
            val hr = LinearLayout(this)
            hr.orientation = LinearLayout.HORIZONTAL
            hr.gravity = Gravity.CENTER_VERTICAL
            hr.addView(IconView(this, icon, cAccent), LinearLayout.LayoutParams(px(22), px(22)))
            val tt = tv(title, 16f, Color.WHITE, true)
            tt.setPadding(px(8), 0, 0, 0)
            hr.addView(tt)
            l.addView(hr)
        } else {
            l.addView(tv(title, 16f, Color.WHITE, true))
        }
        if (hint != null) l.addView(tv(hint, 12f, cSub, false), lp(top = 2))
        return l
    }

    private fun pill(text: String, onClick: () -> Unit): TextView {
        val t = tv(text, 13f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.letterSpacing = 0.06f
        t.background = bg(cChip, 12)
        t.setPadding(0, px(12), 0, px(12))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun askNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 7)
        }
    }

    private fun openAutostart() {
        val targets = listOf(
            "com.transsion.phonemaster" to "com.cyin.himgr.autostart.AutoStartActivity",
            "com.transsion.phonemaster" to "com.itel.autobootmanager.activity.AutoBootMgrActivity",
            "com.itel.autobootmanager" to "com.itel.autobootmanager.activity.AutoBootMgrActivity",
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"
        )
        for ((pkg, cls) in targets) {
            try {
                val i = Intent()
                i.setClassName(pkg, cls)
                startActivity(i)
                return
            } catch (_: Exception) {
            }
        }
        openSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, true)
    }

    private fun openSettings(action: String, withPackage: Boolean) {
        try {
            val i = Intent(action)
            if (withPackage) i.data = Uri.parse("package:$packageName")
            startActivity(i)
        } catch (ex: Exception) {
            Toast.makeText(this, "Not available on this phone", Toast.LENGTH_SHORT).show()
        }
    }

    private fun selectTab(i: Int) {
        tab = i
        tabViews.forEachIndexed { k, t ->
            if (k == i) {
                val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cAccent, cAccent2))
                g.cornerRadius = px(12).toFloat()
                t.background = g
                t.setTextColor(Color.WHITE)
            } else {
                t.background = bg(cCard, 12)
                t.setTextColor(cSub)
            }
            t.setCompoundDrawablesWithIntrinsicBounds(
                null, BitmapDrawable(resources, Icons.bitmap(this, tabKinds[k], if (k == i) Color.WHITE else cSub, px(22))), null, null
            )
        }
        content.removeAllViews()
        when (i) {
            0 -> pageScenes()
            1 -> pageTouch()
            2 -> pageColor()
            else -> pageMore()
        }
        scroll.scrollTo(0, 0)
    }

    private fun slider(parent: LinearLayout, name: String, key: String, def: Int, minV: Int, maxV: Int, onChange: (() -> Unit)? = null, fmt: (Int) -> String) {
        val cur = prefs.getInt(key, def)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val v = tv(fmt(cur), 14f, cAccent, true)
        row.addView(tv(name, 14f, Color.WHITE, false), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(v)
        parent.addView(row, lp(top = 14))
        val sb = SeekBar(this)
        sb.max = maxV - minV
        sb.progress = cur - minV
        sb.progressTintList = ColorStateList.valueOf(cAccent)
        sb.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                val real = value + minV
                prefs.edit().putInt(key, real).apply()
                v.text = fmt(real)
                onChange?.invoke()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(sb)
    }

    private fun switchRow(parent: LinearLayout, title: String, sub: String, key: String, def: Boolean, onChange: ((Boolean) -> Unit)? = null): Switch {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(title, 14f, Color.WHITE, false))
        col.addView(tv(sub, 12f, cSub, false))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(this)
        sw.isChecked = prefs.getBoolean(key, def)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(cAccent, Color.GRAY))
        sw.trackTintList = ColorStateList(states, intArrayOf(Color.parseColor("#556CFF"), Color.parseColor("#333A66")))
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean(key, on).apply()
            onChange?.invoke(on)
        }
        row.addView(sw)
        parent.addView(row, lp(top = 14))
        return sw
    }

    private fun chips(parent: LinearLayout, items: List<String>, cols: Int, selected: Int, onSel: (Int) -> Unit) {
        val views = mutableListOf<TextView>()
        fun restyle(sel: Int) {
            views.forEachIndexed { i, t ->
                if (i == sel) { t.background = bg(cAccent, 12); t.setTextColor(Color.WHITE) }
                else { t.background = bg(cChip, 12); t.setTextColor(cSub) }
            }
        }
        items.chunked(cols).forEachIndexed { r, rowItems ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            rowItems.forEachIndexed { k, label ->
                val idx = r * cols + k
                val t = tv(label, 13f, cSub, true)
                t.gravity = Gravity.CENTER
                t.setPadding(px(4), px(11), px(4), px(11))
                t.setOnClickListener { restyle(idx); onSel(idx) }
                views.add(t)
                val par = LinearLayout.LayoutParams(0, WRAP, 1f)
                par.marginEnd = px(6)
                row.addView(t, par)
            }
            repeat(cols - rowItems.size) { row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            parent.addView(row, lp(top = 10))
        }
        restyle(selected)
    }

    // ---------- pages ----------
    private fun renderThumb(id: String, hue: Int, sat: Int): Bitmap {
        val bmp = Bitmap.createBitmap(360, 225, Bitmap.Config.ARGB_8888)
        val env = Env()
        env.w = 720
        env.h = 450
        env.dp = 2.5f
        env.hue = hue.toFloat().coerceIn(0f, 359.9f)
        env.sat = sat / 100f
        env.color = Color.HSVToColor(floatArrayOf(env.hue, env.sat, 1f))
        env.radius = 300f
        env.touchOn = false
        val scene = Scenes.create(id, env)
        for (i in 0 until 50) {
            env.t += 0.05f
            scene.step(0.05f)
        }
        val c = Canvas(bmp)
        c.scale(0.5f, 0.5f)
        scene.render(c)
        return bmp
    }

    private fun pageScenes() {
        val cards = LinkedHashMap<String, LinearLayout>()
        val views = HashMap<String, ImageView>()
        var cur = prefs.getString("scene", "constellation") ?: "constellation"
        var banner: TextView? = null
        fun restyle() {
            cards.forEach { (id, l) ->
                l.background = if (id == cur) bg(cCardSel, 16, 2, cAccent) else bg(cCard, 16, 2, cCard)
            }
        }
        fun pick(id: String) {
            cur = id
            val ed = prefs.edit()
            if (prefs.getInt("auto", 0) != 0) {
                ed.putInt("auto", 0)
                banner?.visibility = View.GONE
                Toast.makeText(this, "Auto-change turned off", Toast.LENGTH_SHORT).show()
            }
            ed.putString("scene", id).apply()
            restyle()
        }

        if (prefs.getInt("auto", 0) != 0) {
            val bn = tv("Auto-change is ON, so the scene switches by itself. Tap to turn it off.", 12f, Color.WHITE, true)
            bn.background = bg(Color.parseColor("#3A2A7A"), 12, 1, cAccent2)
            bn.setPadding(px(12), px(10), px(12), px(10))
            bn.setOnClickListener {
                prefs.edit().putInt("auto", 0).apply()
                bn.visibility = View.GONE
            }
            banner = bn
            content.addView(bn, lp(bottom = 10))
        }

        content.addView(pill("+  ADD YOUR OWN BACKGROUND") { pickFile() }, lp(bottom = 10))
        val mine = Custom.list(prefs)
        val cviews = HashMap<String, ImageView>()
        if (mine.isNotEmpty()) {
            content.addView(tv("My backgrounds", 14f, cSub, true), lp(bottom = 2))
            mine.chunked(2).forEach { pair ->
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                pair.forEachIndexed { k, item ->
                    val l = LinearLayout(this)
                    l.orientation = LinearLayout.VERTICAL
                    l.setPadding(px(8), px(8), px(8), px(10))
                    l.background = bg(cCard, 16, 2, cCard)
                    val iv = ImageView(this)
                    iv.scaleType = ImageView.ScaleType.CENTER_CROP
                    iv.background = bg(Color.parseColor("#0B0F26"), 12)
                    iv.clipToOutline = true
                    l.addView(iv, LinearLayout.LayoutParams(MATCH, px(92)))
                    cviews[item.id] = iv
                    val nm = tv(item.name, 14f, Color.WHITE, true)
                    nm.setPadding(px(4), 0, px(4), 0)
                    nm.maxLines = 1
                    l.addView(nm, lp(top = 8))
                    l.addView(tv(if (item.type == "v") "Video" else "Photo", 11f, cSub, false).also { it.setPadding(px(4), 0, px(4), 0) }, lp(top = 2))
                    l.setOnClickListener { showCustom(item) }
                    val par = LinearLayout.LayoutParams(0, WRAP, 1f)
                    if (k == 0) par.marginEnd = px(5) else par.marginStart = px(5)
                    row.addView(l, par)
                }
                if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
                content.addView(row, lp(top = 10))
            }
            Thread {
                for (item in mine) {
                    try {
                        val f = Custom.file(Store.ctx(this), item)
                        val b = if (item.type == "i") Custom.decode(f, 320, 200) else Custom.videoThumb(f)
                        if (b != null) runOnUiThread { cviews[item.id]?.setImageBitmap(b) }
                    } catch (_: Exception) {
                    }
                }
            }.start()
            content.addView(tv("Built-in backgrounds", 14f, cSub, true), lp(top = 14))
        }

        val rnd = tv("RANDOM SCENE", 13f, Color.WHITE, true)
        rnd.gravity = Gravity.CENTER
        rnd.letterSpacing = 0.08f
        rnd.background = bg(cChip, 12)
        rnd.setPadding(0, px(12), 0, px(12))
        rnd.setOnClickListener { pick(Scenes.list.map { it.first }.filter { it != cur }.random()) }
        content.addView(rnd, lp(top = 10))

        Scenes.list.chunked(2).forEach { pair ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            pair.forEachIndexed { k, t ->
                val l = LinearLayout(this)
                l.orientation = LinearLayout.VERTICAL
                l.setPadding(px(8), px(8), px(8), px(10))
                val iv = ImageView(this)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                iv.background = bg(Color.parseColor("#0B0F26"), 12)
                iv.clipToOutline = true
                l.addView(iv, LinearLayout.LayoutParams(MATCH, px(92)))
                views[t.first] = iv
                val nm = tv(t.second, 15f, Color.WHITE, true)
                nm.setPadding(px(4), 0, px(4), 0)
                val nameRow = LinearLayout(this)
                nameRow.orientation = LinearLayout.HORIZONTAL
                nameRow.gravity = Gravity.CENTER_VERTICAL
                nameRow.addView(nm)
                if (Scenes.fresh.contains(t.first)) {
                    val chip = tv("NEW", 10f, Color.WHITE, true)
                    val cg = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cAccent, cAccent2))
                    cg.cornerRadius = px(8).toFloat()
                    chip.background = cg
                    chip.setPadding(px(6), px(2), px(6), px(2))
                    val cp = LinearLayout.LayoutParams(WRAP, WRAP)
                    cp.marginStart = px(4)
                    nameRow.addView(chip, cp)
                }
                l.addView(nameRow, lp(top = 8))
                val ds = tv(t.third, 11f, cSub, false)
                ds.setPadding(px(4), 0, px(4), 0)
                l.addView(ds, lp(top = 2))
                l.setOnClickListener {
                    pick(t.first)
                    if (t.first == "water") showWater()
                }
                cards[t.first] = l
                val par = LinearLayout.LayoutParams(0, WRAP, 1f)
                if (k == 0) par.marginEnd = px(5) else par.marginStart = px(5)
                row.addView(l, par)
            }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            content.addView(row, lp(top = 10))
        }
        restyle()

        val hue = prefs.getInt("hue", 200)
        val sat = prefs.getInt("sat", 70)
        if (thumbCache.size > 34) thumbCache.clear()
        Thread {
            for (t in Scenes.list) {
                try {
                    val bmp = thumbCache.getOrPut("${t.first}-$hue-$sat") { renderThumb(t.first, hue, sat) }
                    runOnUiThread { views[t.first]?.setImageBitmap(bmp) }
                } catch (_: Exception) {
                }
            }
        }.start()
    }


    // ---------- Live water menu ----------
    private fun renderWaterPreview(): Bitmap {
        val bmp = Bitmap.createBitmap(270, 480, Bitmap.Config.ARGB_8888)
        val env = Env()
        env.w = 540
        env.h = 960
        env.dp = 3f
        env.hue = prefs.getInt("hue", 200).toFloat().coerceIn(0f, 359.9f)
        env.sat = prefs.getInt("sat", 70) / 100f
        env.color = Color.HSVToColor(floatArrayOf(env.hue, env.sat, 1f))
        WaterPrefs.apply(env, prefs)
        val sc = Scenes.create("water", env)
        for (i in 0 until 40) {
            env.t += 0.05f
            sc.step(0.05f)
        }
        val c = Canvas(bmp)
        c.scale(0.5f, 0.5f)
        sc.render(c)
        return bmp
    }

    private fun renderBoat(style: Int): Bitmap {
        val bmp = Bitmap.createBitmap(160, 120, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        c.drawColor(Color.parseColor("#0B0F26"))
        BoatArt.draw(c, p, 80f, 78f, 40f, style, 0f)
        val hue = prefs.getInt("hue", 200).toFloat().coerceIn(0f, 359.9f)
        val base = if (prefs.getBoolean("wown", false))
            Color.HSVToColor(floatArrayOf(prefs.getInt("whue", 205).toFloat().coerceIn(0f, 359.9f), prefs.getInt("wsat", 75) / 100f, 1f))
        else Color.HSVToColor(floatArrayOf(hue, prefs.getInt("sat", 70) / 100f, 1f))
        p.style = android.graphics.Paint.Style.FILL
        p.color = Color.argb(215, Color.red(base) * 7 / 10, Color.green(base) * 7 / 10, Color.blue(base) * 7 / 10)
        c.drawRect(0f, 80f, 160f, 120f, p)
        p.color = Color.argb(150, 255, 255, 255)
        p.strokeWidth = 2f
        p.style = android.graphics.Paint.Style.STROKE
        c.drawLine(0f, 80f, 160f, 80f, p)
        return bmp
    }

    private fun showWater() {
        content.removeAllViews()
        val back = tv("<  Back to scenes", 14f, cAccent, true)
        back.setPadding(0, px(4), 0, px(10))
        back.setOnClickListener { selectTab(0) }
        content.addView(back, lp())

        // preview + liters
        val c1 = card("Live water", "Water floats, splashes and flows when you tilt the phone", "drop")
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.background = bg(Color.parseColor("#0B0F26"), 16)
        img.clipToOutline = true
        val ip = LinearLayout.LayoutParams(px(150), px(266))
        ip.gravity = Gravity.CENTER_HORIZONTAL
        ip.topMargin = px(12)
        c1.addView(img, ip)
        val lit = tv("", 22f, Color.WHITE, true)
        lit.gravity = Gravity.CENTER
        c1.addView(lit, lp(top = 8))
        fun refresh() {
            img.setImageBitmap(renderWaterPreview())
            lit.text = "%.1f L".format(prefs.getInt("liters", 15) / 10f)
        }
        slider(c1, "Amount of water", "liters", 15, 5, 50, onChange = { refresh() }) { "%.1f L".format(it / 10f) }
        content.addView(c1, lp())

        // boats
        val c2 = card("Paper boats", "Pick a boat style", "boat")
        val boatCards = ArrayList<LinearLayout>()
        var curStyle = prefs.getInt("bstyle", 0)
        fun restyleBoats() {
            boatCards.forEachIndexed { i, l ->
                l.background = if (i == curStyle) bg(cCardSel, 12, 2, cAccent) else bg(cChip, 12, 2, cChip)
            }
        }
        val brow = LinearLayout(this)
        brow.orientation = LinearLayout.HORIZONTAL
        BoatArt.names.forEachIndexed { i, name ->
            val l = LinearLayout(this)
            l.orientation = LinearLayout.VERTICAL
            l.gravity = Gravity.CENTER_HORIZONTAL
            l.setPadding(px(4), px(4), px(4), px(6))
            val iv = ImageView(this)
            iv.setImageBitmap(renderBoat(i))
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.background = bg(Color.parseColor("#0B0F26"), 8)
            iv.clipToOutline = true
            l.addView(iv, LinearLayout.LayoutParams(MATCH, px(54)))
            l.addView(tv(name, 11f, cSub, true), lp(top = 4))
            l.setOnClickListener {
                curStyle = i
                prefs.edit().putInt("bstyle", i).apply()
                restyleBoats()
                refresh()
            }
            boatCards.add(l)
            val par = LinearLayout.LayoutParams(0, WRAP, 1f)
            par.marginEnd = if (i < 3) px(6) else 0
            brow.addView(l, par)
        }
        c2.addView(brow, lp(top = 10))
        restyleBoats()
        slider(c2, "Boats on the water", "boats", 1, 0, 5, onChange = { refresh() }) { "$it" }
        content.addView(c2, lp(top = 12))

        // stones
        val c3 = card("Stones", "Tap the wallpaper to drop a stone. Drag a stone to lift and throw it (lock screen and preview). On some home screens a tap only drops a stone.", "stone")
        slider(c3, "Max stones", "stones", 6, 0, 15) { "$it" }
        content.addView(c3, lp(top = 12))

        // physics switches
        val c4 = card("Physics", null, "atom")
        lateinit var sTilt: Switch
        val sNone = switchRow(c4, "No Physics", "Calm water: no splashes, no falling stones, no movement", "p_none", false) { on ->
            if (on) sTilt.isChecked = false
            refresh()
        }
        sTilt = switchRow(c4, "Yes Physics", "Water flows to the low side when you tilt the phone", "p_tilt", true) { on ->
            if (on) sNone.isChecked = false
            refresh()
        }
        content.addView(c4, lp(top = 12))

        // water color
        val c5 = card("Water color", null, "color")
        val wheel = ColorWheel(this)
        wheel.hue = prefs.getInt("whue", 205).toFloat()
        wheel.sat = prefs.getInt("wsat", 75) / 100f
        wheel.onPick = { hh, ss ->
            prefs.edit().putInt("whue", hh.toInt()).putInt("wsat", (ss * 100).toInt()).apply()
            refresh()
        }
        val wp = LinearLayout.LayoutParams(px(220), px(220))
        wp.gravity = Gravity.CENTER_HORIZONTAL
        wp.topMargin = px(10)
        val own = prefs.getBoolean("wown", false)
        wheel.visibility = if (own) View.VISIBLE else View.GONE
        switchRow(c5, "Separate water color", "Off: water uses the main wallpaper color", "wown", false) { on ->
            wheel.visibility = if (on) View.VISIBLE else View.GONE
            refresh()
        }
        c5.addView(wheel, wp)
        content.addView(c5, lp(top = 12))

        val c6 = card("Sound", "Splashes, stones and gentle flowing water", "sound")
        switchRow(c6, "Sound effects", "Turns the sounds of all wallpapers on or off", "sound", true)
        content.addView(c6, lp(top = 12))

        refresh()
        scroll.scrollTo(0, 0)
    }


    // ---------- own backgrounds ----------
    private fun pickFile() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
        i.addCategory(Intent.CATEGORY_OPENABLE)
        try {
            startActivityForResult(i, 55)
        } catch (ex: Exception) {
            Toast.makeText(this, "No file picker found", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 55 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val mime = contentResolver.getType(uri) ?: ""
        var name = "Background"
        try {
            contentResolver.query(uri, null, null, null, null)?.use { cur ->
                val ix = cur.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (ix >= 0 && cur.moveToFirst()) name = cur.getString(ix).substringBeforeLast('.')
            }
        } catch (_: Exception) {
        }
        if (Custom.list(prefs).size >= 12) {
            Toast.makeText(this, "Limit is 12 own backgrounds", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "Adding...", Toast.LENGTH_LONG).show()
        Thread {
            val item = if (mime.startsWith("video")) Custom.addVideo(this, uri, name) else Custom.addImage(this, uri, name)
            runOnUiThread {
                if (item == null) {
                    Toast.makeText(this, "Could not add this file (videos up to 150 MB)", Toast.LENGTH_LONG).show()
                } else {
                    Custom.save(prefs, Custom.list(prefs) + item)
                    Toast.makeText(this, "Added", Toast.LENGTH_SHORT).show()
                    if (tab == 0) selectTab(0)
                }
            }
        }.start()
    }

    private fun setVideoWallpaper() {
        try {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            i.putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this, VideoWallpaperService::class.java)
            )
            startActivity(i)
        } catch (ex: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }

    private fun showCustom(item: Custom.Item) {
        content.removeAllViews()
        val back = tv("<  Back to scenes", 14f, cAccent, true)
        back.setPadding(0, px(4), 0, px(10))
        back.setOnClickListener { selectTab(0) }
        content.addView(back, lp())

        val isVideo = item.type == "v"
        val c = card(item.name, if (isVideo) "Video background" else "Photo background", if (isVideo) "video" else "image")
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.background = bg(Color.parseColor("#0B0F26"), 16)
        img.clipToOutline = true
        c.addView(img, LinearLayout.LayoutParams(MATCH, px(200)).also { it.topMargin = px(12) })
        Thread {
            try {
                val f = Custom.file(Store.ctx(this), item)
                val b = if (isVideo) Custom.videoThumb(f) else Custom.decode(f, 800, 500)
                if (b != null) runOnUiThread { img.setImageBitmap(b) }
            } catch (_: Exception) {
            }
        }.start()

        if (!isVideo) {
            c.addView(tv("Effect on top", 14f, Color.WHITE, true), lp(top = 14))
            val cur = Custom.overlays.indexOfFirst { it.first == item.overlay }.coerceAtLeast(0)
            chips(c, Custom.overlays.map { it.second }, 3, cur) { sel ->
                Custom.save(prefs, Custom.list(prefs).map {
                    if (it.id == item.id) Custom.Item(it.id, it.type, it.name, Custom.overlays[sel].first) else it
                })
            }
            c.addView(pill("USE THIS BACKGROUND") {
                prefs.edit().putString("scene", "c:" + item.id).apply()
                Toast.makeText(this, "Selected. Tap SET AS WALLPAPER if it is not set yet.", Toast.LENGTH_LONG).show()
            }, lp(top = 14))
        } else {
            c.addView(tv("Plays muted as a separate live wallpaper. Effects and sounds are not available for video.", 12f, cSub, false), lp(top = 12))
            c.addView(pill("SET AS VIDEO WALLPAPER") {
                prefs.edit().putString("video_id", item.id).apply()
                setVideoWallpaper()
            }, lp(top = 12))
        }
        val del = pill("DELETE") {
            AlertDialog.Builder(this)
                .setTitle("Delete this background?")
                .setPositiveButton("Delete") { _, _ ->
                    Custom.delete(this, prefs, item.id)
                    selectTab(0)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        del.background = bg(Color.parseColor("#5A1F2E"), 12)
        c.addView(del, lp(top = 8))
        content.addView(c, lp())
        scroll.scrollTo(0, 0)
    }

    private fun pageTouch() {
        val c1 = card("Reaction", "What happens when you touch the wallpaper", "touch")
        val modes = listOf("attract", "repel", "off")
        chips(c1, listOf("Fly to finger", "Fly away", "Off"), 3, modes.indexOf(prefs.getString("mode", "attract")).coerceAtLeast(0)) {
            prefs.edit().putString("mode", modes[it]).apply()
        }
        content.addView(c1, lp())

        val c2 = card("Touch radius", "Only things inside this circle react to your finger", "touch")
        slider(c2, "Radius", "radius", 25, 5, 80) { "%.1f cm".format(it / 10f) }
        switchRow(c2, "Show touch circle", "Draws the radius under your finger", "ring", false)
        content.addView(c2, lp(top = 12))

        val c3 = card("Screen edges", null, "scenes")
        switchRow(c3, "Keep inside the screen", "Objects bounce off the edges instead of flying out", "bounce", false)
        content.addView(c3, lp(top = 12))

        val c4 = card("Tip", "On the home screen tap or hold an empty spot to trigger the effect. On the lock screen and in the preview, dragging works too.", "touch")
        content.addView(c4, lp(top = 12))
    }

    private fun pageColor() {
        val c = card("Color wheel", "Drag on the wheel. Center is white, edge is full color.", "color")
        val wheel = ColorWheel(this)
        wheel.hue = prefs.getInt("hue", 200).toFloat()
        wheel.sat = prefs.getInt("sat", 70) / 100f
        wheel.onPick = { h, s -> prefs.edit().putInt("hue", h.toInt()).putInt("sat", (s * 100).toInt()).apply() }
        val wp = LinearLayout.LayoutParams(px(260), px(260))
        wp.gravity = Gravity.CENTER_HORIZONTAL
        wp.topMargin = px(10)
        c.addView(wheel, wp)

        val sw = LinearLayout(this)
        sw.orientation = LinearLayout.HORIZONTAL
        val presets = listOf(0 to 0, 0 to 100, 28 to 100, 55 to 100, 130 to 90, 185 to 100, 225 to 90, 275 to 80, 325 to 80)
        presets.forEach { (h, s) ->
            val v = View(this)
            val gd = GradientDrawable()
            gd.shape = GradientDrawable.OVAL
            gd.setColor(Color.HSVToColor(floatArrayOf(h.toFloat(), s / 100f, 1f)))
            gd.setStroke(px(2), Color.parseColor("#33FFFFFF"))
            v.background = gd
            v.setOnClickListener {
                wheel.setColor(h.toFloat(), s / 100f)
                prefs.edit().putInt("hue", h).putInt("sat", s).apply()
            }
            val par = LinearLayout.LayoutParams(0, px(30), 1f)
            par.marginEnd = px(5)
            sw.addView(v, par)
        }
        c.addView(sw, lp(top = 14))
        content.addView(c, lp())

        val c2 = card("Rainbow", null, "color")
        switchRow(c2, "Rainbow cycle", "Color slowly changes through the whole wheel", "rainbow", false)
        content.addView(c2, lp(top = 12))
    }

    private fun pageMore() {
        val cs = card("Sound", "Sound effects for every wallpaper", "sound")
        switchRow(cs, "Sound effects", "Splashes, explosions and ambient sounds", "sound", true)
        slider(cs, "Volume", "vol", 50, 0, 100) { "$it%" }
        content.addView(cs, lp())

        val cp = card("Lag protection", "Lowers FPS and detail by itself when the phone is slow, hot or in battery saver", "bolt")
        switchRow(cp, "Adaptive performance", "Keeps the wallpaper light on resources", "adaptive", true)
        switchRow(cp, "Full quality (60 FPS)", "Ignore the weak-phone limit (budget phones start in 30 FPS mode)", "forcefull", false)
        content.addView(cp, lp(top = 12))

        val cr = card("After reboot", "Some phones reset live wallpapers on restart. Allow this app to run in the background (battery: no restrictions, autostart on).", "refresh")
        switchRow(cr, "Remind me if it resets", "Shows a notification you can tap to set the wallpaper again", "remind", true) { on ->
            if (on) askNotifications()
        }
        cr.addView(pill("BATTERY SETTINGS") { openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS, false) }, lp(top = 14))
        cr.addView(pill("AUTOSTART MANAGER") { openAutostart() }, lp(top = 8))
        cr.addView(tv("Tecno / Infinix (HiOS): Phone Master > Autostart: allow NOVA Wallpapers. Battery > App battery usage: No restrictions. Lock the app in Recents.", 11f, cSub, false), lp(top = 8))
        cr.addView(pill("APP SETTINGS") { openSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, true) }, lp(top = 8))
        content.addView(cr, lp(top = 12))

        val c1 = card("Auto-change scene", "Switch to a random scene automatically", "shuffle")
        chips(c1, listOf("Off", "On unlock", "1 min", "5 min", "15 min", "30 min", "1 hour"), 4, prefs.getInt("auto", 0)) {
            prefs.edit().putInt("auto", it).apply()
        }
        content.addView(c1, lp(top = 12))

        val c2 = card("Fine tuning", null, "more")
        slider(c2, "Speed", "speed", 50, 0, 100) { "$it%" }
        slider(c2, "Amount", "amount", 50, 0, 100) { "$it%" }
        slider(c2, "Dim wallpaper", "dim", 0, 0, 80) { "$it%" }
        switchRow(c2, "Battery saver", "Limits animation to 30 FPS", "fps30", false)
        content.addView(c2, lp(top = 12))

        val reset = tv("RESET TO DEFAULTS", 13f, Color.WHITE, true)
        reset.gravity = Gravity.CENTER
        reset.letterSpacing = 0.08f
        reset.background = bg(cChip, 12)
        reset.setPadding(0, px(12), 0, px(12))
        reset.setOnClickListener {
            prefs.edit().clear().apply()
            Toast.makeText(this, "Settings reset", Toast.LENGTH_SHORT).show()
            selectTab(tab)
        }
        content.addView(reset, lp(top = 14))
        val foot = tv("NOVA Wallpapers 1.5", 11f, cSub, false)
        foot.gravity = Gravity.CENTER
        content.addView(foot, lp(top = 14))
    }

    private fun setWallpaper() {
        try {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            i.putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this, NovaWallpaperService::class.java)
            )
            startActivity(i)
        } catch (ex: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }
}
