package com.nova.wallpapers

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class ColorWheel(ctx: Context) : View(ctx) {
    var hue = 200f
    var sat = 0.7f
    var onPick: ((Float, Float) -> Unit)? = null
    private val pw = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pr = Paint(Paint.ANTI_ALIAS_FLAG)
    private var cx = 0f
    private var cy = 0f
    private var rad = 0f
    private val dp = ctx.resources.displayMetrics.density

    fun setColor(h: Float, s: Float) {
        hue = h; sat = s
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f
        cy = h / 2f
        rad = min(w, h) / 2f - 14f * dp
    }

    override fun onDraw(c: Canvas) {
        pw.style = Paint.Style.FILL
        pw.shader = SweepGradient(
            cx, cy,
            intArrayOf(Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED),
            null
        )
        c.drawCircle(cx, cy, rad, pw)
        pw.shader = RadialGradient(cx, cy, rad, Color.WHITE, Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, rad, pw)
        pw.shader = null
        val a = Math.toRadians(hue.toDouble())
        val d = sat * rad
        val sx = cx + (cos(a) * d).toFloat()
        val sy = cy + (sin(a) * d).toFloat()
        pr.style = Paint.Style.FILL
        pr.color = Color.HSVToColor(floatArrayOf(hue.coerceIn(0f, 359.9f), sat, 1f))
        c.drawCircle(sx, sy, 12f * dp, pr)
        pr.style = Paint.Style.STROKE
        pr.strokeWidth = 3f * dp
        pr.color = Color.WHITE
        c.drawCircle(sx, sy, 12f * dp, pr)
        pr.strokeWidth = 1f * dp
        pr.color = Color.argb(120, 0, 0, 0)
        c.drawCircle(sx, sy, 14f * dp, pr)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val dx = ev.x - cx
                val dy = ev.y - cy
                var ang = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
                if (ang < 0f) ang += 360f
                hue = ang
                sat = (sqrt(dx * dx + dy * dy) / rad).coerceIn(0f, 1f)
                invalidate()
                onPick?.invoke(hue, sat)
            }
        }
        return true
    }
}
