package com.nova.wallpapers

import android.content.SharedPreferences
import android.graphics.*
import kotlin.math.*
import kotlin.random.Random

object WaterPrefs {
    fun apply(env: Env, prefs: SharedPreferences) {
        env.liters = prefs.getInt("liters", 15) / 10f
        env.phys = if (prefs.getBoolean("p_none", false)) 1 else if (prefs.getBoolean("p_tilt", true)) 2 else 0
        env.waterOwn = prefs.getBoolean("wown", false)
        env.whue = prefs.getInt("whue", 205).toFloat().coerceIn(0f, 359.9f)
        env.wsat = prefs.getInt("wsat", 75) / 100f
        env.boats = prefs.getInt("boats", 1).coerceIn(0, 5)
        env.bstyle = prefs.getInt("bstyle", 0).coerceIn(0, 3)
        env.stones = prefs.getInt("stones", 6).coerceIn(0, 15)
    }
}

object BoatArt {
    val names = listOf("Classic", "Red", "Sunny", "Blue")
    private val body = intArrayOf(
        Color.parseColor("#F4F4F4"), Color.parseColor("#E8564A"),
        Color.parseColor("#F2C14E"), Color.parseColor("#4A90E2")
    )

    fun draw(c: Canvas, p: Paint, cx: Float, wl: Float, s: Float, style: Int, tiltDeg: Float) {
        val base = body[style.coerceIn(0, 3)]
        val path = Path()
        c.save()
        c.translate(cx, wl)
        c.rotate(tiltDeg)
        p.shader = null
        p.style = Paint.Style.FILL
        path.moveTo(-s, -0.12f * s); path.lineTo(s, -0.12f * s)
        path.lineTo(0.62f * s, 0.45f * s); path.lineTo(-0.62f * s, 0.45f * s)
        path.close()
        p.color = shade(base, 0.8f)
        c.drawPath(path, p)
        path.reset()
        path.moveTo(-0.78f * s, -0.12f * s); path.lineTo(0.78f * s, -0.12f * s); path.lineTo(0f, -1.15f * s)
        path.close()
        p.color = base
        c.drawPath(path, p)
        path.reset()
        path.moveTo(0f, -1.15f * s); path.lineTo(0.78f * s, -0.12f * s); path.lineTo(0f, -0.12f * s)
        path.close()
        p.color = shade(base, 0.76f)
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = max(1f, s * 0.04f)
        p.color = Color.argb(90, 0, 0, 0)
        path.reset()
        path.moveTo(-s, -0.12f * s); path.lineTo(s, -0.12f * s)
        path.lineTo(0.62f * s, 0.45f * s); path.lineTo(-0.62f * s, 0.45f * s)
        path.close()
        c.drawPath(path, p)
        c.restore()
    }
}

class Stone {
    var x = 0f
    var y = 0f
    var vx = 0f
    var vy = 0f
    var r = 16f
    var rot = 0f
    var w = 0f
    var inW = false
    var tone = 0.7f
    val shape = FloatArray(8) { 0.8f + Random.nextFloat() * 0.35f }
}

class Drop(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float)

class WaterScene(e: Env) : Scene(e) {
    private val N = 100
    private val PIF = Math.PI.toFloat()
    private val hh = FloatArray(N)
    private val vv = FloatArray(N)
    private val lo = FloatArray(N)
    private val hi = FloatArray(N)
    private val ambC = FloatArray(N)
    private val ok = BooleanArray(N)
    private var gAng = 0f
    private var gVel = 0f
    private var sg = 0f
    private var cg = 1f
    private var level = 0f
    private var uMin = 0f
    private var du = 1f
    private var anyVis = false
    private var uVisMin = 0f
    private var uVisMax = 0f
    private val stones = ArrayList<Stone>()
    private val drops = ArrayList<Drop>()
    private var held: Stone? = null
    private var wasTouch = false
    private var lastTx = 0f
    private var lastTy = 0f
    private var fvx = 0f
    private var fvy = 0f
    private val boatU = FloatArray(5)
    private val boatV = FloatArray(5)
    private val boatB = FloatArray(5)
    private val boatA = FloatArray(5)
    private val bu = FloatArray(16)
    private val bd = FloatArray(16)
    private val bs = FloatArray(16)
    private val path = Path()
    private val surf = Path()
    private val spath = Path()

    private fun target(): Float = if (e.phys == 2) atan2(e.gx, e.gy) else 0f

    private fun amb(u: Float): Float {
        val dp = e.dp
        return (sin(u / (80f * dp) + e.t * 1.3f) * 3.2f + sin(u / (37f * dp) - e.t * 0.9f) * 2.2f) * dp
    }

    override fun reset() {
        hh.fill(0f); vv.fill(0f)
        stones.clear(); drops.clear(); held = null
        gAng = target(); gVel = 0f
        for (i in 0 until 5) {
            boatU[i] = (i - 2) * e.w * 0.2f
            boatB[i] = rf(-9f, 9f) * e.dp
            boatV[i] = boatB[i]
            boatA[i] = 0f
        }
        for (i in 0 until 16) {
            bu[i] = rf(-1f, 1f) * e.w * 0.5f
            bd[i] = rf(40f, 400f) * e.dp
            bs[i] = rf(12f, 34f) * e.dp
        }
    }

    private fun areaAt(l: Float): Float {
        var sum = 0f
        for (i in 0 until N) {
            if (!ok[i]) continue
            val top = max(lo[i], l + hh[i] + ambC[i])
            if (hi[i] > top) sum += hi[i] - top
        }
        return sum * du
    }

    private fun inWater(x: Float, y: Float): Boolean {
        val dx = x - e.w / 2f
        val dy = y - e.h / 2f
        val u = dx * cg - dy * sg
        val d = dx * sg + dy * cg
        val idx = ((u - uMin) / du).roundToInt().coerceIn(0, N - 1)
        return d > level + hh[idx] + ambC[idx]
    }

    override fun update(dt: Float) {
        val w = e.w.toFloat()
        val h = e.h.toFloat()
        val dp = e.dp
        val physical = e.phys != 1

        if (!physical) {
            gAng = 0f; gVel = 0f
        } else {
            var diff = target() - gAng
            while (diff > PIF) diff -= 2f * PIF
            while (diff < -PIF) diff += 2f * PIF
            gVel += (diff * 34f - gVel * 5.5f) * dt
            gAng += gVel * dt
        }
        sg = sin(gAng)
        cg = cos(gAng)

        val a = w / 2f
        val b = h / 2f
        val eu = a * abs(cg) + b * abs(sg) + 30f * dp
        uMin = -eu
        du = 2f * eu / (N - 1)
        for (i in 0 until N) {
            val u = uMin + i * du
            var l = -1e9f
            var hg = 1e9f
            var empty = false
            val lo1 = -a - cg * u
            val hi1 = a - cg * u
            if (abs(sg) > 1e-4f) {
                val d1 = lo1 / sg; val d2 = hi1 / sg
                l = max(l, min(d1, d2)); hg = min(hg, max(d1, d2))
            } else if (abs(cg * u) > a) empty = true
            val lo2 = -b + sg * u
            val hi2 = b + sg * u
            if (abs(cg) > 1e-4f) {
                val d1 = lo2 / cg; val d2 = hi2 / cg
                l = max(l, min(d1, d2)); hg = min(hg, max(d1, d2))
            } else if (abs(sg * u) > b) empty = true
            if (empty || l > hg) { ok[i] = false; lo[i] = 0f; hi[i] = 0f }
            else { ok[i] = true; lo[i] = l; hi[i] = hg }
            ambC[i] = amb(u)
        }

        if (!physical) {
            for (i in 0 until N) { hh[i] *= 0.9f; vv[i] = 0f }
        } else {
            val steps = (dt * 60f).roundToInt().coerceIn(1, 3)
            repeat(steps) {
                for (i in 0 until N) {
                    val l = hh[if (i > 0) i - 1 else 0]
                    val r = hh[if (i < N - 1) i + 1 else N - 1]
                    vv[i] += ((l + r) * 0.5f - hh[i]) * 0.3f - hh[i] * 0.002f
                    vv[i] += gVel * (uMin + i * du) * 0.0004f
                    vv[i] *= 0.985f
                }
                for (i in 0 until N) hh[i] = (hh[i] + vv[i]).coerceIn(-70f * dp, 70f * dp)
            }
        }

        val D = hypot(w, h) / 2f
        val frac = (0.06f + (e.liters - 0.5f) / 4.5f * 0.64f).coerceIn(0.03f, 0.85f)
        val goal = frac * w * h
        var lmin = -D * 1.1f
        var lmax = D * 1.1f
        repeat(22) {
            val mid = (lmin + lmax) / 2f
            if (areaAt(mid) > goal) lmin = mid else lmax = mid
        }
        level = (lmin + lmax) / 2f

        anyVis = false
        uVisMin = 1e9f
        uVisMax = -1e9f
        for (i in 0 until N) {
            val s = level + hh[i] + ambC[i]
            if (ok[i] && s >= lo[i] && s <= hi[i]) {
                val u = uMin + i * du
                anyVis = true
                uVisMin = min(uVisMin, u)
                uVisMax = max(uVisMax, u)
            }
        }

        updateStones(dt)
        updateBoats(dt)
        for (i in 0 until 16) {
            bd[i] -= bs[i] * dt
            if (bd[i] < 0f) {
                bd[i] = rf(60f, 420f) * dp
                bu[i] = if (anyVis) rf(uVisMin, uVisMax) else rf(uMin, -uMin)
            }
        }
        var k = drops.size - 1
        while (k >= 0) {
            val d = drops[k]
            d.vx += sg * 1200f * dp * dt
            d.vy += cg * 1200f * dp * dt
            d.x += d.vx * dt
            d.y += d.vy * dt
            d.life -= dt
            if (d.life <= 0f || (d.life < 0.8f && inWater(d.x, d.y))) drops.removeAt(k)
            k--
        }
    }

    private fun grab() {
        var best: Stone? = null
        var bd2 = Float.MAX_VALUE
        for (s in stones) {
            val d = hypot(s.x - e.tx, s.y - e.ty)
            if (d < s.r + 18f * e.dp && d < bd2) { bd2 = d; best = s }
        }
        if (best == null && e.stones > 0) {
            val ns = Stone()
            ns.x = e.tx; ns.y = e.ty
            ns.r = rf(12f, 22f) * e.dp
            ns.tone = rf(0.55f, 0.9f)
            ns.w = rf(-3f, 3f)
            if (stones.size >= e.stones) stones.removeAt(0)
            stones.add(ns)
            best = ns
        }
        held = best
    }

    private fun updateStones(dt: Float) {
        val dp = e.dp
        val w = e.w.toFloat()
        val h = e.h.toFloat()
        if (e.phys == 1) {
            stones.clear(); drops.clear(); held = null
            wasTouch = e.touching; lastTx = e.tx; lastTy = e.ty
            return
        }
        while (stones.size > e.stones) {
            val s = stones.removeAt(0)
            if (s === held) held = null
        }
        val maxV = 2600f * dp
        if (e.touching && !wasTouch) {
            fvx = 0f; fvy = 0f
            lastTx = e.tx; lastTy = e.ty
            grab()
        }
        if (e.touching) {
            fvx = fvx * 0.6f + (e.tx - lastTx) / max(dt, 0.001f) * 0.4f
            fvy = fvy * 0.6f + (e.ty - lastTy) / max(dt, 0.001f) * 0.4f
        }
        if (!e.touching && wasTouch) {
            held?.let { it.vx = fvx.coerceIn(-maxV, maxV); it.vy = fvy.coerceIn(-maxV, maxV) }
            held = null
        }
        wasTouch = e.touching
        lastTx = e.tx
        lastTy = e.ty

        val g = 1700f * dp
        for (s in stones) {
            val inW = inWater(s.x, s.y)
            if (s === held) {
                val k = min(1f, 28f * dt)
                s.x += (e.tx - s.x) * k
                s.y += (e.ty - s.y) * k
                s.vx = fvx.coerceIn(-maxV, maxV)
                s.vy = fvy.coerceIn(-maxV, maxV)
            } else {
                val gm = if (inW) 0.28f else 1f
                s.vx += sg * g * gm * dt
                s.vy += cg * g * gm * dt
                if (inW) {
                    val dk = 1f - min(0.9f, 3.2f * dt)
                    s.vx *= dk; s.vy *= dk
                }
                s.x += s.vx * dt
                s.y += s.vy * dt
                s.rot += s.w * dt
                s.w *= (1f - min(1f, 1.5f * dt))
                if (s.x < s.r) { s.x = s.r; s.vx = abs(s.vx) * 0.25f; s.vy *= 0.92f }
                else if (s.x > w - s.r) { s.x = w - s.r; s.vx = -abs(s.vx) * 0.25f; s.vy *= 0.92f }
                if (s.y < s.r) { s.y = s.r; s.vy = abs(s.vy) * 0.25f; s.vx *= 0.92f }
                else if (s.y > h - s.r) { s.y = h - s.r; s.vy = -abs(s.vy) * 0.25f; s.vx *= 0.92f }
            }
            if (inW && !s.inW) splash(s)
            s.inW = inW
        }
        for (i in 0 until stones.size) {
            for (j in i + 1 until stones.size) {
                val s1 = stones[i]
                val s2 = stones[j]
                if (s1 === held || s2 === held) continue
                val dx = s1.x - s2.x
                val dy = s1.y - s2.y
                val dist = sqrt(dx * dx + dy * dy)
                val minD = s1.r + s2.r
                if (dist < minD && dist > 0.01f) {
                    val nx = dx / dist
                    val ny = dy / dist
                    val push = (minD - dist) / 2f
                    s1.x += nx * push; s1.y += ny * push
                    s2.x -= nx * push; s2.y -= ny * push
                    val vn = (s1.vx - s2.vx) * nx + (s1.vy - s2.vy) * ny
                    if (vn < 0f) {
                        val imp = -1.2f * vn / 2f
                        s1.vx += imp * nx; s1.vy += imp * ny
                        s2.vx -= imp * nx; s2.vy -= imp * ny
                    }
                }
            }
        }
    }

    private fun splash(s: Stone) {
        val dp = e.dp
        val vn = s.vx * sg + s.vy * cg
        if (vn < 120f * dp) return
        val dx = s.x - e.w / 2f
        val dy = s.y - e.h / 2f
        val u = dx * cg - dy * sg
        val idx = ((u - uMin) / du).roundToInt().coerceIn(0, N - 1)
        val imp = min(vn * 0.014f, 60f) * (s.r / (16f * dp)).coerceIn(0.6f, 1.6f)
        for (k in -5..5) {
            val c = idx + k
            if (c in 0 until N) vv[c] += imp * (1f - abs(k) / 6f)
        }
        val cnt = (4 + vn / (160f * dp)).toInt().coerceIn(4, 14)
        for (i in 0 until cnt) {
            if (drops.size >= 70) break
            val up = rf(0.2f, 0.7f) * vn * 0.5f
            val lat = rf(-1f, 1f) * 180f * dp
            drops.add(Drop(s.x, s.y, -sg * up + cg * lat, -cg * up - sg * lat, rf(0.6f, 1.1f)))
        }
    }

    private fun updateBoats(dt: Float) {
        if (!anyVis) return
        val dp = e.dp
        val m = 30f * dp
        for (i in 0 until e.boats.coerceIn(0, 5)) {
            val idx = ((boatU[i] - uMin) / du).roundToInt().coerceIn(1, N - 2)
            val slope = (hh[idx + 1] - hh[idx - 1]) / (2f * du)
            boatV[i] += ((boatB[i] - boatV[i]) * 0.6f + slope * 900f * dp) * dt
            boatV[i] = boatV[i].coerceIn(-70f * dp, 70f * dp)
            boatU[i] += boatV[i] * dt
            val l = uVisMin + m
            val r = uVisMax - m
            if (l < r) {
                if (boatU[i] < l) { boatU[i] = l; boatV[i] = abs(boatV[i]); boatB[i] = abs(boatB[i]) }
                else if (boatU[i] > r) { boatU[i] = r; boatV[i] = -abs(boatV[i]); boatB[i] = -abs(boatB[i]) }
            } else boatU[i] = (uVisMin + uVisMax) / 2f
            val ta = atan(slope * 2.5f).coerceIn(-0.6f, 0.6f)
            boatA[i] += (ta - boatA[i]) * min(1f, 6f * dt)
        }
    }

    private fun surfAt(u: Float): Float {
        val idx = ((u - uMin) / du).roundToInt().coerceIn(0, N - 1)
        return level + hh[idx] + ambC[idx]
    }

    override fun draw(c: Canvas) {
        val w = e.w.toFloat()
        val h = e.h.toFloat()
        val dp = e.dp
        val D = hypot(w, h) / 2f
        val base = if (e.waterOwn) Color.HSVToColor(floatArrayOf(e.whue, e.wsat, 1f)) else e.color

        for (s in stones) drawStone(c, s)

        c.save()
        c.translate(w / 2f, h / 2f)
        c.rotate(-gAng * 57.29578f)

        // back wave
        spath.reset()
        for (i in 0 until N) {
            val u = uMin + i * du
            val y = level - 9f * dp + sin(u / (60f * dp) + e.t * 1.1f + 1.5f) * 5f * dp + hh[i] * 0.5f
            if (i == 0) spath.moveTo(u, y) else spath.lineTo(u, y)
        }
        spath.lineTo(uMin + (N - 1) * du, D * 2f)
        spath.lineTo(uMin, D * 2f)
        spath.close()
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = Color.argb(95, Color.red(base), Color.green(base), Color.blue(base))
        c.drawPath(spath, p)

        // boats
        if (anyVis) {
            for (i in 0 until e.boats.coerceIn(0, 5)) {
                val y = surfAt(boatU[i])
                BoatArt.draw(c, p, boatU[i], y, 26f * dp, e.bstyle, boatA[i] * 57.29578f)
            }
        }

        // main water body
        path.reset()
        surf.reset()
        for (i in 0 until N) {
            val u = uMin + i * du
            val y = level + hh[i] + ambC[i]
            if (i == 0) { path.moveTo(u, y); surf.moveTo(u, y) } else { path.lineTo(u, y); surf.lineTo(u, y) }
        }
        path.lineTo(uMin + (N - 1) * du, D * 2f)
        path.lineTo(uMin, D * 2f)
        path.close()
        val top = Color.argb(215, Color.red(shade(base, 0.85f)), Color.green(shade(base, 0.85f)), Color.blue(shade(base, 0.85f)))
        val bot = Color.argb(245, Color.red(shade(base, 0.25f)), Color.green(shade(base, 0.25f)), Color.blue(shade(base, 0.25f)))
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, level - 40f * dp, 0f, level + 700f * dp, top, bot, Shader.TileMode.CLAMP)
        c.drawPath(path, p)
        p.shader = null

        // bubbles
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * dp
        p.color = Color.argb(90, 255, 255, 255)
        for (i in 0 until 16) {
            c.drawCircle(bu[i], surfAt(bu[i]) + bd[i], (2f + (i % 3)) * dp, p)
        }

        // surface highlight
        p.strokeWidth = 2f * dp
        p.color = Color.argb(150, 255, 255, 255)
        c.drawPath(surf, p)
        c.restore()

        // droplets
        p.style = Paint.Style.FILL
        for (d in drops) {
            p.color = Color.argb((d.life.coerceIn(0f, 1f) * 220).toInt(), 210, 235, 255)
            c.drawCircle(d.x, d.y, 2.6f * dp, p)
        }
    }

    private fun drawStone(c: Canvas, s: Stone) {
        path.reset()
        for (k in 0 until 8) {
            val a = s.rot + k * 0.7854f
            val rr = s.r * s.shape[k]
            val px = s.x + cos(a) * rr
            val py = s.y + sin(a) * rr
            if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = Color.rgb((150 * s.tone).toInt(), (154 * s.tone).toInt(), (162 * s.tone).toInt())
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * e.dp
        p.color = Color.argb(140, 20, 22, 30)
        c.drawPath(path, p)
        p.style = Paint.Style.FILL
        p.color = Color.argb(70, 255, 255, 255)
        c.drawCircle(s.x - s.r * 0.3f, s.y - s.r * 0.3f, s.r * 0.2f, p)
    }
}
