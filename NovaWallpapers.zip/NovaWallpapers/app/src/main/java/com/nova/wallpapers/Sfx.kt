package com.nova.wallpapers

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.*

/** Procedurally generated sound effects (no audio files needed). */
class Sfx(private val ctx: Context) {
    private val sr = 22050
    private val twoPi = (2.0 * Math.PI).toFloat()
    private var pool: SoundPool? = null
    private val ids = ConcurrentHashMap<String, Int>()
    private val loaded = ConcurrentHashMap<Int, Boolean>()
    private val last = ConcurrentHashMap<String, Long>()
    @Volatile private var enabled = true
    @Volatile private var master = 0.5f
    private var owner: Any? = null
    private var loopName: String? = null
    private var loopLevel = 0f
    private var stream = 0
    private var streamName: String? = null

    fun start() {
        Thread {
            try { build() } catch (_: Exception) { }
        }.start()
    }

    fun release() {
        synchronized(this) {
            try { pool?.release() } catch (_: Exception) { }
            pool = null
            stream = 0
            streamName = null
        }
    }

    @Synchronized
    fun configure(on: Boolean, vol: Float) {
        enabled = on
        master = vol.coerceIn(0f, 1f)
        applyLoop()
    }

    fun play(name: String, vol: Float, rate: Float) {
        if (!enabled) return
        val p = pool ?: return
        val id = ids[name] ?: return
        if (loaded[id] != true) return
        val now = System.currentTimeMillis()
        val prev = last[name] ?: 0L
        if (now - prev < 70L) return
        last[name] = now
        val v = (vol * master).coerceIn(0f, 1f)
        if (v < 0.01f) return
        try { p.play(id, v, v, 1, 0, rate.coerceIn(0.5f, 2f)) } catch (_: Exception) { }
    }

    @Synchronized
    fun setLoop(who: Any, name: String?, level: Float) {
        owner = who
        loopName = name
        loopLevel = level
        applyLoop()
    }

    @Synchronized
    fun clearLoop(who: Any) {
        if (owner === who) {
            loopName = null
            owner = null
            applyLoop()
        }
    }

    @Synchronized
    fun setLevel(level: Float) {
        loopLevel = level
        applyLoop()
    }

    private fun vol() = (loopLevel * master).coerceIn(0f, 1f)

    @Synchronized
    private fun applyLoop() {
        val p = pool ?: return
        val want = if (enabled) loopName else null
        try {
            if (want != streamName) {
                if (stream != 0) { p.stop(stream); stream = 0 }
                streamName = null
                if (want != null) {
                    val id = ids[want]
                    if (id != null && loaded[id] == true) {
                        val v = vol()
                        stream = p.play(id, v, v, 1, -1, 1f)
                        if (stream != 0) streamName = want
                    }
                }
            } else if (stream != 0) {
                val v = vol()
                p.setVolume(stream, v, v)
            }
        } catch (_: Exception) { }
    }

    // ---------- building ----------
    private fun build() {
        val sounds = LinkedHashMap<String, FloatArray>()
        sounds["splash"] = splash()
        sounds["plop"] = plop()
        sounds["flow"] = flow()
        sounds["rain"] = rain()
        sounds["wind"] = wind()
        sounds["hum"] = hum()
        sounds["boom"] = boom()
        sounds["whoosh"] = whoosh()
        sounds["chime"] = chime()
        sounds["tick"] = tick()
        sounds["thud"] = thud()
        sounds["thunder"] = thunder()
        sounds["fizz"] = fizz()
        sounds["pop"] = pop()
        val sp = SoundPool.Builder()
            .setMaxStreams(12)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()
        sp.setOnLoadCompleteListener { _, id, status ->
            if (status == 0) {
                loaded[id] = true
                applyLoop()
            }
        }
        pool = sp
        for ((name, data) in sounds) {
            val f = File(ctx.cacheDir, "sfx_v1_$name.wav")
            writeWav(f, data)
            ids[name] = sp.load(f.absolutePath, 1)
        }
    }

    private fun writeWav(f: File, x: FloatArray) {
        val n = x.size
        val bb = ByteBuffer.allocate(44 + n * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + n * 2); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1)
        bb.putInt(sr); bb.putInt(sr * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(n * 2)
        for (v in x) bb.putShort((v.coerceIn(-1f, 1f) * 32000f).toInt().toShort())
        FileOutputStream(f).use { it.write(bb.array()) }
    }

    // ---------- synthesis helpers ----------
    private fun white(n: Int, seed: Long): FloatArray {
        val r = Random(seed)
        return FloatArray(n) { r.nextFloat() * 2f - 1f }
    }

    private fun norm(x: FloatArray, peak: Float = 0.9f): FloatArray {
        var m = 1e-6f
        for (v in x) m = max(m, abs(v))
        val k = peak / m
        for (i in x.indices) x[i] *= k
        return x
    }

    private fun lowpass(x: FloatArray, fc: Float) {
        val a = 1f - exp(-twoPi * fc / sr)
        var y = 0f
        for (i in x.indices) { y += a * (x[i] - y); x[i] = y }
    }

    private fun sweepLp(x: FloatArray, f0: Float, f1: Float) {
        var y = 0f
        val n = x.size
        for (i in 0 until n) {
            val fc = f0 * (f1 / f0).pow(i.toFloat() / n)
            val a = 1f - exp(-twoPi * fc / sr)
            y += a * (x[i] - y)
            x[i] = y
        }
    }

    private fun loopify(x: FloatArray, len: Int): FloatArray {
        val f = x.size - len
        val out = FloatArray(len)
        for (i in 0 until len) {
            out[i] = if (i < f) {
                val w = i.toFloat() / f
                x[i] * w + x[len + i] * (1f - w)
            } else x[i]
        }
        return out
    }

    private fun t(i: Int) = i / sr.toFloat()

    // ---------- the sounds ----------
    private fun splash(): FloatArray {
        val n = (0.7f * sr).toInt()
        val x = white(n, 1)
        sweepLp(x, 6000f, 600f)
        for (i in 0 until n) x[i] *= exp(-t(i) * 6f) * min(1f, t(i) * 200f)
        for (i in 0 until n) {
            val tt = t(i) - 0.03f
            if (tt > 0f && tt < 0.4f) {
                val ph = twoPi * (320f * tt + 450f * tt * tt)
                x[i] += sin(ph) * exp(-tt * 14f) * 0.5f
            }
        }
        return norm(x)
    }

    private fun plop(): FloatArray {
        val n = (0.2f * sr).toInt()
        val x = FloatArray(n)
        for (i in 0 until n) {
            val tt = t(i)
            x[i] = sin(twoPi * (500f * tt + 4000f * tt * tt)) * exp(-tt * 20f) * min(1f, tt * 400f)
        }
        return norm(x, 0.8f)
    }

    private fun flow(): FloatArray {
        val len = (2.4f * sr).toInt()
        val fade = (0.25f * sr).toInt()
        val a = white(len + fade, 11); lowpass(a, 450f)
        val b = white(len + fade, 12); lowpass(b, 1600f)
        for (i in a.indices) a[i] += b[i] * 0.3f
        val out = loopify(a, len)
        for (i in 0 until len) {
            out[i] *= 0.65f + 0.35f * sin(twoPi * i / len) + 0.1f * sin(twoPi * 3f * i / len)
        }
        return norm(out, 0.85f)
    }

    private fun rain(): FloatArray {
        val len = (2.0f * sr).toInt()
        val fade = (0.2f * sr).toInt()
        val a = white(len + fade, 21)
        val lo = a.copyOf(); lowpass(lo, 1200f)
        for (i in a.indices) a[i] -= lo[i]
        lowpass(a, 7000f)
        return norm(loopify(a, len), 0.8f)
    }

    private fun wind(): FloatArray {
        val len = (3.0f * sr).toInt()
        val fade = (0.3f * sr).toInt()
        val a = white(len + fade, 31); lowpass(a, 320f)
        val b = white(len + fade, 32); lowpass(b, 800f)
        for (i in a.indices) a[i] += b[i] * 0.4f
        val out = loopify(a, len)
        for (i in 0 until len) {
            out[i] *= 0.6f + 0.25f * sin(twoPi * i / len) + 0.15f * sin(twoPi * 3f * i / len + 1f)
        }
        return norm(out, 0.8f)
    }

    private fun hum(): FloatArray {
        val len = 2 * sr
        val x = FloatArray(len)
        for (i in 0 until len) {
            val tt = t(i)
            val v = 0.5f * sin(twoPi * 55f * tt) + 0.4f * sin(twoPi * 55.5f * tt) +
                0.3f * sin(twoPi * 82.5f * tt) + 0.2f * sin(twoPi * 110f * tt)
            x[i] = v * (0.85f + 0.15f * sin(twoPi * 0.5f * tt))
        }
        return norm(x, 0.8f)
    }

    private fun boom(): FloatArray {
        val n = (1.5f * sr).toInt()
        val x = white(n, 41)
        sweepLp(x, 1200f, 90f)
        for (i in 0 until n) {
            val tt = t(i)
            x[i] = x[i] * 3f * exp(-tt * 2.6f) +
                sin(twoPi * (35f * tt + 15f * (1f - exp(-3f * tt)))) * exp(-tt * 2.2f) * 1.2f
        }
        val crack = white((0.02f * sr).toInt(), 42)
        for (i in crack.indices) x[i] += crack[i] * (1f - i / crack.size.toFloat()) * 0.9f
        return norm(x, 0.95f)
    }

    private fun whoosh(): FloatArray {
        val n = (0.8f * sr).toInt()
        val w = white(n, 51)
        val x = FloatArray(n)
        var y1 = 0f
        var y2 = 0f
        for (i in 0 until n) {
            val ph = i.toFloat() / n
            val f = 400f + 2600f * sin(Math.PI.toFloat() * ph)
            val a1 = 1f - exp(-twoPi * f * 1.5f / sr)
            val a2 = 1f - exp(-twoPi * f * 0.6f / sr)
            y1 += a1 * (w[i] - y1)
            y2 += a2 * (w[i] - y2)
            val s = sin(Math.PI.toFloat() * ph)
            x[i] = (y1 - y2) * s * s
        }
        return norm(x, 0.8f)
    }

    private fun chime(): FloatArray {
        val n = (1.4f * sr).toInt()
        val x = FloatArray(n)
        val parts = floatArrayOf(1f, 2.76f, 5.4f)
        val amps = floatArrayOf(1f, 0.35f, 0.15f)
        for (i in 0 until n) {
            val tt = t(i)
            var v = 0f
            for (k in parts.indices) v += amps[k] * sin(twoPi * 880f * parts[k] * tt) * exp(-tt * (2.5f + k * 2f))
            x[i] = v * min(1f, tt * 300f)
        }
        return norm(x, 0.7f)
    }

    private fun tick(): FloatArray {
        val n = (0.06f * sr).toInt()
        val w = white(n, 61)
        val x = FloatArray(n)
        for (i in 0 until n) {
            val tt = t(i)
            x[i] = sin(twoPi * 2200f * tt) * exp(-tt * 80f) + w[i] * exp(-tt * 140f) * 0.5f
        }
        return norm(x, 0.7f)
    }

    private fun thud(): FloatArray {
        val n = (0.3f * sr).toInt()
        val w = white(n, 71)
        lowpass(w, 500f)
        val x = FloatArray(n)
        for (i in 0 until n) {
            val tt = t(i)
            x[i] = sin(twoPi * (50f * tt + 70f / 25f * (1f - exp(-25f * tt)))) * exp(-tt * 14f) +
                w[i] * 2f * exp(-tt * 40f)
        }
        return norm(x, 0.85f)
    }

    private fun thunder(): FloatArray {
        val n = (2.6f * sr).toInt()
        val x = white(n, 81)
        sweepLp(x, 320f, 70f)
        for (i in 0 until n) {
            val tt = t(i)
            x[i] *= (1f - exp(-tt * 30f)) * exp(-tt * 1.1f) * (0.7f + 0.3f * sin(twoPi * 3.3f * tt + 1f))
        }
        val crack = white((0.04f * sr).toInt(), 82)
        lowpass(crack, 2500f)
        for (i in crack.indices) x[i] += crack[i] * 6f * (1f - i / crack.size.toFloat())
        return norm(x, 0.95f)
    }

    private fun fizz(): FloatArray {
        val n = (0.7f * sr).toInt()
        val a = white(n, 91)
        val lo = a.copyOf(); lowpass(lo, 2500f)
        val x = FloatArray(n)
        for (i in 0 until n) {
            val s = sin(Math.PI.toFloat() * i / n)
            x[i] = (a[i] - lo[i]) * s.pow(0.7f)
        }
        return norm(x, 0.7f)
    }

    private fun pop(): FloatArray {
        val n = (0.6f * sr).toInt()
        val x = white(n, 101)
        sweepLp(x, 3500f, 300f)
        for (i in 0 until n) x[i] *= exp(-t(i) * 9f)
        val r = Random(102)
        for (k in 0 until 14) {
            val at = (r.nextFloat() * 0.5f * sr).toInt()
            for (j in 0 until 25) if (at + j < n) x[at + j] += (r.nextFloat() * 2f - 1f) * 0.35f * (1f - j / 25f)
        }
        return norm(x, 0.85f)
    }
}
