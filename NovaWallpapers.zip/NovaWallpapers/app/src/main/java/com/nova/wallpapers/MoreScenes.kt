package com.nova.wallpapers

import android.graphics.*
import kotlin.math.*
import kotlin.random.Random

// ---------- Confetti / hearts / falling stars / embers / dust / leaves ----------
class ShapeRain(e: Env, private val kind: Int) :
    ParticleScene(e, when (kind) { 0 -> 90; 1 -> 40; 2 -> 50; 3 -> 100; 4 -> 80; else -> 45 }, 250) {
    override val canBounceY = false
    override val touchSound: String? = if (kind == 0 || kind == 1) "chime" else null
    private val hOff = FloatArray(250)
    private val path = Path()
    private val rect = RectF()
    private val leafCols = listOf("#6BAA3F", "#E0A030", "#C8502A", "#8DBF4E").map { Color.parseColor(it) }

    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        val dp = e.dp
        when (kind) {
            0 -> { a[i] = rf(-15f, 15f) * dp; b[i] = rf(40f, 110f) * dp; s[i] = rf(4f, 8f); w[i] = rf(-4f, 4f); hOff[i] = Random.nextInt(6) * 60f }
            1 -> { a[i] = rf(-12f, 12f) * dp; b[i] = -rf(30f, 70f) * dp; s[i] = rf(6f, 14f); w[i] = rf(-1f, 1f); hOff[i] = rf(-20f, 30f) }
            2 -> { a[i] = rf(-10f, 10f) * dp; b[i] = rf(40f, 90f) * dp; s[i] = rf(6f, 12f); w[i] = rf(-1.5f, 1.5f); hOff[i] = rf(-30f, 30f) }
            3 -> { a[i] = rf(-20f, 20f) * dp; b[i] = -rf(40f, 110f) * dp; s[i] = rf(1.2f, 3.2f); w[i] = rf(2f, 5f); hOff[i] = rf(0f, 40f) }
            4 -> { a[i] = rf(-8f, 8f) * dp; b[i] = rf(-6f, 6f) * dp; s[i] = rf(0.8f, 2f); w[i] = rf(0.5f, 2f); hOff[i] = 0f }
            else -> { a[i] = rf(-14f, 14f) * dp; b[i] = rf(35f, 80f) * dp; s[i] = rf(6f, 11f); w[i] = rf(-2f, 2f); hOff[i] = Random.nextInt(4).toFloat() }
        }
        vx[i] = a[i]; vy[i] = b[i]; r[i] = rf(0f, 6.283f)
    }

    override fun update(dt: Float) = drift(dt, 2000f * e.dp)

    private fun star(rad: Float) {
        path.reset()
        for (k in 0 until 10) {
            val ang = -1.5708f + k * 0.62832f
            val rr = if (k % 2 == 0) rad else rad * 0.45f
            if (k == 0) path.moveTo(cos(ang) * rr, sin(ang) * rr) else path.lineTo(cos(ang) * rr, sin(ang) * rr)
        }
        path.close()
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            val rad = s[i] * e.dp
            when (kind) {
                0 -> {
                    c.save(); c.translate(x[i], y[i]); c.rotate(r[i] * 57.29578f)
                    p.color = hcol(hOff[i], 230)
                    rect.set(-rad, -rad * 0.5f, rad, rad * 0.5f)
                    c.drawRect(rect, p)
                    c.restore()
                }
                1 -> {
                    c.save(); c.translate(x[i] + sin(r[i]) * 8f * e.dp, y[i]); c.rotate(sin(r[i]) * 15f)
                    path.reset()
                    path.moveTo(0f, rad * 0.9f)
                    path.cubicTo(-rad * 1.4f, -rad * 0.1f, -rad * 0.5f, -rad * 1.1f, 0f, -rad * 0.3f)
                    path.cubicTo(rad * 0.5f, -rad * 1.1f, rad * 1.4f, -rad * 0.1f, 0f, rad * 0.9f)
                    p.color = hcol(hOff[i], 210)
                    c.drawPath(path, p)
                    c.restore()
                }
                2 -> {
                    c.save(); c.translate(x[i], y[i]); c.rotate(r[i] * 57.29578f)
                    star(rad)
                    p.color = hcol(hOff[i], 220)
                    c.drawPath(path, p)
                    c.restore()
                }
                3 -> {
                    val fl = 0.6f + 0.4f * sin(r[i])
                    p.color = Color.argb((40 * fl).toInt(), 255, 140, 50)
                    c.drawCircle(x[i], y[i], rad * 4f, p)
                    p.color = Color.argb((120 * fl).toInt(), 255, 170 + (hOff[i]).toInt(), 60)
                    c.drawCircle(x[i], y[i], rad * 2f, p)
                    p.color = Color.argb((230 * fl).toInt(), 255, 235, 190)
                    c.drawCircle(x[i], y[i], rad * 0.8f, p)
                }
                4 -> {
                    p.color = col((30 + (0.5f + 0.5f * sin(r[i])) * 130).toInt())
                    c.drawCircle(x[i], y[i], rad, p)
                }
                else -> {
                    c.save(); c.translate(x[i] + sin(r[i] * 0.7f) * 10f * e.dp, y[i]); c.rotate(r[i] * 57.29578f)
                    p.color = leafCols[hOff[i].toInt().coerceIn(0, 3)]
                    rect.set(-rad, -rad * 0.5f, rad, rad * 0.5f)
                    c.drawOval(rect, p)
                    p.color = Color.argb(90, 0, 0, 0)
                    c.drawRect(-rad, -rad * 0.04f, rad, rad * 0.04f, p)
                    c.restore()
                }
            }
        }
    }
}

// ---------- Birds / fish (flocking) ----------
class Boids(e: Env, private val fish: Boolean) : Scene(e) {
    override val touchSound: String? = if (fish) "plop" else "whoosh"
    private val cap = 120
    private val x = FloatArray(cap)
    private val y = FloatArray(cap)
    private val vx = FloatArray(cap)
    private val vy = FloatArray(cap)
    private var n = 0
    private val path = Path()

    override fun reset() {
        n = (70 * e.amount).toInt().coerceIn(20, cap)
        val s0 = (if (fish) 70f else 110f) * e.dp
        for (i in 0 until n) {
            x[i] = rf(0f, e.w.toFloat()); y[i] = rf(0f, e.h.toFloat())
            val a = rf(0f, 6.283f)
            vx[i] = cos(a) * s0; vy[i] = sin(a) * s0
        }
    }

    override fun update(dt: Float) {
        val dp = e.dp
        val s0 = (if (fish) 70f else 110f) * dp
        val view = 80f * dp
        val v2 = view * view
        val sep = 24f * dp
        val s2 = sep * sep
        val sw = e.w.toFloat()
        val sh = e.h.toFloat()
        for (i in 0 until n) {
            var cnt = 0
            var avx = 0f; var avy = 0f; var apx = 0f; var apy = 0f; var sx = 0f; var sy = 0f
            for (j in 0 until n) {
                if (j == i) continue
                val dx = x[j] - x[i]; val dy = y[j] - y[i]
                val d2 = dx * dx + dy * dy
                if (d2 < v2) {
                    cnt++
                    avx += vx[j]; avy += vy[j]; apx += x[j]; apy += y[j]
                    if (d2 < s2 && d2 > 0.01f) { sx -= dx / d2 * sep; sy -= dy / d2 * sep }
                }
            }
            var ax = sx * 60f * dp
            var ay = sy * 60f * dp
            if (cnt > 0) {
                ax += (avx / cnt - vx[i]) * 1.5f + (apx / cnt - x[i]) * 0.8f
                ay += (avy / cnt - vy[i]) * 1.5f + (apy / cnt - y[i]) * 0.8f
            }
            touchForce(x[i], y[i], 2600f * dp)
            ax += fx; ay += fy
            vx[i] += ax * dt; vy[i] += ay * dt
            val sp = sqrt(vx[i] * vx[i] + vy[i] * vy[i])
            val lo = 0.6f * s0
            val hi = 1.5f * s0
            if (sp < lo && sp > 0.01f) { vx[i] *= lo / sp; vy[i] *= lo / sp }
            if (sp > hi) { vx[i] *= hi / sp; vy[i] *= hi / sp }
            x[i] += vx[i] * dt * e.speed
            y[i] += vy[i] * dt * e.speed
            val m = 20f * dp
            if (e.bounce) {
                if (x[i] < 0f) { x[i] = 0f; vx[i] = abs(vx[i]) } else if (x[i] > sw) { x[i] = sw; vx[i] = -abs(vx[i]) }
                if (y[i] < 0f) { y[i] = 0f; vy[i] = abs(vy[i]) } else if (y[i] > sh) { y[i] = sh; vy[i] = -abs(vy[i]) }
            } else {
                if (x[i] < -m) x[i] = sw + m else if (x[i] > sw + m) x[i] = -m
                if (y[i] < -m) y[i] = sh + m else if (y[i] > sh + m) y[i] = -m
            }
        }
    }

    override fun draw(c: Canvas) {
        val sz = (if (fish) 9f else 7f) * e.dp
        for (i in 0 until n) {
            val ang = atan2(vy[i], vx[i]) * 57.29578f
            c.save(); c.translate(x[i], y[i]); c.rotate(ang)
            if (fish) {
                p.style = Paint.Style.FILL
                p.color = hcol((i % 5) * 18f, 230)
                path.reset()
                path.moveTo(sz, 0f); path.quadTo(0f, -sz * 0.7f, -sz, 0f); path.quadTo(0f, sz * 0.7f, sz, 0f)
                c.drawPath(path, p)
                path.reset()
                path.moveTo(-sz * 0.8f, 0f); path.lineTo(-sz * 1.6f, -sz * 0.6f); path.lineTo(-sz * 1.6f, sz * 0.6f); path.close()
                c.drawPath(path, p)
            } else {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f * e.dp
                p.color = col(230)
                val flap = sin(e.t * 9f + i) * sz * 0.5f
                path.reset()
                path.moveTo(-sz * 0.6f, -sz + flap); path.lineTo(sz * 0.3f, 0f); path.lineTo(-sz * 0.6f, sz - flap)
                c.drawPath(path, p)
            }
            c.restore()
        }
    }
}

// ---------- Sunflower (phyllotaxis) ----------
class Sunflower(e: Env) : Scene(e) {
    override val touchSound: String? = "chime"
    override fun reset() {}
    override fun update(dt: Float) {}
    override fun draw(c: Canvas) {
        val n = (320 * e.amount).toInt().coerceIn(80, 520)
        val cx = e.w / 2f
        val cy = e.h / 2f
        val sc = min(e.w, e.h) * 0.46f / sqrt(n.toFloat())
        val rot = e.t * 0.15f * e.speed
        p.style = Paint.Style.FILL
        for (i in 1..n) {
            val a = i * 2.39996f + rot
            val rr = sc * sqrt(i.toFloat())
            var px = cx + cos(a) * rr
            var py = cy + sin(a) * rr
            if (e.touching && e.touchOn) {
                val dx = e.tx - px; val dy = e.ty - py
                val d = sqrt(dx * dx + dy * dy)
                if (d > 1f && d < e.radius) { val k = (1f - d / e.radius) * 0.7f * e.dir; px += dx * k; py += dy * k }
            }
            p.color = hcol(i * 0.35f, 230)
            c.drawCircle(px, py, (1.5f + rr / (min(e.w, e.h) * 0.46f) * 4f) * e.dp, p)
        }
    }
}

// ---------- Kaleidoscope ----------
class Kaleido(e: Env) : Scene(e) {
    override val touchSound: String? = "chime"
    private var cx = 0f
    private var cy = 0f
    override fun reset() { cx = e.w / 2f; cy = e.h / 2f }
    override fun update(dt: Float) {
        var tx = e.w / 2f; var ty = e.h / 2f
        if (e.touching && e.touchOn) { tx += (e.tx - tx) * 0.5f * e.dir; ty += (e.ty - ty) * 0.5f * e.dir }
        val sm = min(1f, 4f * dt)
        cx += (tx - cx) * sm; cy += (ty - cy) * sm
    }
    override fun draw(c: Canvas) {
        val dp = e.dp
        val t = e.t * e.speed
        p.style = Paint.Style.FILL
        for (k in 0 until 8) {
            for (mir in 0..1) {
                c.save()
                c.translate(cx, cy)
                c.rotate(k * 45f + t * 8f)
                if (mir == 1) c.scale(1f, -1f)
                for (j in 0 until 5) {
                    val rr = (50f + j * 55f) * dp
                    val py = sin(t * 0.8f + j * 1.3f) * 45f * dp
                    p.color = hcol(j * 30f + k * 4f, 150)
                    c.drawCircle(rr, py, (10f + j * 5f) * dp * (0.7f + 0.3f * sin(t + j)), p)
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 1.5f * dp
                    p.color = hcol(j * 30f + 60f, 120)
                    c.drawLine(rr, py, rr + 55f * dp, sin(t * 0.8f + (j + 1) * 1.3f) * 45f * dp, p)
                    p.style = Paint.Style.FILL
                }
                c.restore()
            }
        }
    }
}

// ---------- Rose curves ----------
class RoseCurve(e: Env) : Scene(e) {
    override val touchSound: String? = "chime"
    private val path = Path()
    private var cx = 0f
    private var cy = 0f
    override fun reset() { cx = e.w / 2f; cy = e.h / 2f }
    override fun update(dt: Float) {
        var tx = e.w / 2f; var ty = e.h / 2f
        if (e.touching && e.touchOn) { tx += (e.tx - tx) * 0.5f * e.dir; ty += (e.ty - ty) * 0.5f * e.dir }
        val sm = min(1f, 4f * dt)
        cx += (tx - cx) * sm; cy += (ty - cy) * sm
    }
    override fun draw(c: Canvas) {
        val big = min(e.w, e.h) * 0.45f
        val k = 3f + 2f * sin(e.t * 0.1f * e.speed)
        p.style = Paint.Style.STROKE
        for (layer in 0 until 3) {
            path.reset()
            for (i in 0..720) {
                val th = i / 720f * 12.566f
                val rr = big * cos(k * th) * (1f - layer * 0.18f)
                val a = th + e.t * 0.2f * e.speed + layer * 0.15f
                val px = cx + cos(a) * rr
                val py = cy + sin(a) * rr
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            p.strokeWidth = (4f - layer) * e.dp
            p.color = hcol(layer * 50f, 110 + layer * 50)
            c.drawPath(path, p)
        }
    }
}

// ---------- Radar ----------
class Radar(e: Env) : Scene(e) {
    override val touchSound: String? = "tick"
    private val bx = FloatArray(10)
    private val by = FloatArray(10)
    private var next = 0
    override fun reset() {
        for (i in 0 until 10) { bx[i] = rf(-1f, 1f); by[i] = rf(-1f, 1f) }
    }
    override fun update(dt: Float) {
        if (justTouched && e.touchOn) {
            val cx = e.w / 2f; val cy = e.h / 2f; val r = min(e.w, e.h) * 0.46f
            bx[next] = (e.tx - cx) / r; by[next] = (e.ty - cy) / r
            next = (next + 1) % 10
        }
    }
    override fun draw(c: Canvas) {
        val cx = e.w / 2f
        val cy = e.h / 2f
        val r = min(e.w, e.h) * 0.46f
        val sweep = e.t * 1.2f * e.speed
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * e.dp
        p.color = col(70)
        for (k in 1..4) c.drawCircle(cx, cy, r * k / 4f, p)
        c.drawLine(cx - r, cy, cx + r, cy, p)
        c.drawLine(cx, cy - r, cx, cy + r, p)
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        p.style = Paint.Style.FILL
        for (k in 0 until 24) {
            p.color = col(((1f - k / 24f) * 110).toInt())
            c.drawArc(rect, (sweep * 57.29578f) - k * 3f, 3f, true, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.5f * e.dp
        p.color = col(255)
        c.drawLine(cx, cy, cx + cos(sweep) * r, cy + sin(sweep) * r, p)
        p.style = Paint.Style.FILL
        for (i in 0 until 10) {
            val ba = atan2(by[i], bx[i])
            var diff = (sweep - ba) % 6.2832f
            if (diff < 0f) diff += 6.2832f
            val al = exp(-diff * 1.2f)
            p.color = col((al * 255).toInt())
            c.drawCircle(cx + bx[i] * r, cy + by[i] * r, 5f * e.dp * (0.6f + al * 0.6f), p)
        }
    }
}

// ---------- Mountains (parallax sunset) ----------
class Mountains(e: Env) : Scene(e) {
    private var off = 0f
    private val path = Path()
    override fun reset() { off = 0f }
    override fun update(dt: Float) {
        val target = if (e.touching && e.touchOn) (e.tx - e.w / 2f) / e.w * e.dir else 0f
        off += (target - off) * min(1f, 3f * dt)
    }
    override fun draw(c: Canvas) {
        val w = e.w.toFloat()
        val h = e.h.toFloat()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h * 0.7f, hcol(-50f, 255), hcol(30f, 255), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        p.color = Color.argb(230, 255, 240, 200)
        c.drawCircle(w * 0.68f - off * w * 0.04f, h * 0.36f, w * 0.12f, p)
        for (l in 0 until 5) {
            val base = h * (0.5f + l * 0.1f)
            val amp = h * (0.07f - l * 0.006f)
            val shift = e.t * (4f + l * 6f) * e.speed * e.dp + off * w * (0.05f + l * 0.06f)
            path.reset()
            path.moveTo(0f, h)
            var x = 0f
            while (x <= w + 10f) {
                val u = (x + shift) / (110f * e.dp * (1f + l * 0.25f))
                val y = base + sin(u + l * 2f) * amp + sin(u * 2.3f + l) * amp * 0.45f
                path.lineTo(x, y)
                x += 10f
            }
            path.lineTo(w + 10f, h)
            path.close()
            val f = 0.55f - l * 0.1f
            p.color = Color.rgb((Color.red(e.color) * f * 0.5f).toInt() + 10, (Color.green(e.color) * f * 0.5f).toInt() + 10, (Color.blue(e.color) * f * 0.6f).toInt() + 20)
            c.drawPath(path, p)
        }
    }
}

// ---------- Night city ----------
class NightCity(e: Env) : Scene(e) {
    override val touchSound: String? = "tick"
    private val bx = Array(3) { FloatArray(40) }
    private val bw = Array(3) { FloatArray(40) }
    private val bh = Array(3) { FloatArray(40) }
    private var off = 0f
    private val stars = StarField(80)
    override fun reset() {
        for (l in 0 until 3) {
            var x = -20f * e.dp
            for (i in 0 until 40) {
                bw[l][i] = rf(34f, 80f) * e.dp * (1f + (2 - l) * 0.2f)
                bh[l][i] = rf(0.12f, 0.32f) * e.h * (1f + (2 - l) * 0.25f) * (0.6f + l * 0.2f)
                bx[l][i] = x
                x += bw[l][i] + rf(0f, 8f) * e.dp
            }
        }
    }
    override fun update(dt: Float) {
        val target = if (e.touching && e.touchOn) (e.tx - e.w / 2f) / e.w * e.dir else 0f
        off += (target - off) * min(1f, 3f * dt)
    }
    override fun draw(c: Canvas) {
        val h = e.h.toFloat()
        stars.draw(c, p, e)
        p.style = Paint.Style.FILL
        for (l in 0 until 3) {
            val sh = off * e.w * (0.03f + l * 0.05f)
            for (i in 0 until 40) {
                val x0 = bx[l][i] - sh
                if (x0 > e.w || x0 + bw[l][i] < 0f) continue
                val top = h - bh[l][i]
                val f = 0.35f + l * 0.25f
                p.color = Color.rgb((Color.red(e.color) * 0.12f * f).toInt() + 8, (Color.green(e.color) * 0.12f * f).toInt() + 9, (Color.blue(e.color) * 0.16f * f).toInt() + 16)
                c.drawRect(x0, top, x0 + bw[l][i], h, p)
                if (l == 2) {
                    val ws = 6f * e.dp
                    val gap = 11f * e.dp
                    val cols = ((bw[l][i] - 8f * e.dp) / gap).toInt().coerceAtLeast(1)
                    val rows = ((bh[l][i] - 12f * e.dp) / gap).toInt().coerceIn(1, 14)
                    for (rr in 0 until rows) for (cc in 0 until cols) {
                        val hs = (i * 31 + rr * 17 + cc * 7 + (e.t * 0.25f).toInt() * (if ((i + rr + cc) % 5 == 0) 1 else 0)) % 7
                        var lit = hs < 3
                        val wx = x0 + 6f * e.dp + cc * gap
                        val wy = top + 8f * e.dp + rr * gap
                        if (e.touching && e.touchOn && hypot(wx - e.tx, wy - e.ty) < e.radius) lit = true
                        if (lit) {
                            p.color = Color.argb(220, 255, 220, 140)
                            c.drawRect(wx, wy, wx + ws, wy + ws, p)
                        }
                    }
                }
            }
        }
    }
}

// ---------- Jellyfish ----------
class Jellyfish(e: Env) : ParticleScene(e, 6, 12) {
    override val marginDp = 120f
    override val touchSound: String? = "plop"
    private val path = Path()
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        a[i] = rf(-6f, 6f) * e.dp; b[i] = -rf(10f, 25f) * e.dp
        vx[i] = a[i]; vy[i] = b[i]
        s[i] = rf(24f, 50f); r[i] = rf(0f, 6.283f); w[i] = rf(1.5f, 2.5f)
    }
    override fun update(dt: Float) = drift(dt, 1800f * e.dp)
    override fun draw(c: Canvas) {
        val rect = RectF()
        for (i in 0 until n) {
            val pulse = 0.85f + 0.15f * sin(r[i])
            val bw = s[i] * e.dp * pulse
            val bh = s[i] * e.dp * (1.1f - 0.2f * pulse)
            p.style = Paint.Style.FILL
            p.color = hcol(i * 25f, 110)
            rect.set(x[i] - bw, y[i] - bh, x[i] + bw, y[i] + bh)
            c.drawArc(rect, 180f, 180f, true, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.5f * e.dp
            p.color = hcol(i * 25f, 200)
            c.drawArc(rect, 180f, 180f, false, p)
            p.color = hcol(i * 25f, 120)
            for (t in -2..2) {
                path.reset()
                val sx = x[i] + t * bw * 0.4f
                path.moveTo(sx, y[i])
                for (k in 1..7) {
                    path.lineTo(sx + sin(r[i] * 0.7f + k * 0.9f + t) * s[i] * 0.12f * e.dp, y[i] + k * s[i] * 0.3f * e.dp)
                }
                c.drawPath(path, p)
            }
        }
    }
}

// ---------- Flow field ----------
class FlowField(e: Env) : ParticleScene(e, 250, 400) {
    override val touchSound: String? = "whoosh"
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        s[i] = rf(0.6f, 1.4f)
        r[i] = rf(0f, 360f)
    }
    private fun field(px: Float, py: Float): Float =
        (sin(px / (140f * e.dp) + e.t * 0.3f) + cos(py / (120f * e.dp) - e.t * 0.25f)) * 3.1416f
    override fun update(dt: Float) {
        val sw = e.w.toFloat(); val sh = e.h.toFloat()
        for (i in 0 until n) {
            val th = field(x[i], y[i])
            val sp = 70f * e.dp * s[i] * e.speed
            touchForce(x[i], y[i], 2200f * e.dp)
            vx[i] = cos(th) * sp + fx * 0.3f
            vy[i] = sin(th) * sp + fy * 0.3f
            x[i] += vx[i] * dt; y[i] += vy[i] * dt
            r[i] = th * 57.29578f
            if (x[i] < 0f || x[i] > sw || y[i] < 0f || y[i] > sh) { x[i] = rf(0f, sw); y[i] = rf(0f, sh) }
        }
    }
    override fun draw(c: Canvas) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f * e.dp
        for (i in 0 until n) {
            p.color = hcol(r[i] * 0.3f, 150)
            c.drawLine(x[i] - vx[i] * 0.12f, y[i] - vy[i] * 0.12f, x[i], y[i], p)
        }
    }
}

// ---------- Mandala ----------
class Mandala(e: Env) : Scene(e) {
    override val touchSound: String? = "chime"
    private var cx = 0f
    private var cy = 0f
    override fun reset() { cx = e.w / 2f; cy = e.h / 2f }
    override fun update(dt: Float) {
        var tx = e.w / 2f; var ty = e.h / 2f
        if (e.touching && e.touchOn) { tx += (e.tx - tx) * 0.4f * e.dir; ty += (e.ty - ty) * 0.4f * e.dir }
        val sm = min(1f, 4f * dt)
        cx += (tx - cx) * sm; cy += (ty - cy) * sm
    }
    override fun draw(c: Canvas) {
        val rect = RectF()
        val base = min(e.w, e.h) * 0.07f
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f * e.dp
        for (j in 0 until 6) {
            val rr = base * (1.2f + j * 1.15f)
            val cnt = 8 + 2 * j
            val dir = if (j % 2 == 0) 1f else -1f
            p.color = hcol(j * 22f, 190)
            for (k in 0 until cnt) {
                c.save()
                c.translate(cx, cy)
                c.rotate(k * 360f / cnt + dir * e.t * 6f * e.speed)
                rect.set(rr - base * 0.55f, -base * 0.3f, rr + base * 0.55f, base * 0.3f)
                c.drawOval(rect, p)
                c.restore()
            }
        }
        p.style = Paint.Style.FILL
        p.color = hcol(0f, 220)
        c.drawCircle(cx, cy, base * 0.5f, p)
    }
}

// ---------- Atom ----------
class Atom(e: Env) : Scene(e) {
    override val touchSound: String? = "chime"
    private var cx = 0f
    private var cy = 0f
    override fun reset() { cx = e.w / 2f; cy = e.h / 2f }
    override fun update(dt: Float) {
        var tx = e.w / 2f; var ty = e.h / 2f
        if (e.touching && e.touchOn) { tx += (e.tx - tx) * 0.5f * e.dir; ty += (e.ty - ty) * 0.5f * e.dir }
        val sm = min(1f, 4f * dt)
        cx += (tx - cx) * sm; cy += (ty - cy) * sm
    }
    override fun draw(c: Canvas) {
        val rx = min(e.w, e.h) * 0.42f
        val ry = rx * 0.33f
        val rect = RectF(-rx, -ry, rx, ry)
        for (k in 0 until 3) {
            c.save()
            c.translate(cx, cy)
            c.rotate(k * 60f)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.5f * e.dp
            p.color = col(90)
            c.drawOval(rect, p)
            p.style = Paint.Style.FILL
            for (m in 0..1) {
                val a = e.t * (1.3f + k * 0.35f) * e.speed + m * 3.1416f + k
                p.color = hcol(k * 40f, 255)
                c.drawCircle(cos(a) * rx, sin(a) * ry, 6f * e.dp, p)
            }
            c.restore()
        }
        p.style = Paint.Style.FILL
        val gl = 40f * e.dp
        p.shader = RadialGradient(cx, cy, gl, col(160), col(0), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, gl, p)
        p.shader = null
        p.color = Color.WHITE
        c.drawCircle(cx, cy, 8f * e.dp, p)
    }
}

// ---------- Pendulum wave ----------
class Pendulum(e: Env) : Scene(e) {
    override val touchSound: String? = "chime"
    override fun reset() {}
    override fun update(dt: Float) {}
    override fun draw(c: Canvas) {
        val n = 18
        val top = e.h * 0.12f
        val len = e.h * 0.55f
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f * e.dp
        p.color = col(60)
        c.drawLine(e.w * 0.05f, top, e.w * 0.95f, top, p)
        for (i in 0 until n) {
            val px = e.w * (0.1f + 0.8f * i / (n - 1))
            val freq = (30f + i) / 60f
            val th = 0.45f * sin(6.2832f * freq * e.t * e.speed)
            val bx = px + sin(th) * len * 0.55f
            val by = top + cos(th) * len * 0.55f * (1f + 0.4f * (n - i) / n)
            p.style = Paint.Style.STROKE
            p.color = col(90)
            c.drawLine(px, top, bx, by, p)
            p.style = Paint.Style.FILL
            p.color = hcol(i * 14f, 240)
            c.drawCircle(bx, by, 11f * e.dp, p)
        }
    }
}

// ---------- Dot wave ----------
class DotWave(e: Env) : Scene(e) {
    override val touchSound: String? = "tick"
    override fun reset() {}
    override fun update(dt: Float) {}
    override fun draw(c: Canvas) {
        val sp = 22f * e.dp / e.quality.coerceIn(0.5f, 1f)
        val cols = (e.w / sp).toInt() + 1
        val rows = (e.h / sp).toInt() + 1
        p.style = Paint.Style.FILL
        for (r in 0 until rows) for (q in 0 until cols) {
            val x = q * sp + sp / 2f
            val y = r * sp + sp / 2f
            val d = hypot(x - e.w / 2f, y - e.h / 2f)
            var s = 0.5f + 0.5f * sin(d / (80f * e.dp) - e.t * 2f * e.speed)
            if (e.touching && e.touchOn) {
                val dd = hypot(x - e.tx, y - e.ty)
                if (dd < e.radius) s = (s + (1f - dd / e.radius) * e.dir).coerceIn(0f, 1.4f)
            }
            p.color = hcol(d * 0.08f, (60 + s * 190).toInt())
            c.drawCircle(x, y, (1f + s * 8f) * e.dp * 0.8f, p)
        }
    }
}

// ---------- Gradient mesh ----------
class MeshGradient(e: Env) : Scene(e) {
    private var fx0 = 0f
    private var fy0 = 0f
    override fun reset() { fx0 = e.w / 2f; fy0 = e.h / 2f }
    override fun update(dt: Float) {
        if (e.touching && e.touchOn) {
            val sm = min(1f, 3f * dt)
            fx0 += (e.tx - fx0) * sm * e.dir; fy0 += (e.ty - fy0) * sm * e.dir
        }
    }
    override fun draw(c: Canvas) {
        val w = e.w.toFloat(); val h = e.h.toFloat()
        val t = e.t * 0.25f * e.speed
        p.style = Paint.Style.FILL
        for (i in 0 until 5) {
            var bx = w * (0.5f + 0.4f * sin(t * (0.7f + i * 0.23f) + i * 1.7f))
            var by = h * (0.5f + 0.4f * cos(t * (0.5f + i * 0.19f) + i * 2.3f))
            if (i == 0 && e.touching && e.touchOn) { bx = fx0; by = fy0 }
            val rr = max(w, h) * 0.55f
            p.shader = RadialGradient(bx, by, rr, hcol(i * 40f, 200), hcol(i * 40f, 0), Shader.TileMode.CLAMP)
            c.drawCircle(bx, by, rr, p)
        }
        p.shader = null
    }
}

// ---------- Falling blocks ----------
class FallingBlocks(e: Env) : Scene(e) {
    override val touchSound: String? = "tick"
    private val cols = 10
    private var rows = 20
    private var cell = 1f
    private var occ = BooleanArray(1)
    private var hue = IntArray(1)
    private val shapes = arrayOf(
        intArrayOf(0, 0, 1, 0, 2, 0, 3, 0), intArrayOf(0, 0, 1, 0, 0, 1, 1, 1),
        intArrayOf(0, 0, 1, 0, 2, 0, 1, 1), intArrayOf(0, 0, 1, 0, 2, 0, 2, 1),
        intArrayOf(0, 0, 1, 0, 2, 0, 0, 1), intArrayOf(1, 0, 2, 0, 0, 1, 1, 1), intArrayOf(0, 0, 1, 0, 1, 1, 2, 1)
    )
    private var cur = shapes[0]
    private var px = 0
    private var py = 0f
    private var ph = 0
    private var acc = 0f

    override fun reset() {
        cell = e.w.toFloat() / cols
        rows = (e.h / cell).toInt() + 1
        occ = BooleanArray(cols * rows)
        hue = IntArray(cols * rows)
        newPiece()
    }

    private fun newPiece() {
        cur = shapes[Random.nextInt(shapes.size)]
        px = Random.nextInt(cols - 3)
        py = -2f
        ph = Random.nextInt(7) * 50
    }

    private fun fits(x0: Int, y0: Int): Boolean {
        var k = 0
        while (k < 8) {
            val cx = x0 + cur[k]
            val cy = y0 + cur[k + 1]
            if (cx < 0 || cx >= cols || cy >= rows) return false
            if (cy >= 0 && occ[cy * cols + cx]) return false
            k += 2
        }
        return true
    }

    override fun update(dt: Float) {
        if (justTouched && e.touchOn) px = ((e.tx / cell).toInt() - 1).coerceIn(0, cols - 3)
        val speed = (5f + (if (e.touching) 14f else 0f)) * e.speed
        acc += dt * speed
        while (acc >= 1f) {
            acc -= 1f
            val ny = floor(py).toInt() + 1
            if (fits(px, ny)) py += 1f else {
                var k = 0
                var over = false
                while (k < 8) {
                    val cy = floor(py).toInt() + cur[k + 1]
                    val cx = px + cur[k]
                    if (cy < 0) over = true else { occ[cy * cols + cx] = true; hue[cy * cols + cx] = ph }
                    k += 2
                }
                if (over) { occ.fill(false) }
                var r = rows - 1
                while (r >= 0) {
                    var full = true
                    for (q in 0 until cols) if (!occ[r * cols + q]) { full = false; break }
                    if (full) {
                        for (rr in r downTo 1) for (q in 0 until cols) { occ[rr * cols + q] = occ[(rr - 1) * cols + q]; hue[rr * cols + q] = hue[(rr - 1) * cols + q] }
                        for (q in 0 until cols) occ[q] = false
                        e.sound("pop", 0.2f, 1.5f)
                    } else r--
                }
                newPiece()
            }
        }
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        val g = 1.5f * e.dp
        for (r in 0 until rows) for (q in 0 until cols) {
            if (occ[r * cols + q]) {
                p.color = hcol(hue[r * cols + q].toFloat(), 230)
                c.drawRect(q * cell + g, r * cell + g, (q + 1) * cell - g, (r + 1) * cell - g, p)
            }
        }
        var k = 0
        while (k < 8) {
            val cx = px + cur[k]
            val cy = py + cur[k + 1]
            p.color = hcol(ph.toFloat(), 255)
            c.drawRect(cx * cell + g, cy * cell + g, (cx + 1) * cell - g, (cy + 1) * cell - g, p)
            k += 2
        }
    }
}

// ---------- Bouncy balls ----------
class BouncyBalls(e: Env) : ParticleScene(e, 14, 40) {
    override val touchSound: String? = "plop"
    override fun spawn(i: Int, initial: Boolean) {
        randomPos(i)
        vx[i] = rf(-200f, 200f) * e.dp; vy[i] = rf(-200f, 0f) * e.dp
        s[i] = rf(12f, 30f)
    }
    override fun update(dt: Float) {
        val sw = e.w.toFloat(); val sh = e.h.toFloat()
        for (i in 0 until n) {
            val rad = s[i] * e.dp
            touchForce(x[i], y[i], 3500f * e.dp)
            vx[i] += fx * dt
            vy[i] += (1800f * e.dp + fy) * dt
            x[i] += vx[i] * dt * e.speed
            y[i] += vy[i] * dt * e.speed
            if (x[i] < rad) { x[i] = rad; vx[i] = abs(vx[i]) * 0.85f } else if (x[i] > sw - rad) { x[i] = sw - rad; vx[i] = -abs(vx[i]) * 0.85f }
            if (y[i] < rad) { y[i] = rad; vy[i] = abs(vy[i]) * 0.85f }
            else if (y[i] > sh - rad) {
                if (abs(vy[i]) > 500f * e.dp) e.sound("thud", 0.18f, rf(0.9f, 1.4f))
                y[i] = sh - rad; vy[i] = -abs(vy[i]) * 0.85f
                vx[i] *= 0.995f
            }
        }
        for (i in 0 until n) for (j in i + 1 until n) {
            val dx = x[i] - x[j]; val dy = y[i] - y[j]
            val dist = sqrt(dx * dx + dy * dy)
            val md = (s[i] + s[j]) * e.dp
            if (dist < md && dist > 0.01f) {
                val nx = dx / dist; val ny = dy / dist
                val push = (md - dist) / 2f
                x[i] += nx * push; y[i] += ny * push; x[j] -= nx * push; y[j] -= ny * push
                val vn = (vx[i] - vx[j]) * nx + (vy[i] - vy[j]) * ny
                if (vn < 0f) {
                    val imp = -1.8f * vn / 2f
                    vx[i] += imp * nx; vy[i] += imp * ny; vx[j] -= imp * nx; vy[j] -= imp * ny
                }
            }
        }
    }
    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            val rad = s[i] * e.dp
            p.shader = RadialGradient(x[i] - rad * 0.3f, y[i] - rad * 0.3f, rad * 1.3f, hcol(i * 25f + 30f, 255), hcol(i * 25f - 20f, 255), Shader.TileMode.CLAMP)
            c.drawCircle(x[i], y[i], rad, p)
        }
        p.shader = null
    }
}

// ---------- Gyroscope ----------
class Gyro(e: Env) : Scene(e) {
    override val touchSound: String? = "whoosh"
    private var cx = 0f
    private var cy = 0f
    override fun reset() { cx = e.w / 2f; cy = e.h / 2f }
    override fun update(dt: Float) {
        var tx = e.w / 2f; var ty = e.h / 2f
        if (e.touching && e.touchOn) { tx += (e.tx - tx) * 0.5f * e.dir; ty += (e.ty - ty) * 0.5f * e.dir }
        val sm = min(1f, 4f * dt)
        cx += (tx - cx) * sm; cy += (ty - cy) * sm
    }
    override fun draw(c: Canvas) {
        val r = min(e.w, e.h) * 0.4f
        val t = e.t * e.speed
        for (k in 0 until 4) {
            c.save()
            c.translate(cx, cy)
            c.rotate(t * 25f + k * 45f)
            c.scale(1f, abs(cos(t * 0.5f + k * 0.8f)).coerceAtLeast(0.05f))
            p.style = Paint.Style.STROKE
            p.strokeWidth = (3f + k) * e.dp
            p.color = hcol(k * 35f, 200)
            c.drawCircle(0f, 0f, r * (1f - k * 0.18f), p)
            c.restore()
        }
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        c.drawCircle(cx, cy, 6f * e.dp, p)
    }
}

// ---------- Oscilloscope ----------
class Scope(e: Env) : Scene(e) {
    override val touchSound: String? = "tick"
    private val path = Path()
    private var bump = 0f
    private var lx = 0f
    override fun reset() { bump = 0f }
    override fun update(dt: Float) {
        val on = e.touching && e.touchOn
        if (on) lx = e.tx
        bump += ((if (on) 1f else 0f) - bump) * min(1f, 5f * dt)
    }
    override fun draw(c: Canvas) {
        val w = e.w.toFloat(); val h = e.h.toFloat()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * e.dp
        p.color = col(30)
        for (k in 1..9) { c.drawLine(w * k / 10f, 0f, w * k / 10f, h, p); c.drawLine(0f, h * k / 10f, w, h * k / 10f, p) }
        path.reset()
        var x = 0f
        var first = true
        while (x <= w) {
            val g = exp(-((x - lx) * (x - lx)) / (2f * e.radius * e.radius * 0.5f))
            val amp = h * 0.12f * (1f + e.dir * bump * 1.6f * g)
            val y = h / 2f + amp * (sin(x / w * 18f + e.t * 3f * e.speed) + 0.5f * sin(x / w * 41f - e.t * 5f * e.speed) + 0.25f * sin(x / w * 87f + e.t * 9f))
            if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
            x += 6f
        }
        p.strokeWidth = 9f * e.dp; p.color = col(35); c.drawPath(path, p)
        p.strokeWidth = 4f * e.dp; p.color = col(90); c.drawPath(path, p)
        p.strokeWidth = 1.8f * e.dp; p.color = Color.argb(255, 235, 255, 245); c.drawPath(path, p)
    }
}

// ---------- Game of Life ----------
class LifeGame(e: Env) : Scene(e) {
    override val touchSound: String? = "tick"
    private var cols = 10
    private var rows = 10
    private var cell = 1f
    private var cur = BooleanArray(1)
    private var nxt = BooleanArray(1)
    private var age = IntArray(1)
    private var acc = 0f
    private var lastCount = -1
    private var same = 0

    override fun reset() {
        cell = 14f * e.dp / e.quality.coerceIn(0.5f, 1f)
        cols = (e.w / cell).toInt() + 1
        rows = (e.h / cell).toInt() + 1
        cur = BooleanArray(cols * rows); nxt = BooleanArray(cols * rows); age = IntArray(cols * rows)
        seed()
    }

    private fun seed() {
        for (i in cur.indices) { cur[i] = Random.nextFloat() < 0.25f; age[i] = 0 }
        same = 0
    }

    override fun update(dt: Float) {
        acc += dt * e.speed
        if (e.touching && e.touchOn) {
            val cx = (e.tx / cell).toInt(); val cy = (e.ty / cell).toInt()
            val rr = (e.radius / cell).toInt().coerceAtLeast(2)
            for (k in 0 until 6) {
                val x = (cx + Random.nextInt(-rr, rr + 1)).coerceIn(0, cols - 1)
                val y = (cy + Random.nextInt(-rr, rr + 1)).coerceIn(0, rows - 1)
                cur[y * cols + x] = e.dir > 0
            }
        }
        if (acc < 0.12f) return
        acc = 0f
        var count = 0
        for (r in 0 until rows) for (q in 0 until cols) {
            var nb = 0
            for (dy in -1..1) for (dx in -1..1) {
                if (dx == 0 && dy == 0) continue
                val rr = (r + dy + rows) % rows
                val qq = (q + dx + cols) % cols
                if (cur[rr * cols + qq]) nb++
            }
            val i = r * cols + q
            val alive = cur[i]
            val nv = if (alive) nb == 2 || nb == 3 else nb == 3
            nxt[i] = nv
            age[i] = if (nv) (if (alive) age[i] + 1 else 0) else 0
            if (nv) count++
        }
        val t = cur; cur = nxt; nxt = t
        if (count == lastCount) same++ else same = 0
        lastCount = count
        if (count < 8 || same > 25) seed()
    }

    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        val g = 1.2f * e.dp
        for (r in 0 until rows) for (q in 0 until cols) {
            val i = r * cols + q
            if (cur[i]) {
                p.color = hcol(age[i] * 6f, 230)
                c.drawRect(q * cell + g, r * cell + g, (q + 1) * cell - g, (r + 1) * cell - g, p)
            }
        }
    }
}

// ---------- Wind tree ----------
class WindTree(e: Env) : Scene(e) {
    private var bump = 0f
    private var wind = 0f
    override fun reset() { bump = 0f; wind = 0f }
    override fun update(dt: Float) {
        val on = e.touching && e.touchOn
        bump += ((if (on) 1f else 0f) - bump) * min(1f, 4f * dt)
        if (on) wind = (e.tx - e.w / 2f) / e.w * e.dir
    }
    private fun branch(c: Canvas, x: Float, y: Float, len: Float, ang: Float, depth: Int) {
        val sway = sin(e.t * 0.8f * e.speed + depth * 0.7f) * 0.05f + wind * bump * 0.25f * (8 - depth) / 8f
        val a = ang + sway
        val x2 = x + sin(a) * len
        val y2 = y - cos(a) * len
        p.style = Paint.Style.STROKE
        p.strokeWidth = (depth * 1.6f + 1f) * e.dp
        p.color = Color.rgb(90 + (8 - depth) * 4, 66 + (8 - depth) * 3, 50)
        c.drawLine(x, y, x2, y2, p)
        if (depth == 0) {
            p.style = Paint.Style.FILL
            p.color = hcol(((x * 0.1f) % 40f), 200)
            c.drawCircle(x2, y2, 5f * e.dp, p)
            return
        }
        branch(c, x2, y2, len * 0.74f, a - 0.38f, depth - 1)
        branch(c, x2, y2, len * 0.74f, a + 0.38f, depth - 1)
    }
    override fun draw(c: Canvas) {
        branch(c, e.w / 2f, e.h * 0.92f, e.h * 0.16f, 0f, 8)
        p.style = Paint.Style.FILL
        p.color = Color.argb(160, 20, 24, 30)
        c.drawRect(0f, e.h * 0.92f, e.w.toFloat(), e.h.toFloat(), p)
    }
}

// ---------- Sunburst / disco ----------
class Sunburst(e: Env, private val disco: Boolean) : Scene(e) {
    override val touchSound: String? = if (disco) "chime" else "whoosh"
    private var cx = 0f
    private var cy = 0f
    private val path = Path()
    override fun reset() { cx = e.w / 2f; cy = e.h / 2f }
    override fun update(dt: Float) {
        var tx = e.w / 2f; var ty = e.h / 2f
        if (e.touching && e.touchOn) { tx += (e.tx - tx) * 0.6f * e.dir; ty += (e.ty - ty) * 0.6f * e.dir }
        val sm = min(1f, 4f * dt)
        cx += (tx - cx) * sm; cy += (ty - cy) * sm
    }
    override fun draw(c: Canvas) {
        val n = if (disco) 18 else 24
        val big = hypot(e.w.toFloat(), e.h.toFloat())
        p.style = Paint.Style.FILL
        for (k in 0 until n) {
            val a0 = e.t * (if (disco) 0.5f else 0.3f) * e.speed + k * 6.2832f / n
            val a1 = a0 + 6.2832f / n * (if (disco) 0.45f else 1f)
            if (!disco && k % 2 == 1) continue
            path.reset()
            path.moveTo(cx, cy)
            path.lineTo(cx + cos(a0) * big, cy + sin(a0) * big)
            path.lineTo(cx + cos(a1) * big, cy + sin(a1) * big)
            path.close()
            val pulse = if (disco) 0.5f + 0.5f * sin(e.t * 3f + k) else 1f
            p.color = hcol(if (disco) k * 20f else 0f, (60 + 90 * pulse).toInt())
            c.drawPath(path, p)
        }
        val gl = 120f * e.dp
        p.shader = RadialGradient(cx, cy, gl, col(200), col(0), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, gl, p)
        p.shader = null
    }
}

// ---------- Hypno spiral ----------
class Hypno(e: Env) : Scene(e) {
    override val touchSound: String? = "whoosh"
    private var cx = 0f
    private var cy = 0f
    override fun reset() { cx = e.w / 2f; cy = e.h / 2f }
    override fun update(dt: Float) {
        var tx = e.w / 2f; var ty = e.h / 2f
        if (e.touching && e.touchOn) { tx += (e.tx - tx) * 0.5f * e.dir; ty += (e.ty - ty) * 0.5f * e.dir }
        val sm = min(1f, 4f * dt)
        cx += (tx - cx) * sm; cy += (ty - cy) * sm
    }
    override fun draw(c: Canvas) {
        val n = 22
        val sp = hypot(e.w.toFloat(), e.h.toFloat()) * 0.6f / n
        val off = (e.t * 0.7f * e.speed) % 2f
        p.style = Paint.Style.FILL
        for (k in n downTo 0) {
            val r = (k + off) * sp
            val idx = k + (if (off >= 1f) 1 else 0)
            p.color = if (idx % 2 == 0) hcol(k * 8f, 255) else bgColor()
            c.drawCircle(cx, cy, r, p)
        }
    }
}

// ---------- Neon clock ----------
class NeonClock(e: Env) : Scene(e) {
    override val touchSound: String? = "tick"
    override fun reset() {}
    override fun update(dt: Float) {}
    override fun draw(c: Canvas) {
        val now = System.currentTimeMillis() + java.util.TimeZone.getDefault().getOffset(System.currentTimeMillis())
        val sec = (now % 60000L) / 1000f
        val min = (now / 60000L % 60L) + sec / 60f
        val hr = (now / 3600000L % 12L) + min / 60f
        val cx = e.w / 2f
        val cy = e.h * 0.42f
        val r = e.w * 0.38f
        p.style = Paint.Style.STROKE
        for (k in 0 until 60) {
            val a = k * 0.10472f - 1.5708f
            val big = k % 5 == 0
            p.strokeWidth = (if (big) 3.5f else 1.5f) * e.dp
            p.color = col(if (big) 230 else 90)
            val r0 = r * (if (big) 0.88f else 0.94f)
            c.drawLine(cx + cos(a) * r0, cy + sin(a) * r0, cx + cos(a) * r, cy + sin(a) * r, p)
        }
        p.strokeWidth = 2f * e.dp
        p.color = col(60)
        c.drawCircle(cx, cy, r * 1.06f, p)
        fun hand(frac: Float, len: Float, wd: Float, colr: Int) {
            val a = frac * 6.2832f - 1.5708f
            p.strokeWidth = wd * e.dp
            p.color = colr
            p.strokeCap = Paint.Cap.ROUND
            c.drawLine(cx, cy, cx + cos(a) * r * len, cy + sin(a) * r * len, p)
            p.strokeCap = Paint.Cap.BUTT
        }
        hand(hr / 12f, 0.5f, 7f, Color.WHITE)
        hand(min / 60f, 0.75f, 5f, hcol(0f, 255))
        hand(sec / 60f, 0.85f, 2f, hcol(150f, 255))
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        c.drawCircle(cx, cy, 7f * e.dp, p)
        p.textAlign = Paint.Align.CENTER
        p.textSize = e.w * 0.14f
        p.typeface = Typeface.DEFAULT_BOLD
        p.color = col(235)
        val hh = (now / 3600000L % 24L).toInt()
        val mm = (now / 60000L % 60L).toInt()
        c.drawText(String.format("%02d:%02d", hh, mm), cx, e.h * 0.82f, p)
    }
}

// ---------- Heartbeat ----------
class Ecg(e: Env) : Scene(e) {
    private val nPts = 180
    private val buf = FloatArray(nPts)
    private var phase = 0f
    private var acc = 0f
    private var lastQ = false
    private val path = Path()

    override fun reset() { buf.fill(0f); phase = 0f }

    private fun wave(ph: Float): Float = when {
        ph < 0.10f -> 0.15f * sin(ph / 0.10f * 3.1416f)
        ph < 0.18f -> 0f
        ph < 0.20f -> -0.15f * (ph - 0.18f) / 0.02f
        ph < 0.24f -> -0.15f + 1.15f * (ph - 0.20f) / 0.04f
        ph < 0.28f -> 1f - 1.35f * (ph - 0.24f) / 0.04f
        ph < 0.31f -> -0.35f + 0.35f * (ph - 0.28f) / 0.03f
        ph < 0.46f -> 0f
        ph < 0.60f -> 0.25f * sin((ph - 0.46f) / 0.14f * 3.1416f)
        else -> 0f
    }

    override fun update(dt: Float) {
        val bpm = (70f + (if (e.touching) 60f else 0f)) * e.speed
        acc += dt
        val step = 1f / 90f
        while (acc >= step) {
            acc -= step
            phase += step * bpm / 60f
            if (phase >= 1f) { phase -= 1f; e.sound("tick", 0.12f, 0.7f) }
            for (i in 0 until nPts - 1) buf[i] = buf[i + 1]
            buf[nPts - 1] = wave(phase)
        }
    }

    override fun draw(c: Canvas) {
        val w = e.w.toFloat(); val h = e.h.toFloat()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * e.dp
        p.color = col(30)
        for (k in 1..9) { c.drawLine(w * k / 10f, 0f, w * k / 10f, h, p); c.drawLine(0f, h * k / 10f, w, h * k / 10f, p) }
        path.reset()
        for (i in 0 until nPts) {
            val x = i / (nPts - 1f) * w
            val y = h / 2f - buf[i] * h * 0.2f
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        p.strokeWidth = 9f * e.dp; p.color = col(40); c.drawPath(path, p)
        p.strokeWidth = 3.5f * e.dp; p.color = col(120); c.drawPath(path, p)
        p.strokeWidth = 2f * e.dp; p.color = Color.argb(255, 235, 255, 245); c.drawPath(path, p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        c.drawCircle(w, h / 2f - buf[nPts - 1] * h * 0.2f, 5f * e.dp, p)
    }
}

// ---------- Fountain ----------
class Fountain(e: Env) : ParticleScene(e, 160, 320) {
    override val canBounceY = true
    override val touchSound: String? = "plop"
    private var src = 0f
    override fun reset() { src = e.w / 2f; super.reset() }
    override fun spawn(i: Int, initial: Boolean) {
        x[i] = src + rf(-12f, 12f) * e.dp
        y[i] = e.h.toFloat() - rf(0f, if (initial) e.h * 0.6f else 10f * e.dp)
        vx[i] = rf(-170f, 170f) * e.dp
        vy[i] = -rf(750f, 1150f) * e.dp
        s[i] = rf(1.6f, 3.4f)
        r[i] = rf(0f, 40f)
    }
    override fun update(dt: Float) {
        val target = if (e.touching && e.touchOn) e.tx else e.w / 2f
        src += (target - src) * min(1f, 3f * dt)
        for (i in 0 until n) {
            touchForce(x[i], y[i], 2600f * e.dp)
            vx[i] += fx * dt
            vy[i] += (1400f * e.dp + fy) * dt
            x[i] += vx[i] * dt * e.speed
            y[i] += vy[i] * dt * e.speed
            if (y[i] > e.h + 20f * e.dp || x[i] < -50f || x[i] > e.w + 50f) spawn(i, false)
        }
    }
    override fun draw(c: Canvas) {
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            p.color = hcol(r[i], 200)
            c.drawCircle(x[i], y[i], s[i] * e.dp, p)
        }
    }
}
